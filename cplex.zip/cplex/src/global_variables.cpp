#include "global_variables.h"


int day;
int K;
int N;
int Q;
int P;
double regulation;
double** people;
double** travel;
double root_LP;

double lambda=1;
double mu=100000000000;
double q=0;


