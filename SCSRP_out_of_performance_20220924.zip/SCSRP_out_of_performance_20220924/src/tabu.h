#include <vector>
#include<list>
#include <queue>
#include <math.h>
#include "global_variables.h"
#include "global_functions.h"
#include "heurisitic.h"
#include <cstdio>
#include <unordered_set>

using namespace std;


typedef struct Tabu_Route
{
	double reduced_cost;     

	vector<int> ng_arcselect;        
	vector<int> nodevisit_indicator;  
} Tabu_Route;


class tabu
{
public:
    vector<Tabu_Route*> new_generated_routes;
	int T;
	int nbCities;
	int src;
	double** travelcost;
	double** traveltime;
    vector<vector<int>> basic_columns_tabu;
	unordered_set<int> TL_remove;
	unordered_set<int> TL_insert;
	int maxIter=10;
	int maxCol=300;

public:
	tabu(int,int,int,double**,double**);

	~tabu()
	{
        while(!new_generated_routes.empty())
        {
            {
				delete new_generated_routes.back();
				new_generated_routes.pop_back();
			}
		}

		for(int i=0;i<nbCities;i++)
		{
			delete [] travelcost[i];
			delete [] traveltime[i];
		}
		delete [] travelcost;
		delete [] traveltime;
	};

/**********************************************************/
int tabu_search();
/**********************************************************/



};


