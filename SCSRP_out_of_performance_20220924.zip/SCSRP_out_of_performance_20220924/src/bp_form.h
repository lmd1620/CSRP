#include<stdlib.h>
#include<stdio.h>
#include<assert.h>
#include<time.h>
#include<ctime>
#include<iostream>
#include<fstream>
#include<math.h>
#include<string.h>
#include<errno.h>
#include<sstream>
#include<vector>
#include<queue>
#include<algorithm>
#include <cplex.h>


#include "tabu.h"
#include "global_variables.h"
#include "global_functions.h"
#include "heurisitic.h"
#include "labelcor.h"

using namespace std;

struct LPnode
{

	int level;
	int node_i;
	int node_j;
	int map_d;
	int map_o;

	double current_LP;

	int number;
	string branch_name;
	int branch_type;

	vector<vector<vector<int>>> column_index_global_branch;
	vector<vector<vector<vector<int>>>> column_arcs_global_branch;

	vector<vector<vector<vector<int>>>> column_node_global_branch;

	
	vector<vector<vector<int>>> assigned_cuts_global_branch;
	vector<vector<vector<int>>> unassigned_cuts_global_branch;
	vector<vector<vector<int>>> row_point_indicator_branch;

	double ****Node_traveltime,****Node_travelcost;
	//int** Node_status_u_selection;
	int**** Node_status_node_couple;
	int*** Node_status_node_couple_total;
	int*** Node_status_node_selection;
	





	CPXLPptr  key_lp;


	LPnode* release;
	LPnode* fixed;

	bool operator<(const LPnode& rhs) const
	{
		return rhs.current_LP<current_LP;
	}
};

using namespace std;

/*****************************************************************/
int my_floor(double a);
/*****************************************************************/

/*****************************************************************/
int  my_ceil(double a);
/*****************************************************************/

/*****************************************************************/
void master_heur_warmup();
/*****************************************************************/

/*****************************************************************/
void master_heur_warmup_consistent();
/*****************************************************************/

/*****************************************************************/
double master_tabu_solve_lp();
/*****************************************************************/

/*****************************************************************/
double tabu_solver(double *pi);
/*****************************************************************/

/*****************************************************************/
void master_build();
/*****************************************************************/

/*****************************************************************/
void master_initialize();
/*****************************************************************/

/*****************************************************************/
//void master_free();
/*****************************************************************/

/*****************************************************************/
double master_solve_lp(data* Homecare_instance);
/*****************************************************************/

/*****************************************************************/
double price_solver(double *pi, int num_rows);
/*****************************************************************/

/*****************************************************************/
int master_column_add_seperate(int map_d,double** newroutesgenerate,int** column_row_indicator,int NUMR);
/*****************************************************************/





/*****************************************************************/
bool master_check_integrality_arc();
/*****************************************************************/
/*****************************************************************/
bool master_check_integrality_arc_total();
/*****************************************************************/

/*****************************************************************/
bool master_check_integrality_node();
/*****************************************************************/


/*****************************************************************/
bool master_check_integrality_u();
/*****************************************************************/

/*****************************************************************/
bool branch_select_u_branching(int* node_i,int* node_j);
/*****************************************************************/

/*****************************************************************/
bool branch_select_node_branching(int* map_d,int*map_o,int* node_i);
/*****************************************************************/

/*****************************************************************/
LPnode* branch_u_enforce(data* Homecare_instance,int node_i,int node_j,CPXLPptr currentLPptr,double best_incumbent_current,int level);
LPnode* branch_u_forbidden(data* Homecare_instance,int node_i,int node_j,CPXLPptr currentLPptr,double best_incumbent_current,int level);
/*****************************************************************/

/*****************************************************************/
LPnode* branch_enforce(data* Homecare_instance,int map_d,int map_o,int node_i,CPXLPptr currentLPptr,double best_incumbent_current,int level);
LPnode* branch_forbidden(data* Homecare_instance,int map_d,int map_o,int node_i,CPXLPptr currentLPptr,double best_incumbent_current,int level);
/*****************************************************************/

/*****************************************************************/
bool branch_select_couple_branching(int* map_d,int*map_o,int* node_i,int* node_j);
bool branch_select_couple_branching_total(int* map_d,int* node_i,int* node_j);
/*****************************************************************/

/*****************************************************************/
LPnode* branch_release(data* Homecare_instance,int map_d,int map_o,int node_i,int node_j,CPXLPptr currentLPptr,int level);
LPnode* branch_fixed(data* Homecare_instance,int map_d,int map_o,int node_i,int node_j,CPXLPptr currentLPptr,int level);
LPnode* branch_release_total(data* Homecare_instance,int map_d,int node_i,int node_j,CPXLPptr currentLPptr,int level);
LPnode* branch_fixed_total(data* Homecare_instance,int map_d,int node_i,int node_j,CPXLPptr currentLPptr,int level);
/*****************************************************************/

/*****************************************************************/
int branch_and_price(data* Homecare_instance, int level);
/*****************************************************************/

/*****************************************************************/
void travel_free();
/*****************************************************************/

/*****************************************************************/
void master_free();
/*****************************************************************/

/*****************************************************************/
double MIPSolver_Bound(CPXLPptr currentLPptr);
/*****************************************************************/

void EvaluateSolution();
double CalcExpLate(vector<int> ROUTE_single);
double CalcLateProb(vector<int> ROUTE_single);
double CalcMaxExpLate(vector<int> ROUTE_single);
double CalcMaxLateProb(vector<int> ROUTE_single);
double CalcNodeExpLate(vector<double>& vec);
double CalcNodeLateProb(std::vector<double>& vec);