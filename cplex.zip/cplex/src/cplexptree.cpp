﻿#include "global_functions.h"


using namespace std;

int main(int argc,char** argv)
{
	data Homecare_instance;
	Homecare_instance.istname=(char*) calloc(2000,sizeof(char));
		
	Homecare_instance.distname=(char*) calloc(2000,sizeof(char));
		

	strcpy(Homecare_instance.istname, argv[1]);

	Homecare_instance.option=atoi(argv[2]);


	if (Homecare_instance.option==1)
	{
		get_peo_info(Homecare_instance.istname);
	}
	else if (Homecare_instance.option==2) //liurandata
	{
		cout<<"this is the liu data set testing\n";
		get_distance_info(Homecare_instance.istname);
	}
	else if (Homecare_instance.option==3) //liurandata
	{
		
		get_ts_info(Homecare_instance.istname);
		if(N+K==60)
		{
			strcpy(Homecare_instance.distname,"./HHCP_TSdata/distanceMatrix_60.txt");	
		}
		else if(N+K==70)
		{
			strcpy(Homecare_instance.distname,"./HHCP_TSdata/distanceMatrix_70.txt");	
		}
		else
		{
			exit(-1);
		}
		get_ts_info_travel(Homecare_instance.distname);

		
	}			
	else if (Homecare_instance.option==0) 
	{
		cout<<"this is the standard data set testing\n";
		get_standard_info(Homecare_instance.istname);
	}
	
	else if (Homecare_instance.option==4) 
	{
		get_peo_info(Homecare_instance.istname);
	}

	cout<<"after stdinfo construction\n";

	if (Homecare_instance.option==1)
	{
		get_travel();
	}
	else if (Homecare_instance.option==0) 
	{
		get_standard_travel();
	}
	else if (Homecare_instance.option==4) 
	{
		get_standard_travel();
	}
	
	//output();
	cout<<"after data construction\n";



	Homecare_instance.start_time=time(NULL);



    //#############################################
	//cout<<"solve之前"<<endl;
	clock_t start = clock();
	int optimalIndicator=solve();
	clock_t stop = clock();
	double dur = double(stop-start) / CLOCKS_PER_SEC;
	cout<<"run time is "<<dur<<endl;
	//cout<<"solve之后"<<endl;
	//#############################################
	



	master_free();
	
	Homecare_instance.stop_time=time(NULL);
	double duration =(double) difftime(Homecare_instance.stop_time,Homecare_instance.start_time);


	ofstream info_SUMMARY("info_BP.txt", ios::app);
	
	info_SUMMARY << fixed
				 << Homecare_instance.istname << "\t"
				 << optimalIndicator << "\t"
				 << duration  << "\t"
				 << root_LP << "\t"
				 << endl;
	info_SUMMARY.close();


	//cout<<"run time is "<<duration<<endl;
	return 1;
} 

