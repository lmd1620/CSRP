/*
 * Bitset implementation using C macros
 */

#ifndef UBITSET_H
#define UBITSET_H


/* Bitset type definition macros */
#define MBSET_T long unsigned int
#define WORDSIZE (8 * sizeof(MBSET_T))

/* Bitset creation macros */
#define M_CREATESET(setname, setsize) \
    enum setname##NUMBLOCKS{ setname##NUMBLOCKS = (1 + ((setsize)/(WORDSIZE))) }; \
    enum setname##MAXCAPACITY{ setname##MAXCAPACITY = ((setname##NUMBLOCKS) * WORDSIZE) }; \
    enum setname##SIZE{ setname##SIZE = (setsize) }; \
    MBSET_T setname[setname##NUMBLOCKS];

/* It copies a bitset to another */
#define M_COPY(set, newSet) \
    do{ \
        for(unsigned int _i = 0; _i < set##NUMBLOCKS; _i++){ \
            newSet[_i] = set[_i]; \
        } \
    }while(0)

/* It checks if two bitsets are equal */
#define M_EQUAL(setA, setB) \
    ({ \
        int _res = 1; \
        for(unsigned int _i = 0; _i < setA##NUMBLOCKS; _i++){if(setA[_i] != setB[_i]){ _res = 0; break;} } \
        _res == 1; \
    })

/* Bitset bit operations macros */
#define M_INSERT(set, element) \
    do{ \
        unsigned int _pos = (element % WORDSIZE); \
        unsigned int _blck = (unsigned int)(element / WORDSIZE); \
        set[_blck] = set[_blck] | ((MBSET_T)0x1 << _pos); \
    }while(0)

#define M_REMOVE(set, element) \
    do{ \
        unsigned int _pos = (element % WORDSIZE); \
        unsigned int _blck = (unsigned int)(element / WORDSIZE); \
        set[_blck] = set[_blck] & ~((MBSET_T)0x1 << _pos); \
    }while(0)

/* Bitset mathematical operations macros */
#define M_UNION(reSetC, opSetA, opSetB) \
    do{ \
        for(unsigned int _i = 0; _i < reSetC##NUMBLOCKS; _i++){ \
            reSetC[_i] = ((opSetA[_i]) | (opSetB[_i])); \
        } \
    }while(0)

#define M_INTERSECTION(reSetC, opSetA, opSetB) \
    do{ \
        for(unsigned int _i = 0; _i < reSetC##NUMBLOCKS; _i++){ \
            reSetC[_i] = ((opSetA[_i]) & (opSetB[_i])); \
        } \
    }while(0)

#define M_DIFFERENCE(reSetC, opSetA, opSetB) \
    do{ \
        for(unsigned int _i = 0; _i < reSetC##NUMBLOCKS; _i++){ \
            reSetC[_i] = (((opSetA[_i]) ^ (opSetB[_i])) & (opSetA[_i])); \
        } \
    }while(0)

#define M_SUBSET(opSetA, opSetB) \
    ({ \
        M_CREATESET(_RESETC, opSetA##NUMBLOCKS); \
        M_DIFFERENCE(_RESETC, opSetA, opSetB); \
        M_NONE(_RESETC); \
    })

#define M_BELONGS(set, element) \
    ({ \
        MBSET_T _res = 0; \
        unsigned int _pos = (element % WORDSIZE); \
        unsigned int _blck = (unsigned int)(element / WORDSIZE); \
        _res = set[_blck] & ((MBSET_T)0x1 << _pos); \
        _res > 0; \
    })

/* Bitset auxiliary and information macros */
#define M_RESET(set) \
    do{ \
        for(unsigned int _i = 0; _i < set##NUMBLOCKS; _i++){set[_i] = (MBSET_T)0;} \
    }while(0)

#define M_FILL(set, numElem) \
    do{ \
        unsigned int _numblck = (unsigned int)(numElem / WORDSIZE); \
        if(numElem >= (set##MAXCAPACITY)){ \
            printf("\n<MFILL Error> specified value outside bitset range capacity.\n"); return(-1); } \
        for(unsigned int _i = 0; _i <= _numblck; _i++){set[_i] = (MBSET_T)0xFFFFFFFFFFFFFFFF;} \
        set[_numblck] = (set[_numblck] >> ((WORDSIZE - 1) - (numElem % WORDSIZE))); \
    }while(0)

#define M_NONE(set) \
    ({ \
        int _res = 1; \
        for(unsigned int _i = 0; _i < set##NUMBLOCKS; _i++){if(set[_i] != (MBSET_T)0){ _res = 0; break;} } \
        _res == 1; \
    })

#define M_ALL(set) \
    ({ \
        int _res = 1; \
        MBSET_T _last = ((MBSET_T)0xFFFFFFFFFFFFFFFF >> ((WORDSIZE - 1) - ((set##SIZE) % WORDSIZE))); \
        for(unsigned int _i = 0; _i < ((set##NUMBLOCKS) - 1); _i++){ \
            if(set[_i] != (MBSET_T)0xFFFFFFFFFFFFFFFF){ _res = 0; break;} \
        } \
        if((set[((set##NUMBLOCKS) - 1)] & _last) != _last) _res = 0; \
        _res == 1; \
    })

#define M_FULL(set) \
    ({ \
        int _res = 1; \
        for(unsigned int _i = 0; _i < set##NUMBLOCKS; _i++){ \
            if(set[_i] != (MBSET_T)0xFFFFFFFFFFFFFFFF){ _res = 0; break;} \
        } \
        _res == 1; \
    })

#define M_PRINT(set) \
    do{ \
        unsigned int _elem = 0; \
        printf(#set "[ "); \
        for(unsigned int _i = 0; _i < set##NUMBLOCKS; _i++){ \
            for(unsigned int _j = 0; _j < WORDSIZE; _j++){ \
                if(set[_i] & ((MBSET_T)0x1 << _j)){ printf("%u ", _elem); } \
                _elem++; \
            } \
        } \
        printf("]\n"); \
    }while(0)

#define M_SETINFO(set) \
    do{ \
        printf("\nSize of bitset <" #set ">: %d\n", set##SIZE); \
        printf("Max capacity of bitset <" #set ">: %d\n", set##MAXCAPACITY); \
        printf("Possible range of values in bitset <" #set ">: 0 to %d\n", (set##MAXCAPACITY) - 1); \
        printf("Num of blocks in bitset <" #set ">: %d\n", set##NUMBLOCKS); \
        printf("bitset type info: %lu bytes (blocksize: %ld bits)\n", sizeof(MBSET_T), WORDSIZE); \
        printf("\n"); \
    }while(0)

#endif /* UBITSET_H */
