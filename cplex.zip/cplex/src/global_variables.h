﻿#ifndef VARIABLE_local_HEADER
#define VARIABLE_local_HEADER


#include <cplex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <iomanip>
#include <time.h>
#include <cstdlib> 
#include <vector>
#include<list>
#include <queue>
#include <cstdio>

using namespace std;
#define PI                      3.141592654
#define EARTH_RADIUS            6378.137       
#define M 10e10     


extern int day;
extern int K;
extern int N;
extern int Q;
extern int P;
extern double regulation;
extern double** people;
extern double** travel;

extern double lambda;
extern double mu;
extern double q;
extern double root_LP;

typedef class data
{
public:

	char *istname;
    int option;
    char *distname;

    // clock_t start_time;
    // clock_t stop_time;
    time_t  start_time;
    time_t stop_time;
    // tBegin,timeEnd,currTime;

} data;


#endif