﻿#include "global_functions.h"





double round(double r)
{
    return (r > 0.0) ? floor(r + 0.5) : ceil(r - 0.5);
}

double round2(double f)
{

    int a = (int)f;
    //获取十分位部分
    int b = (int)(f*10)%10;
    //获取百分位部分
    int c = (int)(f*100)%10;
    //获取千分位部分
    int d = (int)(f*1000)%10;
    
    //判断千分位是否大于等于5
    if (d >= 5) {
        //是，百分位进一位
        c ++;
    }
    
    //乘以系数后相加
    double e = a + b*0.1 + c*0.01;
    
    return e;
}

/*
double get_distance(double lng1, double lat1, double lng2, double lat2)
{
	double radLat1 = lat1 * PI / 180.0;   //角度1˚ = π / 180
	double radLat2 = lat2 * PI / 180.0;   //角度1˚ = π / 180
	double a = radLat1 - radLat2;//纬度之差
	double b = lng1 * PI / 180.0 - lng2* PI / 180.0;  //经度之差k
	double dst = 2 * asin((sqrt(pow(sin(a / 2), 2) + cos(radLat1) * cos(radLat2) * pow(sin(b / 2), 2))));
	dst = dst * EARTH_RADIUS;
	dst=round(2*dst);
	return dst;
}*/

double get_distance(double lng1, double lat1, double lng2, double lat2)
{
	double radLat1 = lat1 * PI / 180.0;   //角度1˚ = π / 180
	double radLat2 = lat2 * PI / 180.0;   //角度1˚ = π / 180
	double a = radLat1 - radLat2;//纬度之差
	double b = lng1 * PI / 180.0 - lng2* PI / 180.0;  //经度之差k
	double dst = 2 * asin((sqrt(pow(sin(a / 2), 2) + cos(radLat1) * cos(radLat2) * pow(sin(b / 2), 2))));
	dst = dst * EARTH_RADIUS;
	dst=round(2*dst);
	return dst;
}

void get_peo_info(char* filename)
{
	ifstream srcFile1(filename,ios::in); //以文本模式打开txt备读
  	    if(!srcFile1) { //打开失败
    	    cout << "error opening source file." << endl;
  	        exit (-1);
  	    }
	//0 for sequence 1/2 for position, 3/4time window, 5 for service time, 6+day表示pattern，5+day+P+表示服务等级和偏好
	int y;
	double x;
	srcFile1 >>y ;
	day=y;
	srcFile1 >>y ;
	K=y;
	srcFile1 >>y ;
	N=y;
	srcFile1 >>y ;
	Q=y;
	srcFile1 >>y ;
	P=y;
	srcFile1 >>x ;
	regulation=x;

	people = new double* [N+K];
	for (int i=0;i<N+K;i++)
	{
		people[i] = new double[7+day+P];
		for (int j=0;j<7+day+P;j++)
		{
			
			srcFile1 >>x ; //可以像用cin那样用ifstream对象
			people[i][j]=x;	
		}	 
	}
   	srcFile1.close();
	cout << "input successfully" << endl;

	travel = new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
	    travel[i] = new double[N+K];
	}

	cout << "input successfully" << endl;
}

void get_distance_info(char* filename)
{
	ifstream srcFile1(filename,ios::in); //以文本模式打开txt备读
    if(!srcFile1) 
	{ //打开失败
		cout << "error opening source file." << endl;
  	    exit (-1);
  	}

	int y;
	double x;
	srcFile1 >>y ;
	day=y;
	srcFile1 >>y ;
	K=y;
	srcFile1 >>y ;
	N=y;
	srcFile1 >>y ;
	Q=y;
	srcFile1 >>y ;
	P=y;
	srcFile1 >>x ;
	regulation=x;

	people = new double* [N+K];
	for (int i=0;i<N+K;i++)
	{
		people[i] = new double[7+day+P];
	}

	travel = new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
	    travel[i] = new double[N+K];
	}
	for(int j=0;j<N+2;j++)
	{
		srcFile1 >> x;
	}
	for(int i=K;i<N+K;i++)
	{
		srcFile1 >> x;
		for(int j=K;j<N+K;j++)
		{
			srcFile1 >> x;
			travel[i][j]=x;
		}
		srcFile1 >> x;
	}
	for(int j=0;j<N+2;j++)
	{
		srcFile1 >> x;
	}
	for(int i=0;i<K;i++)
	{
		srcFile1 >> x;
		for(int j=K;j<N+K;j++)
		{
			srcFile1 >> x;
			travel[i][j]=x;
			travel[j][i]=x;
		}
		srcFile1 >> x;
	}

	for(int i=K;i<N+K;i++)
	{
		srcFile1 >> x;
		people[i][5]=x;
	}

	for(int i=K;i<N+K;i++)
	{
		srcFile1 >> x;
		people[i][3]=x;
		srcFile1 >> x;
		people[i][4]=x;
	}

   	srcFile1.close();
	cout << "input successfully" << endl;

	for (int i=0;i<K;i++)
	{
		people[i][0]=i;
		people[i][1]=0;
		people[i][2]=0;
		people[i][3]=0;
		people[i][4]=0;
		people[i][5]=0;
		for(int d=0;d<day;d++)
		{
			people[i][6+d]=1;
		}
		people[i][5+day+P]=1;
		people[i][6+day+P]=N;
	}
	for (int i=K;i<N+K;i++)
	{
		people[i][0]=i;
		people[i][1]=0;
		people[i][2]=0;
		for(int d=0;d<day;d++)
		{
			people[i][6+d]=1;
		}
		people[i][5+day+P]=1;
		people[i][6+day+P]=1;
	}
}



void get_ts_info_travel(char* filename1)
{
	double x;

	ifstream srcFile2(filename1,ios::in); //以文本模式打开txt备读
	//srcFile2.open(filename1);
	//cout<<filename1<<endl;
	//cerr << "Error: " << strerror(errno);
  	    if(!srcFile2) { //打开失败
    	    cout << "error opening source file2." << endl;
  	        exit (-1);
  	    }

	

	travel = new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
	    travel[i] = new double[N+K];
		for (int j=0;j<N+K;j++)
		{
			srcFile2 >>x ; //可以像用cin那样用ifstream对象
			travel[i][j]=x;	
		}
	}
	srcFile2.close();
	cout << "input travel successfully" << endl;

}



void get_ts_info(char* filename)
{
	
	
	ifstream srcFile1(filename,ios::in); //以文本模式打开txt备读
  	    if(!srcFile1) { //打开失败
    	    cout << "error opening source file." << endl;
  	        exit (-1);
  	    }
	//0 for sequence 1/2 for position, 3 time window, 4 for service time, 5待添加, 6-5+day表示pattern，5+day+P+表示服务等级和偏好
	cout<<"filename\t"<<filename<<endl;
	int y;
	double x;
	srcFile1 >>y ;
	day=y;
	srcFile1 >>y ;
	K=y;
	srcFile1 >>y ;
	N=y;
	srcFile1 >>y ;
	Q=y;
	srcFile1 >>y ;
	P=y;
	srcFile1 >>x ;
	regulation=x;

	people = new double* [N+K];
	for (int i=0;i<N+K;i++)
	{
		people[i] = new double[7+day+P];
		for (int j=0;j<7+day+P;j++)
		{
			
			srcFile1 >>x ; //可以像用cin那样用ifstream对象
			people[i][j]=x;	
		}	 
	}
   	srcFile1.close();
	cout << "input people successfully" << endl;
}


void get_standard_info(char* filename)
{
	ifstream srcFile1(filename,ios::in); //以文本模式打开txt备读
  	    if(!srcFile1) { //打开失败
    	    cout << "error opening source file." << endl;
  	        exit (-1);
  	    }

	int y;
	int depot_combination;
	double x;

	double capacity;
	int vehicle;
	int depot;
	srcFile1 >>y ;
	srcFile1 >>y ;
	vehicle=y;
	srcFile1 >>y ;
	N=y;
	srcFile1 >>y ;
	depot=y;
	K=depot*vehicle;
	day=1;
	P=1;
	Q=1;
	
	for (int i=0;i<depot;i++)
	{
		srcFile1 >>x;
		//regulation=x;
		srcFile1 >>x;
		capacity=x;
	}



	people = new double* [N+K];
	for (int i=0;i<N+K;i++)
	{
		people[i] = new double[7+day+P];
	}

	for (int i=0;i<N;i++)
	{
		srcFile1 >>y; //1
		people[K+y-1][0]=K+y-1;	
		
		srcFile1 >>x; //2
		people[K+y-1][1]=x;	

		srcFile1 >>x; //3
		people[K+y-1][2]=x;	

		srcFile1 >>x; //4
		people[K+y-1][5]=x;	

		srcFile1 >>x; //5
		people[K+y-1][6+day+P]=x;	

		srcFile1 >>x; //6

		srcFile1 >>depot_combination; //7
		for(int j=0;j<depot_combination;j++)
		{
			srcFile1 >>x;
		}
		//srcFile1 >>x; //8
		//srcFile1 >>x; //9
		//srcFile1 >>x; //10
		//srcFile1 >>x; //11

		srcFile1 >>x; //12
		people[K+y-1][3]=x;	
		srcFile1 >>x; //13
		people[K+y-1][4]=x;	

		people[K+y-1][6]=1;
		people[K+y-1][7]=1;
	}

	for (int i=0;i<depot;i++)
	{
		srcFile1 >>y; //1
		for(int j=0;j<vehicle;j++)
		{
			people[vehicle*(y-N-1)+j][0]=vehicle*(y-N-1)+j;	
		}
		srcFile1 >>x; //2
		for(int j=0;j<vehicle;j++)
		{
			people[vehicle*(y-N-1)+j][1]=x;	
		}	
		srcFile1 >>x; //3
		for(int j=0;j<vehicle;j++)
		{
			people[vehicle*(y-N-1)+j][2]=x;	
			people[vehicle*(y-N-1)+j][3]=0;	
			people[vehicle*(y-N-1)+j][4]=0;	
			people[vehicle*(y-N-1)+j][5]=0;	
			people[vehicle*(y-N-1)+j][6]=1;	
			people[vehicle*(y-N-1)+j][7]=1;	
			people[vehicle*(y-N-1)+j][8]=capacity;	
		}	

		srcFile1 >>x; //4
		srcFile1 >>x; //5
		srcFile1 >>x; //6
		srcFile1 >>x; //7
		srcFile1 >>x; //8
		srcFile1 >>x; //9
		regulation=x;

	}
   	srcFile1.close();

	cout << "input successfully" << endl;

	travel = new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
	    travel[i] = new double[N+K];
	}
}




double get_distance_2(double x1, double y1, double x2, double y2)
{
	double dst = sqrt(pow((x1-x2)*1.0,2) + pow((y1-y2)*1.0,2));
	dst=round2(dst);
	return dst;
}

void get_standard_travel()
{
	for (int i=0;i<N+K-1;i++)
	{
		travel[0][0]=0;
		for (int j=i;j<N+K;j++)
		{
			travel[j][j]=0;
			double tempD=get_distance_2(people[i][1],people[i][2],people[j][1],people[j][2]);
			if(i!=j)
			{
				travel[i][j]=tempD;
				travel[j][i]=tempD;
			}
		}
	}
	ofstream destFile2("travel.txt",ios::out); //以文本模式打开txt备写,若文件已存在则清空原内容
    if(!destFile2) 
	{
		destFile2.close(); //程序结束前不能忘记关闭以前打开过的文件
		exit (-1);
	}
	for(int i = 0; i < N+K;i++)
	{
		for(int j = 0; j < N+K;j++)
		{
			destFile2 <<travel[i][j]<< "\t"; 
		}
		destFile2 <<"\n";
	}
	destFile2.close();
	cout<<"successfully get travel_cost"<<endl;
}



void get_travel()
{
	for (int i=0;i<N+K-1;i++)
	{
		travel[0][0]=0;
		for (int j=i;j<N+K;j++)
		{
			travel[j][j]=0;
			double tempD=get_distance(people[i][1],people[i][2],people[j][1],people[j][2]);
			if(i!=j)
			{
				travel[i][j]=tempD;
				travel[j][i]=tempD;
			}
		
		}
	}
	ofstream destFile2("travel.txt",ios::out); //以文本模式打开txt备写,若文件已存在则清空原内容
    if(!destFile2) 
	{
		destFile2.close(); //程序结束前不能忘记关闭以前打开过的文件
		exit (-1);
	}
	for(int i = 0; i < N+K;i++)
	{
		for(int j = 0; j < N+K;j++)
		{
			destFile2 <<travel[i][j]<< "\t"; 
		}
		destFile2 <<"\n";
	}
	destFile2.close();
	cout<<"successfully get travel_cost"<<endl;
}


// void output()
// {
// 	ofstream destFile_r("output.txt",ios::out); //以文本模式打开txt备写,若文件已存在则清空原内容
//     if(!destFile_r) 
// 	{
// 		destFile_r.close(); //程序结束前不能忘记关闭以前打开过的文件
// 		exit (-1);
// 	}
// 	for (int i=0;i<N+K;i++)
// 	{
// 		for (int j=0;j<7+day+P;j++)
// 		{
// 			destFile_r <<people[i][j]<< " "; 
				
// 		}	 
// 		destFile_r <<"\n";
// 	}

// 	destFile_r.close();

// 	cout << "output successfully" << endl;
// }



int solve()
{
   double   *x = NULL;
   double   *pi = NULL;
   double   *slack = NULL;
   double   *dj = NULL;


   CPXENVptr     env = NULL;
   CPXLPptr      lp = NULL;
   int           status = 0;
   double sol=0.0;
   int           cur_numrows, cur_numcols;
   env = CPXopenCPLEX (&status);
   if ( env == NULL ) {
      char  errmsg[CPXMESSAGEBUFSIZE];
      fprintf (stderr, "Could not open CPLEX environment.\n");
      CPXgeterrorstring (env, status, errmsg);
      fprintf (stderr, "%s", errmsg);
      exit(-1);
   }
   //status = CPXsetdblparam (env, CPXPARAM_TimeLimit, 3600.0);
   status = CPXsetdblparam (env, CPXPARAM_MIP_Tolerances_MIPGap, 1e-06);
	if ( status )  
   {
      exit(-1);
   }

   //cout<<"创建问题"<<endl;
   /* 创建问题 */
   lp = CPXcreateprob (env, &status, "pinetree");
   
   if ( lp == NULL ) {
      fprintf (stderr,"Failed to create subproblem\n");
      status = 1;
      exit(-1);
      //goto TERMINATE;
   }


   CPXsetintparam(env,CPX_PARAM_SCRIND,CPX_ON);

   double* time;
   time = (double *) malloc (10 * sizeof(double));

   status=CPXgetdettime(env, time);
   if ( status )  
   {
      exit(-1);
   }
   cout<<"time"<<time<<endl;
	
   free(time);
   status = CPXchgobjsen (env, lp, CPX_MIN);  /* Problem is minimization */
   if ( status )  
   {
      exit(-1);
   }
   //goto TERMINATE;
   //cout<<"最小化问题"<<endl;

   int NUMCOLS;

   
   double   *obj=NULL;
   double   *lb=NULL;
   double   *ub=NULL;
   char     **colname=NULL;
   char     *ctype=NULL;

   NUMCOLS=day*K*(N+K)*(N+K);//分别为x

   obj = (double *) malloc (NUMCOLS * sizeof(double));
   lb  = (double *) malloc (NUMCOLS * sizeof(double));
   ub  = (double *) malloc (NUMCOLS * sizeof(double));
   colname = (char**) malloc (NUMCOLS * sizeof(char*));
   ctype = (char *) malloc (NUMCOLS * sizeof(char));
   /*
   double   *obj=new double[NUMCOLS];
   double   *lb=new double[NUMCOLS];
   double   *ub=new double[NUMCOLS];
   char     **colname=new char*[NUMCOLS];
   char     *ctype=new char[NUMCOLS];
   */

   /* Now add the new columns.  First, populate the arrays. */
   int temp1;
   for (int d=0;d<day;d++)
   {
	   for (int o=0;o<K;o++)
	   {
		   for (int i=0;i<N+K;i++)
		   {
			   for (int j=0;j<N+K;j++)
			   {
				   temp1=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+i*(N+K)+j;
				   obj[temp1]=lambda*travel[i][j];
				   lb[temp1]=0;
               ub[temp1]=1;
	            ctype[temp1]='B';
				   colname[temp1]=new char[256];
				   sprintf(colname[temp1],"x_%d_%d_%d_%d",d,o,i,j);
			   }
		   }
	   } 
   }
   status = CPXnewcols (env, lp, NUMCOLS, obj, lb, ub, ctype, colname);


   free(obj);
   free(lb);
   free(ub);
   free(colname);
   free(ctype);

   NUMCOLS=N*K;//分别为u
   obj = (double *) malloc (NUMCOLS * sizeof(double));
   lb  = (double *) malloc (NUMCOLS * sizeof(double));
   ub  = (double *) malloc (NUMCOLS * sizeof(double));
   colname = (char**) malloc (NUMCOLS * sizeof(char*));
   ctype = (char *) malloc (NUMCOLS * sizeof(char));



   for (int j=0;j<N;j++)
   {
	   for (int o=0;o<K;o++)
	   {
		   temp1=j*K+o;
		   obj[temp1]=0;
		   lb[temp1]=0;
		   ub[temp1]=1;
		   ctype[temp1]='B';
		   colname[temp1]=new char[256];
		   sprintf(colname[temp1],"u_%d_%d",j,o);
	   }
   }

   status = CPXnewcols (env, lp, NUMCOLS, obj, lb, ub, ctype, colname);


   free(obj);
   free(lb);
   free(ub);
   free(colname);
   free(ctype);

   NUMCOLS=day*(N+K);//分别为S

   obj = (double *) malloc (NUMCOLS * sizeof(double));
   lb  = (double *) malloc (NUMCOLS * sizeof(double));
   ub  = (double *) malloc (NUMCOLS * sizeof(double));
   colname = (char**) malloc (NUMCOLS * sizeof(char*));
   ctype = (char *) malloc (NUMCOLS * sizeof(char));


   for (int d=0;d<day;d++)
   {
	   for (int i=0;i<N+K;i++)
	   {
		   temp1=d*(N+K)+i;
		   obj[temp1]=0;
		   lb[temp1]=0;
		   ub[temp1]=CPX_INFBOUND;
		   ctype[temp1]='C';
		   colname[temp1]=new char[256];
		   sprintf(colname[temp1],"S_%d_%d",d,i);
	   }
   }

   status = CPXnewcols (env, lp, NUMCOLS, obj, lb, ub, ctype, colname);


   free(obj);
   free(lb);
   free(ub);
   free(colname);
   free(ctype);




   

   cout<<"定义变量结束"<<endl;




   int      *rmatbeg=NULL;
   int      *rmatind=NULL;
   double   *rmatval=NULL;
   double   *rhs=NULL;
   char     *sense=NULL;
   char     **rowname=NULL;


   int rownow=day*N;
   int nznow=day*N*K*(N+K);

   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));


   cout<<"第一条约束"<<endl;
   
 
   int temp2;
   int temp3;
   //第一条约束 (3)
   for (int d=0;d<day;d++)
   {
	   for (int j=0;j<N;j++)
	   {
			temp2=d*N+j;//计算是多少行
			rmatbeg[temp2] = temp2*K*(N+K); 
			sense[temp2] = 'E';
			rhs[temp2]   = people[K+j][6+d];
			for (int o=0;o<K;o++)
			{
					for (int i=0;i<N+K;i++)
					{
						temp3=d*N*K*(N+K)+j*K*(N+K)+o*(N+K)+i;
						rmatval[temp3]=1;
						rmatind[temp3]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+i*(N+K)+(j+K);
					}
			}
			rowname[temp2]=new char[256];
         	sprintf(rowname[temp2],"c0_%d",temp2);
	   }
   }

   int rowed=day*N;
   int coled=day*K*(N+K)*(N+K);
   int nzed=day*N*K*(N+K);
   
   cout<<"添加约束"<<endl;
   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);
   
   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);



   cout<<"第二条约束"<<endl;
   //第二条约束 (11)
   rownow=N;
   nznow=N*K;

   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));

   for(int j=0;j<N;j++)
   {
	   rmatbeg[j] = j*K; 
	   sense[j] = 'L';
	   rhs[j]   = Q;
	   rowname[j]=new char[256];
	   sprintf(rowname[j],"c1_%d",j);

	   for(int o=0;o<K;o++)
	   {
		   temp3=j*K+o;
		   rmatval[temp3]=1;
		   rmatind[temp3]=coled+j*K+o;  
	   }
   }

   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }

   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+N;
   coled=coled+N*K;
   nzed=nzed+N*K;

   
    //第三条约束 (12)
   rownow=day*K*(N+K)*N;
   nznow=2*day*K*(N+K)*N;
   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));
   for (int d=0;d<day;d++)
   {
	   for (int j=0;j<N;j++)
	   {
		   for (int o=0;o<K;o++)
		   {
				for (int i=0;i<N+K;i++)
				{
					temp2=d*N*K*(N+K)+j*K*(N+K)+o*(N+K)+i;
					rmatbeg[temp2] = 2*temp2;
					sense[temp2] = 'L';
					rhs[temp2]   = 0;

					temp3=2*temp2;
					rmatval[temp3]=1;
					rmatind[temp3]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+i*(N+K)+(j+K);	
					temp3=2*temp2+1;
					rmatval[temp3]=-1;
					rmatind[temp3]=day*K*(N+K)*(N+K)+j*K+o;	

					rowname[temp2]=new char[256];
	                sprintf(rowname[temp2],"c2_%d",temp2);
				}
		   }
 		   
	   }
   }
   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+day*K*(N+K)*N;
   coled=coled;
   nzed=nzed+2*day*K*(N+K)*N;
   
   

   //第四条约束 (13)

   rownow=N*K;
   nznow=N*K*(1+day*(N+K));


   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));

   for (int j=0;j<N;j++)
   {
	   for (int o=0;o<K;o++)
	   {
		   temp2=j*K+o;
		   rmatbeg[temp2] = (1+day*(N+K))*temp2;
		   sense[temp2] = 'L';
		   rhs[temp2]   = 0;
		   rowname[temp2]=new char[256];
	       sprintf(rowname[temp2],"c3_%d",temp2);
		   for (int d=0;d<day;d++) 
		   {
			   for (int i=0;i<N+K;i++)
			   {
				   temp3=(1+day*(N+K))*temp2+d*(N+K)+i;
				   rmatval[temp3]=-1;
				   rmatind[temp3]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+i*(N+K)+(j+K);
			   }
		   }
		   temp3=(1+day*(N+K))*temp2+day*(N+K);
		   rmatval[temp3]=1;
		   rmatind[temp3]=day*K*(N+K)*(N+K)+j*K+o;
	   }
   }
   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+N*K;
   coled=coled;
   nzed=nzed+N*K*(1+day*(N+K));
   

   //第五条约束(10)
   
   rownow=day*N*K*P;
   nznow=day*N*K*P*(N+K);


   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));

   for (int d=0;d<day;d++) 
   {
	   for (int j=0;j<N;j++)
	   {
		   for (int o=0;o<K;o++)
		   {
			   for(int p=0;p<P;p++)
			   {
				   //cout<<"进入循环"<<endl;
				   temp2=d*N*K*P+j*K*P+o*P+p;
				   //cout<<"temp2"<<temp2<<endl;
				   rmatbeg[temp2] = (N+K)*temp2;
				   sense[temp2] = 'L';
				   rhs[temp2]   = 1+people[o][p+day+6]-people[K+j][p+day+6];
				   rowname[temp2]=new char[256];
	               sprintf(rowname[temp2],"c4_%d",temp2);
				   for (int i=0;i<N+K;i++)
				   {
					   temp3=(N+K)*temp2+i;
					   rmatval[temp3]=1;
					   rmatind[temp3]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+i*(N+K)+(j+K);
				   }
			   }
		   }
	   }
   }

   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+day*N*K*P;
   coled=coled;
   nzed=nzed+day*N*K*P*(N+K);
   

   //第六条约束 (6)
//    rownow=day*K;
//    nznow=day*K*(N+K)*(N+K);

//    rmatbeg = (int *) malloc (rownow * sizeof(int));
//    rmatind  = (int *) malloc (nznow * sizeof(int));
//    rmatval  = (double *) malloc (nznow * sizeof(double));
//    rhs = (double *) malloc (rownow* sizeof(double));
//    sense = (char *) malloc (rownow* sizeof(char));
//    rowname = (char **) malloc (rownow * sizeof(char*));

//    for (int d=0;d<day;d++) 
//    {
// 	   //cout<<"进入d"<<d<<endl;
// 	   for (int o=0;o<K;o++)
// 	   {
// 		   //cout<<"进入o"<<o<<endl;
// 		   temp2=d*K+o;
// 		   rmatbeg[temp2] = (N+K)*(N+K)*temp2;
// 		   sense[temp2] = 'L';
// 		   rhs[temp2]   = regulation;
// 		   rowname[temp2]=new char[256];
// 	       sprintf(rowname[temp2],"c5_%d",temp2);
// 		   for (int i=0;i<N+K;i++)
// 		   {
// 			   //cout<<"进入i"<<i<<endl;
// 			   for (int j=0;j<(N+K);j++)
// 			   {
// 				   //cout<<"进入j"<<j<<endl;
// 				   temp3=(N+K)*(N+K)*temp2+i*(N+K)+j;
// 				   rmatval[temp3]=travel[i][j]+people[j][5];
// 				   rmatind[temp3]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+i*(N+K)+j;
// 			   }
// 		   }
// 	   }
//    }

//    status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
//                         rmatind, rmatval, NULL, rowname);

//    if ( status )  
//    {
//       exit(-1);
//    }
//    free(rmatbeg);
//    free(rmatind);
//    free(rmatval);
//    free(sense);
//    free(rowname);
//    free(rhs);

//    rowed=rowed+day*K;
//    coled=coled;
//    nzed=nzed+day*K*(N+K)*(N+K);




   










   //第七条约束 (4-5)
   rownow=day*K*(N+K);
   nznow=2*day*K*(N+K)*(N+K);


   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));

   for (int d=0;d<day;d++) 
   {
	   for (int o=0;o<K;o++)
	   {
		   for (int j=0;j<N+K;j++)
		   {
			   temp2=d*K*(N+K)+o*(N+K)+j;
			   rmatbeg[temp2] = 2*(N+K)*temp2;
			   sense[temp2] = 'E';
		       rhs[temp2]   = 0;
			   rowname[temp2]=new char[256];
	           sprintf(rowname[temp2],"c6_%d",temp2);
			   
			   for (int i=0;i<N+K;i++)
			   {
				   temp3=2*(N+K)*temp2+2*i;
				   rmatval[temp3]=1;
				   rmatind[temp3]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+i*(N+K)+j;
				   rmatval[temp3+1]=-1;
				   rmatind[temp3+1]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+j*(N+K)+i;
			   }
		   }
	   }
   }

   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+day*K*(N+K);
   coled=coled;
   nzed=nzed+2*day*K*(N+K)*(N+K);

   

   //第八条约束 (2)
   rownow=day*K*K;
   nznow=day*K*K*(N+K);

   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));

   for (int d=0;d<day;d++) 
   {
	   for (int o=0;o<K;o++)
	   {
		   for(int i=0;i<K;i++)
		   {
			   temp2=d*K*K+o*K+i;
			   rmatbeg[temp2] = (N+K)*temp2;
			   sense[temp2] = 'L';
			   if(i==o)
			   {
				   rhs[temp2]   = people[o][6+d];
			   }
			   else
			   {
				   rhs[temp2]   = 0;
			   }
		   
			   rowname[temp2]=new char[256];
			   sprintf(rowname[temp2],"c7_%d",temp2);
			   for (int j=0;j<(N+K);j++)
		       {
			       temp3=(N+K)*temp2+j;
			       rmatval[temp3]=1;
			       rmatind[temp3]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+i*(N+K)+(j);
		       }
		   }
	   }
   }

   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+day*K*K;
   coled=coled;
   nzed=nzed+day*K*K*N;

  
   //第九条约束 (2)
   rownow=day*K*K;
   nznow=day*K*K*(N+K);


   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));
   for (int d=0;d<day;d++) 
   {
	   for (int o=0;o<K;o++)
	   {
		   for(int i=0;i<K;i++)
		   {
			   temp2=d*K*K+o*K+i;
			   rmatbeg[temp2] = (N+K)*temp2;
			   sense[temp2] = 'L';
			   if(i==o)
			   {
				   rhs[temp2]   = people[o][6+d];
			   }
			   else
			   {
				   rhs[temp2]   = 0;
			   }
		   
			   rowname[temp2]=new char[256];
			   sprintf(rowname[temp2],"c8_%d",temp2);
			   for (int j=0;j<(N+K);j++)
		       {
			       temp3=(N+K)*temp2+j;
			       rmatval[temp3]=1;
			       rmatind[temp3]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+(j)*(N+K)+i;
		       }
		   }
	   }
   }
   

   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+day*K*K;
   coled=coled;
   nzed=nzed+day*K*K*N;
 
  

   //第十条约束 (9)
   rownow=day*K;
   nznow=day*K;


   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));

   for (int d=0;d<day;d++) 
   {
	   for (int i=0;i<K;i++)
	   {
		   temp2=d*K+i;
		   rmatbeg[temp2] = temp2;
		   sense[temp2] = 'E';
		   rhs[temp2]   =people[i][3];
		   rowname[temp2]=new char[256];
	       sprintf(rowname[temp2],"c9_%d",temp2);
		   rmatval[temp2]=1;
		   rmatind[temp2]=coled+d*(K+N)+i;
	   }
   }
   

   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+day*K;
   coled=coled;
   nzed=nzed+day*K;

   

   //第十一条约束(8)
   rownow=day*N;
   nznow=day*N;


   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));

   for (int d=0;d<day;d++) 
   {
	   for (int i=0;i<N;i++)
	   {
         temp2=d*N+i;
		   rmatbeg[temp2] = temp2;
		   sense[temp2] = 'G';
		   rhs[temp2]   =people[K+i][3];
		   rowname[temp2]=new char[256];
	       sprintf(rowname[temp2],"c10_%d",temp2);
		   rmatval[temp2]=1;
		   rmatind[temp2]=coled+d*(K+N)+(i+K);
	   }
   }
   

   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+day*N;
   coled=coled;
   nzed=nzed+day*N;

   //第十二条约束(8)
   rownow=day*N;
   nznow=day*N;


   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));

   for (int d=0;d<day;d++) 
   {
	   for (int i=0;i<N;i++)
	   {
         temp2=d*N+i;
		   rmatbeg[temp2] = temp2;
		   sense[temp2] = 'L';
		   rhs[temp2]   =people[K+i][4];
		   rowname[temp2]=new char[256];
	       sprintf(rowname[temp2],"c11_%d",temp2);
		   rmatval[temp2]=1;
		   rmatind[temp2]=coled+d*(K+N)+(i+K);
	   }
   }
   

   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+day*N;
   coled=coled;
   nzed=nzed+day*N;

   //第六条约束(6)

   rownow=day*K*K*N;
   nznow=2*day*K*K*N;


   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));

   for (int d=0;d<day;d++) 
   {
	   for (int o=0;o<K;o++)
	   {
		   for (int i=0;i<K;i++)
		   {
			   for (int j=0;j<N;j++)
			   {
				   temp2=d*N*K*K+j+o*N*K+i*N;
		           rmatbeg[temp2] = 2*temp2;
		           sense[temp2] = 'L';
		           rhs[temp2]   =people[i][4]+regulation-people[K+j][5]-travel[K+j][i]+M;
         	       rowname[temp2]=new char[256];
	               sprintf(rowname[temp2],"c5_%d",temp2);
				   rmatval[2*temp2]=1;
		           rmatind[2*temp2]=coled+d*(K+N)+(j+K);
			       rmatval[2*temp2+1]=M;
		           rmatind[2*temp2+1]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+(j+K)*(N+K)+i;
		       }   
		   }
	   }
   }
   

   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+day*K*(K)*N;
   coled=coled;
   nzed=nzed+2*day*K*K*N;
   


   //第十三条约束(7)

   rownow=day*K*(K+N)*N;
   nznow=3*day*K*(K+N)*N;


   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));

   for (int d=0;d<day;d++) 
   {
	   for (int o=0;o<K;o++)
	   {
		   for (int i=0;i<K+N;i++)
		   {
			   for (int j=0;j<N;j++)
			   {
				   temp2=d*N*K*(N+K)+j+o*N*(N+K)+i*N;
		           rmatbeg[temp2] = 3*temp2;
		           sense[temp2] = 'G';
		           rhs[temp2]   =people[i][5]+travel[i][K+j]-M;
         	       rowname[temp2]=new char[256];
	               sprintf(rowname[temp2],"c11_%d",temp2);
    	           rmatval[3*temp2]=-1;
				   rmatind[3*temp2]=coled+d*(K+N)+i;
				   rmatval[3*temp2+1]=1;
		           rmatind[3*temp2+1]=coled+d*(K+N)+(j+K);
			       rmatval[3*temp2+2]=-M;
		           rmatind[3*temp2+2]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+i*(N+K)+(j+K);
		       }   
		   }
	   }
   }
   

   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

   rowed=rowed+day*K*(K+N)*N;
   coled=coled;
   nzed=nzed+3*day*K*(K+N)*N;
 
  
   //第十四条约束 make x_{ii}^{od}=0
   rownow=day*K*(K+N);
   nznow=day*K*(K+N);


   rmatbeg = (int *) malloc (rownow * sizeof(int));
   rmatind  = (int *) malloc (nznow * sizeof(int));
   rmatval  = (double *) malloc (nznow * sizeof(double));
   rhs = (double *) malloc (rownow* sizeof(double));
   sense = (char *) malloc (rownow* sizeof(char));
   rowname = (char **) malloc (rownow * sizeof(char*));

   for (int d=0;d<day;d++) 
   {
	   for (int o=0;o<K;o++)
	   {
		   for (int i=0;i<K+N;i++)
		   {
			   temp2=d*K*(N+K)+o*(N+K)+i;
		       rmatbeg[temp2] = temp2;
		       sense[temp2] = 'E';
		       rhs[temp2]   =0;
			   rowname[temp2]=new char[256];
	           sprintf(rowname[temp2],"c14_%d",temp2);

			   rmatval[temp2]=1;
		       rmatind[temp2]=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+i*(N+K)+i;
		   }
	   }
   }
   
   

   status = CPXaddrows (env, lp, 0, rownow, nznow, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);

   if ( status )  
   {
      exit(-1);
   }
   free(rmatbeg);
   free(rmatind);
   free(rmatval);
   free(sense);
   free(rowname);
   free(rhs);

    

   rowed=rowed+day*K*(K+N);
   coled=coled;
   nzed=nzed+day*K*(K+N);




    

   rowed=rowed+day*K*(K+N);
   coled=coled;
   nzed=nzed+day*K*(K+N);
   cout<<"rowed"<<rowed<<endl;
   cout<<"nzed"<< nzed<<endl;

   cout<<"输出问题"<<endl;
   status=CPXwriteprob(env,lp,"PtreeLPModel.lp",NULL);
	if(status!=0) {
		printf("error in CPXwriteprob\n");
		exit(-1);
	}



   /* Optimize the problem and obtain solution. */

   status = CPXmipopt(env, lp);

   int lpstat=CPXgetstat(env,lp);
   cout<<"solution status\t"<<lpstat<<endl;


   if ( status ) {
      fprintf (stderr, "Failed to optimize LP.\n");
      exit(-1);
      //goto TERMINATE;
   }


   status = CPXgetobjval(env,lp,&sol);
   if ( status ) {
      fprintf (stderr, "Failed to obtain solution.\n");
      exit(-1);
     
   }

  // cout<<"objective value\t"<<sol<<endl;



   root_LP=sol;

   

   cur_numrows = CPXgetnumrows (env, lp);
   cur_numcols = CPXgetnumcols (env, lp);
   cout<<"cur_numrows"<<cur_numrows<<endl;
   cout<<"cur_numcols"<<cur_numcols<<endl;
   x=(double *) malloc (cur_numcols * sizeof(double));

   status = CPXgetmipx(env,lp,x,0,cur_numcols-1);

   for (int d=0;d<day;d++)
   {
	   for (int o=0;o<K;o++)
	   {
		   for (int i=0;i<N+K;i++)
		   {
			   for (int j=0;j<N+K;j++)
			   {
				   temp1=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+i*(N+K)+j;
				   if(x[temp1]>0)
				   {
					   cout<<"x"<<"_"<<d<<"_"<<o<<"_"<<i<<"_"<<j<<"="<<x[temp1]<<endl;
				   }
			   }
		   }
	   } 
   }
   for (int d=0;d<day;d++)
   {
	   cout<<"第"<<d<<"天"<<endl;
	   cout<<"--------------------"<<endl;
	   for (int o=0;o<K;o++)
	   {
		   cout<<"康复师"<<o<<"的出行路径为"<<endl;
		   int start=o;
		   cout<<start;
		   do
		   {
			   for (int i=0;i<N+K;i++)
			   {
				   temp1=d*K*(N+K)*(N+K)+o*(N+K)*(N+K)+start*(N+K)+i;
				   if(x[temp1]>0&&((start>=K||i>=K)||travel[start][i]>0))
				   {
					   start=i;
					   cout<<"--"<<start;
					   break;
				   }
			   }
		   }while(start!=o);
		   cout<<endl;
		   cout<<"--------"<<endl;
	   } 
	   cout<<"--------------------"<<endl;
	   cout<<endl;
   }
   int tempp;
   coled=day*K*(N+K)*(N+K)+N*K;
   for (int d=0;d<day;d++)
   {
	   cout<<"第"<<d<<"天"<<endl;
	   cout<<"--------------------"<<endl;
	   for (int i=0;i<N+K;i++)
	   {
		   tempp=d*(N+K)+i;
		   cout<<"S_"<<d<<"_"<<i<<"为"<<x[coled+tempp]<<endl;
	   }
   }

  
   /* Free up the problem as allocated by CPXcreateprob, if necessary */

   if ( lp != NULL ) {
      status = CPXfreeprob (env, &lp);
      if ( status ) {
         fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
      }
   }

   /* Free up the CPLEX environment, if necessary */

   if ( env != NULL ) {
      status = CPXcloseCPLEX (&env);

      /* Note that CPXcloseCPLEX produces no output,
         so the only way to see the cause of the error is to use
         CPXgeterrorstring.  For other CPLEX routines, the errors will
         be seen if the CPXPARAM_ScreenOutput indicator is set to CPX_ON. */

      if ( status ) {
         char  errmsg[CPXMESSAGEBUFSIZE];
         fprintf (stderr, "Could not close CPLEX environment.\n");
         CPXgeterrorstring (env, status, errmsg);
         fprintf (stderr, "%s", errmsg);
      }
   }
     
	cout<<"objective value\t"<<sol<<endl;
   return (status);
}


void master_free()
{
	/////////////////////////////////////////////////////////////
	for (int i=0;i<N+K;i++)
	{
		delete [] people[i]; 
	}
	delete [] people;

	for (int i=0;i<N+K;i++)
	{
	    delete [] travel[i];
	}
	delete [] travel;
}