﻿#include "global_functions.h"
#include "global_variables.h"
#include "bp_form.h"
#include <cstdio>


using namespace std;


int main(int argc,char** argv)
{

	data Homecare_instance;
	Homecare_instance.istname=(char*) calloc(2000,sizeof(char));
		
	Homecare_instance.distname=(char*) calloc(2000,sizeof(char));
	//cout<<"argc\t"<<argc<<endl;
	//int actual=0;
	
		

	strcpy(Homecare_instance.istname, argv[1]);

	Homecare_instance.option=atoi(argv[2]);


	if (Homecare_instance.option==1)
	{
		cout<<"this is the real-world data set testing\n";
		get_peo_info(Homecare_instance.istname);
	}
	else if (Homecare_instance.option==2) //liurandata
	{
		cout<<"this is the liu data set testing\n";
		get_distance_info(Homecare_instance.istname);
	}
	else if (Homecare_instance.option==3) //tsdata
	{
		
		cout<<"this is the TS data set testing\n";
		get_ts_info(Homecare_instance.istname);
		if(N+K==60)
		{
			strcpy(Homecare_instance.distname,"./HHCP_TSdata/distanceMatrix_60.txt");	
		}
		else if(N+K==70)
		{
			strcpy(Homecare_instance.distname,"./HHCP_TSdata/distanceMatrix_70.txt");	
		}
		else
		{
			exit(-1);
		}
		get_ts_info_travel(Homecare_instance.distname);
	}			
	
	else if (Homecare_instance.option==0) 
	{
		cout<<"this is the standard data set testing\n";
		get_standard_info(Homecare_instance.istname);
	}
	else if (Homecare_instance.option==4) 
	{
		cout<<"this is the Solomon data set testing\n";
		get_peo_info(Homecare_instance.istname);
	}

	
	get_discrete_points();
	

	//cout<<"after stdinfo construction\n";

	if (Homecare_instance.option==1)
	{
		get_travel();
	}
	else if (Homecare_instance.option==0) 
	{
		get_standard_travel();
	}
	else if (Homecare_instance.option==4) 
	{
		get_standard_travel();
	}



	//output();



	//cout<<"after data construction\n";
	Homecare_instance.start_time=time(NULL);
	
	master_build();
	
	int level=0;
	int outcome=branch_and_price(&Homecare_instance,level);

	cout<<"solution_return_"<<outcome<<endl;

	//out_routes();

	EvaluateSolution();


	if (outcome!=0)
	{
		travel_free();
	}
	master_free();
	
	Homecare_instance.stop_time=time(NULL);
	double duration =(double) difftime(Homecare_instance.stop_time,Homecare_instance.start_time);

	cout<<"run time is "<<duration<<endl;
	cout<<"assigned_cuts_number"<<assigned_cuts_global[0].size()<<endl;
	return 1;
}
