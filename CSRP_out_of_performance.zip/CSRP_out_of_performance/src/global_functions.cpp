﻿#include "global_functions.h"

//TODO: in the global function, just to initializae some data
//For example, the travel matrix, distance computing


float max(float a , float b)

{

if( a > b) return a;

return b;

}

double Random()
{
	return 1.0*rand()/RAND_MAX;
}

double check_reg()
{
	double time_regulation=0;
	for(int index_i=K;index_i<N+K;index_i++)
	{
		for(int o=0;o<K;o++)
		{
			if(people[index_i][4]+people[index_i][5]+travel[index_i][o]>time_regulation)
			{
				time_regulation=people[index_i][4]+people[index_i][5]+travel[index_i][o];
				if(time_regulation>regulation)
				{
					return regulation;
				}
			}
		}
	}
	return time_regulation;
}

void get_distance_info(char* filename)
{
	ifstream srcFile1(filename,ios::in); //以文本模式打开txt备读
    if(!srcFile1) 
	{ //打开失败
		cout << "error opening source file." << endl;
  	    exit (-1);
  	}

	int y;
	double x;
	srcFile1 >>y ;
	day=y;
	day=1;
	srcFile1 >>y ;
	K=y;
	srcFile1 >>y ;
	N=y;
	srcFile1 >>y ;
	Q=y;
	srcFile1 >>y ;
	P=y;
	srcFile1 >>x ;
	regulation=x;

	people = new double* [N+K];
	for (int i=0;i<N+K;i++)
	{
		people[i] = new double[7+day+P];
	}

	travel = new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
	    travel[i] = new double[N+K];
	}
	for(int j=0;j<N+2;j++)
	{
		srcFile1 >> x;
	}
	for(int i=K;i<N+K;i++)
	{
		srcFile1 >> x;
		for(int j=K;j<N+K;j++)
		{
			srcFile1 >> x;
			travel[i][j]=x;
		}
		srcFile1 >> x;
	}
	for(int j=0;j<N+2;j++)
	{
		srcFile1 >> x;
	}
	for(int i=0;i<K;i++)
	{
		srcFile1 >> x;
		for(int j=K;j<N+K;j++)
		{
			srcFile1 >> x;
			travel[i][j]=x;
			travel[j][i]=x;
		}
		srcFile1 >> x;
	}

	for(int i=K;i<N+K;i++)
	{
		srcFile1 >> x;
		people[i][5]=x;
	}

	for(int i=K;i<N+K;i++)
	{
		srcFile1 >> x;
		people[i][3]=x;
		srcFile1 >> x;
		people[i][4]=x;
	}

   	srcFile1.close();
	//cout << "input successfully" << endl;

	for (int i=0;i<K;i++)
	{
		people[i][0]=i;
		people[i][1]=0;
		people[i][2]=0;
		people[i][3]=0;
		people[i][4]=0;
		people[i][5]=0;
		for(int d=0;d<day;d++)
		{
			people[i][6+d]=1;
		}
		people[i][5+day+P]=1;
		people[i][6+day+P]=N;
	}
	for (int i=K;i<N+K;i++)
	{
		people[i][0]=i;
		people[i][1]=0;
		people[i][2]=0;
		for(int d=0;d<day;d++)
		{
			people[i][6+d]=1;
		}
		people[i][5+day+P]=1;
		people[i][6+day+P]=1;
	}

	daytravel = new double**[day];
	for(int d=0; d<day; d++)
	{
		daytravel[d] = new double*[N+K];
		for (int i=0;i<N+K;i++)
		{
			daytravel[d][i] = new double[N+K];
		}
	}

	tempdaytravel = new double**[day];
	for(int d=0; d<day; d++)
	{
		tempdaytravel[d] = new double*[N+K];
		for (int i=0;i<N+K;i++)
		{
			tempdaytravel[d][i] = new double[N+K];
		}
	}
	
	daydoctravel = new double***[day];
	for(int d=0; d<day; d++)
	{
		daydoctravel[d] = new double**[K];
		for (int o=0;o<K;o++)
		{
			daydoctravel[d][o] = new double*[N+K];
			for (int i=0;i<N+K;i++)
			{
				daydoctravel[d][o][i] = new double[N+K];
			}
		}
	}

	extra_routes = new double[N+K+1];

	costs_sum= new double*[K];
	for (int i=0;i<K;i++)
	{
		costs_sum[i] = new double[6];
	}
	
	sharev= new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
		sharev[i] = new double[3];
	}

	sharevi= new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
		sharevi[i] = new double[3];
	}

	routes = new int*[K];
	for (int i=0;i<K;i++)
	{
		routes[i] = new int[N+2+2];
	}

	routes_time = new double*[K];
	for (int i=0;i<K;i++)
	{
		routes_time[i] = new double[N+2+2];
		for(int j=0;j<N+2+2;j++)
		{
			routes_time[i][j]=0; 
		}
	}

	sequence = new int[N];
	for (int i=0;i<N;i++)
	{
		sequence[i] = 0;
	}

	tempK = new int*[day];
	for(int d=0; d<day; d++)
	{
		tempK[d] = new int[K];
		for (int i=0;i<K;i++)
		{
			tempK[d][i] = 0;
		}
	}

	tempnumK= new int[day];
	for(int d=0; d<day; d++)
	{
		tempnumK[d] = 0;
	}

	tempN = new int*[day];
	for(int d=0; d<day; d++)
	{
		tempN[d] = new int[N];
		for (int i=0;i<N;i++)
		{
			tempN[d][i] = 0;
		}
	}

	tempnumN = new int[day];//new_added 
	for(int d=0; d<day; d++)
	{
		tempnumN[d] = 0;
	}
	places = new double**[N+K];
	for (int i=0;i<N+K;i++)
	{
		places[i] = new double*[N+K];
		for (int j=0;j<N+K;j++)
		{
			places[i][j]=new double [3];
			for (int k=0;k<3;k++)
			{
				places[i][j][k]=0;
			}
		}
	}
	


	consist_N_to_K = new int[N+K];
	for (int i=0;i<N+K;i++)
	{
		consist_N_to_K[i] = -1;
	}





	constraints[0] = day*N;
	constraints[1] = day*K;
	constraints[2] = N;
	constraints[3] = day*N*K;

	ofstream destFile2("travel.txt",ios::out); //以文本模式打开txt备写,若文件已存在则清空原内容
    if(!destFile2) 
	{
		destFile2.close(); //程序结束前不能忘记关闭以前打开过的文件
		exit (-1);
	}
	for(int i = 0; i < N+K;i++)
	{
		for(int j = 0; j < N+K;j++)
		{
			destFile2 <<travel[i][j]<< "\t"; 
		}
		destFile2 <<"\n";
	}
	destFile2.close();
	//cout<<"successfully get travel_cost"<<endl;
}



void get_ts_info_travel(char* filename1)
{
	double x;

	ifstream srcFile2(filename1,ios::in); //以文本模式打开txt备读
	//srcFile2.open(filename1);
	//cout<<filename1<<endl;
	//cerr << "Error: " << strerror(errno);
  	    if(!srcFile2) { //打开失败
    	    cout << "error opening source file2." << endl;
  	        exit (-1);
  	    }

	

	travel = new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
	    travel[i] = new double[N+K];
		for (int j=0;j<N+K;j++)
		{
			srcFile2 >>x ; //可以像用cin那样用ifstream对象
			travel[i][j]=x;	
		}
	}
	srcFile2.close();
	//cout << "input travel successfully" << endl;

}


void get_ts_info(char* filename)
{
	
	
	ifstream srcFile1(filename,ios::in); //以文本模式打开txt备读
  	    if(!srcFile1) { //打开失败
    	    cout << "error opening source file." << endl;
  	        exit (-1);
  	    }
	//0 for sequence 1/2 for position, 3 time window, 4 for service time, 5待添加, 6-5+day表示pattern，5+day+P+表示服务等级和偏好
	//cout<<"filename\t"<<filename<<endl;
	int y;
	double x;
	srcFile1 >>y ;
	day=y;
	srcFile1 >>y ;
	K=y;
	srcFile1 >>y ;
	N=y;
	srcFile1 >>y ;
	Q=y;
	srcFile1 >>y ;
	P=y;
	srcFile1 >>x ;
	regulation=x;

	people = new double* [N+K];
	for (int i=0;i<N+K;i++)
	{
		people[i] = new double[7+day+P];
		for (int j=0;j<7+day+P;j++)
		{
			
			srcFile1 >>x ; //可以像用cin那样用ifstream对象
			people[i][j]=x;	
		}	 
	}
   	srcFile1.close();
	//cout << "input people successfully" << endl;



	daytravel = new double**[day];
	for(int d=0; d<day; d++)
	{
		daytravel[d] = new double*[N+K];
		for (int i=0;i<N+K;i++)
		{
			daytravel[d][i] = new double[N+K];
		}
	}

	tempdaytravel = new double**[day];
	for(int d=0; d<day; d++)
	{
		tempdaytravel[d] = new double*[N+K];
		for (int i=0;i<N+K;i++)
		{
			tempdaytravel[d][i] = new double[N+K];
		}
	}
	
	daydoctravel = new double***[day];
	for(int d=0; d<day; d++)
	{
		daydoctravel[d] = new double**[K];
		for (int o=0;o<K;o++)
		{
			daydoctravel[d][o] = new double*[N+K];
			for (int i=0;i<N+K;i++)
			{
				daydoctravel[d][o][i] = new double[N+K];
			}
		}
	}

	extra_routes = new double[N+K+1];

	costs_sum= new double*[K];
	for (int i=0;i<K;i++)
	{
		costs_sum[i] = new double[6];
	}
	
	sharev= new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
		sharev[i] = new double[3];
	}

	sharevi= new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
		sharevi[i] = new double[3];
	}

	routes = new int*[K];
	for (int i=0;i<K;i++)
	{
		routes[i] = new int[N+2+2];
	}

	routes_time = new double*[K];
	for (int i=0;i<K;i++)
	{
		routes_time[i] = new double[N+2+2];
		for(int j=0;j<N+2+2;j++)
		{
			routes_time[i][j]=0; 
		}
	}

	sequence = new int[N];
	for (int i=0;i<N;i++)
	{
		sequence[i] = 0;
	}

	tempK = new int*[day];//new_added for every tempK in this .cpp

	for(int d=0; d<day; d++)
	{
		tempK[d] = new int[K];
		for (int i=0;i<K;i++)
		{
			tempK[d][i] = 0;
		}
	}

	tempnumK = new int[day];//new_added 
	for(int d=0; d<day; d++)
	{
		tempnumK[d] = 0;
	}

	tempN = new int*[day];//new_added for every tempK in this .cpp

	for(int d=0; d<day; d++)
	{
		tempN[d] = new int[N];
		for (int i=0;i<N;i++)
		{
			tempN[d][i] = 0;
		}
	}

	tempnumN = new int[day];//new_added 
	for(int d=0; d<day; d++)
	{
		tempnumN[d] = 0;
	}

	places = new double**[N+K];

	for (int i=0;i<N+K;i++)
	{
		places[i] = new double*[N+K];
		for (int j=0;j<N+K;j++)
		{
			places[i][j]=new double [3];
			for (int k=0;k<3;k++)
			{
				places[i][j][k]=0;
			}
		}
	}

	consist_N_to_K = new int[N+K];
	for (int i=0;i<N+K;i++)
	{
		consist_N_to_K[i] = -1;
	}

	constraints[0] = day*N;
	constraints[1] = day*K;
	constraints[2] = N;
	constraints[3] = day*N*K;


}





void get_standard_info(char* filename)
{
	ifstream srcFile1(filename,ios::in); //以文本模式打开txt备读
  	    if(!srcFile1) { //打开失败
    	    cout << "error opening source file." << endl;
  	        exit (-1);
  	    }

	int y;
	int depot_combination;
	double x;

	double capacity;
	int vehicle;
	int depot;
	srcFile1 >>y ;
	srcFile1 >>y ;
	vehicle=y;
	srcFile1 >>y ;
	N=y;
	srcFile1 >>y ;
	depot=y;
	K=depot*vehicle;
	day=1;
	P=1;
	Q=1;
	
	for (int i=0;i<depot;i++)
	{
		srcFile1 >>x;
		//regulation=x;
		srcFile1 >>x;
		capacity=x;
	}



	people = new double* [N+K];
	for (int i=0;i<N+K;i++)
	{
		people[i] = new double[7+day+P];
	}

	for (int i=0;i<N;i++)
	{
		srcFile1 >>y; //1
		people[K+y-1][0]=K+y-1;	
		
		srcFile1 >>x; //2
		people[K+y-1][1]=x;	

		srcFile1 >>x; //3
		people[K+y-1][2]=x;	

		srcFile1 >>x; //4
		people[K+y-1][5]=x;	

		srcFile1 >>x; //5
		people[K+y-1][6+day+P]=x;	

		srcFile1 >>x; //6

		srcFile1 >>depot_combination; //7
		for(int j=0;j<depot_combination;j++)
		{
			srcFile1 >>x;
		}
		//srcFile1 >>x; //8
		//srcFile1 >>x; //9
		//srcFile1 >>x; //10
		//srcFile1 >>x; //11

		srcFile1 >>x; //12
		people[K+y-1][3]=x;	
		srcFile1 >>x; //13
		people[K+y-1][4]=x;	

		people[K+y-1][6]=1;
		people[K+y-1][7]=1;
	}

	for (int i=0;i<depot;i++)
	{
		srcFile1 >>y; //1
		for(int j=0;j<vehicle;j++)
		{
			people[vehicle*(y-N-1)+j][0]=vehicle*(y-N-1)+j;	
		}
		srcFile1 >>x; //2
		for(int j=0;j<vehicle;j++)
		{
			people[vehicle*(y-N-1)+j][1]=x;	
		}	
		srcFile1 >>x; //3
		for(int j=0;j<vehicle;j++)
		{
			people[vehicle*(y-N-1)+j][2]=x;	
			people[vehicle*(y-N-1)+j][3]=0;	
			people[vehicle*(y-N-1)+j][4]=0;	
			people[vehicle*(y-N-1)+j][5]=0;	
			people[vehicle*(y-N-1)+j][6]=1;	
			people[vehicle*(y-N-1)+j][7]=1;	
			people[vehicle*(y-N-1)+j][8]=capacity;	
		}	

		srcFile1 >>x; //4
		srcFile1 >>x; //5
		srcFile1 >>x; //6
		srcFile1 >>x; //7
		srcFile1 >>x; //8
		srcFile1 >>x; //9
		regulation=x;

	}
   	srcFile1.close();

	//cout << "input successfully" << endl;

	travel = new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
	    travel[i] = new double[N+K];
	}

	daytravel = new double**[day];
	for(int d=0; d<day; d++)
	{
		daytravel[d] = new double*[N+K];
		for (int i=0;i<N+K;i++)
		{
			daytravel[d][i] = new double[N+K];
		}
	}

	tempdaytravel = new double**[day];
	for(int d=0; d<day; d++)
	{
		tempdaytravel[d] = new double*[N+K];
		for (int i=0;i<N+K;i++)
		{
			tempdaytravel[d][i] = new double[N+K];
		}
	}
	
	daydoctravel = new double***[day];
	for(int d=0; d<day; d++)
	{
		daydoctravel[d] = new double**[K];
		for (int o=0;o<K;o++)
		{
			daydoctravel[d][o] = new double*[N+K];
			for (int i=0;i<N+K;i++)
			{
				daydoctravel[d][o][i] = new double[N+K];
			}
		}
	}

	extra_routes = new double[N+K+1];

	costs_sum= new double*[K];
	for (int i=0;i<K;i++)
	{
		costs_sum[i] = new double[6];
	}
	
	sharev= new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
		sharev[i] = new double[6];
	}

	sharevi= new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
		sharevi[i] = new double[6];
	}

	routes = new int*[K];
	for (int i=0;i<K;i++)
	{
		routes[i] = new int[N+2+2];
	}

	routes_time = new double*[K];
	for (int i=0;i<K;i++)
	{
		routes_time[i] = new double[N+2+2];
		for(int j=0;j<N+2+2;j++)
		{
			routes_time[i][j]=0; 
		}
	}

	sequence = new int[N];
	for (int i=0;i<N;i++)
	{
		sequence[i] = 0;
	}

	tempK = new int*[day];

	for(int d=0; d<day; d++)
	{
		tempK[d] = new int[K];
		for (int i=0;i<K;i++)
		{
			tempK[d][i] = 0;
		}
	}

	tempnumK = new int[day];
	for(int d=0; d<day; d++)
	{
		tempnumK[d] = 0;
	}
	tempN = new int*[day];
	for(int d=0; d<day; d++)
	{
		tempN[d] = new int[N];
		for (int i=0;i<N;i++)
		{
			tempN[d][i] = 0;
		}
	}

	tempnumN = new int[day];//new_added 
	for(int d=0; d<day; d++)
	{
		tempnumN[d] = 0;
	}
	places = new double**[N+K];
	for (int i=0;i<N+K;i++)
	{
		places[i] = new double*[N+K];
		for (int j=0;j<N+K;j++)
		{
			places[i][j]=new double [3];
			for (int k=0;k<3;k++)
			{
				places[i][j][k]=0;
			}
		}
	}

	consist_N_to_K = new int[N+K];
	for (int i=0;i<N+K;i++)
	{
		consist_N_to_K[i] = -1;
	}

	constraints[0] = day*N;
	constraints[1] = day*K;
	constraints[2] = N;
	constraints[3] = day*N*K;
}


void get_peo_info(char* filename)
{
	/*
    ifstream srcFile1(filename,ios::in); //以文本模式打开txt备读
  	    if(!srcFile1) { //打开失败
    	    cout << "error opening source file." << endl;
  	        exit (-1);
  	    }
	//0 for sequence 1/2 for position, 3 time window, 4 for service time, 5待添加, 6-5+day表示pattern，5+day+P+表示服务等级和偏好
	double x;
	for (int i=0;i<N+K;i++)
	{
		for (int j=0;j<7+day+P;j++)
		{
			srcFile1 >>x ; //可以像用cin那样用ifstream对象
			people[i][j]=x;	
		}	 
	}
   	srcFile1.close();
	cout << "input successfully" << endl;
	*/


	
	ifstream srcFile1(filename,ios::in); //以文本模式打开txt备读
  	    if(!srcFile1) { //打开失败
    	    cout << "error opening source file." << endl;
  	        exit (-1);
  	    }
	//0 for sequence 1/2 for position, 3 time window, 4 for service time, 5待添加, 6-5+day表示pattern，5+day+P+表示服务等级和偏好
	int y;
	double x;
	srcFile1 >>y ;
	day=y;
	srcFile1 >>y ;
	K=y;
	srcFile1 >>y ;
	N=y;
	srcFile1 >>y ;
	Q=y;
	srcFile1 >>y ;
	P=y;
	srcFile1 >>x ;
	regulation=x;

	people = new double* [N+K];
	for (int i=0;i<N+K;i++)
	{
		people[i] = new double[7+day+P];
		for (int j=0;j<7+day+P;j++)
		{
			
			srcFile1 >>x ; //可以像用cin那样用ifstream对象
			people[i][j]=x;	
		}	 
	}
   	srcFile1.close();
	//cout << "input successfully" << endl;

	travel = new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
	    travel[i] = new double[N+K];
	}

	daytravel = new double**[day];
	for(int d=0; d<day; d++)
	{
		daytravel[d] = new double*[N+K];
		for (int i=0;i<N+K;i++)
		{
			daytravel[d][i] = new double[N+K];
		}
	}

	tempdaytravel = new double**[day];
	for(int d=0; d<day; d++)
	{
		tempdaytravel[d] = new double*[N+K];
		for (int i=0;i<N+K;i++)
		{
			tempdaytravel[d][i] = new double[N+K];
		}
	}
	
	daydoctravel = new double***[day];
	for(int d=0; d<day; d++)
	{
		daydoctravel[d] = new double**[K];
		for (int o=0;o<K;o++)
		{
			daydoctravel[d][o] = new double*[N+K];
			for (int i=0;i<N+K;i++)
			{
				daydoctravel[d][o][i] = new double[N+K];
			}
		}
	}

	extra_routes = new double[N+K+1];

	costs_sum= new double*[K];
	for (int i=0;i<K;i++)
	{
		costs_sum[i] = new double[6];
	}
	
	sharev= new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
		sharev[i] = new double[3];
	}

	sharevi= new double*[N+K];
	for (int i=0;i<N+K;i++)
	{
		sharevi[i] = new double[3];
	}

	routes = new int*[K];
	for (int i=0;i<K;i++)
	{
		routes[i] = new int[N+2+2];
	}

	routes_time = new double*[K];
	for (int i=0;i<K;i++)
	{
		routes_time[i] = new double[N+2+2];
		for(int j=0;j<N+2+2;j++)
		{
			routes_time[i][j]=0; 
		}
	}

	sequence = new int[N];
	for (int i=0;i<N;i++)
	{
		sequence[i] = 0;
	}

	tempK = new int*[day];

	for(int d=0; d<day; d++)
	{
		tempK[d] = new int[K];
		for (int i=0;i<K;i++)
		{
			tempK[d][i] = 0;
		}
	}

	tempnumK = new int[day];
	for(int d=0; d<day; d++)
	{
		tempnumK[d] = 0;
	}

	tempN = new int*[day];
	for(int d=0; d<day; d++)
	{
		tempN[d] = new int[N];
		for (int i=0;i<N;i++)
		{
			tempN[d][i] = 0;
		}
	}

	tempnumN = new int[day];//new_added 
	for(int d=0; d<day; d++)
	{
		tempnumN[d] = 0;
	}

	places = new double**[N+K];
	for (int i=0;i<N+K;i++)
	{
		places[i] = new double*[N+K];
		for (int j=0;j<N+K;j++)
		{
			places[i][j]=new double [3];
			for (int k=0;k<3;k++)
			{
				places[i][j][k]=0;
			}
		}
	}

	consist_N_to_K = new int[N+K];
	for (int i=0;i<N+K;i++)
	{
		consist_N_to_K[i] = -1;
	}


	constraints[0] = day*N;
	constraints[1] = day*K;
	constraints[2] = N;
	constraints[3] = day*N*K;
	//cout << "input successfully" << endl;
}

void output()
{
	ofstream destFile_r("output.txt",ios::out); //以文本模式打开txt备写,若文件已存在则清空原内容
    if(!destFile_r) 
	{
		destFile_r.close(); //程序结束前不能忘记关闭以前打开过的文件
		exit (-1);
	}
	for (int i=0;i<N+K;i++)
	{
		for (int j=0;j<7+day+P;j++)
		{
			destFile_r <<people[i][j]<< " "; 
				
		}	 
		destFile_r <<"\n";
	}

	destFile_r.close();

	//cout << "output successfully" << endl;
}

void get_routes()
{
	ifstream srcFile("routes.txt",ios::in); //以文本模式打开txt备读
  	if(!srcFile) //打开失败
	{ 
    	cout << "error opening source file." << endl;
  	    exit (-1);
  	}
	srcFile >>R ;
	Routes = new double*[R];
	for (int row=0;row<R;row++)
	{
		Routes[row]=new double [N+K+1];
		for(int col=0;col<N+K+1;col++)
		{
			srcFile>>Routes[row][col];
		}
	}
	cout << "get routes successfully" << endl;
	
	for (int row=0;row<R;row++)
	{
		delete [] Routes[row];
	}
	delete [] Routes;
}


double round(double r)
{
    return (r > 0.0) ? floor(r + 0.5) : ceil(r - 0.5);
}

double round2(double f)
{

    int a = (int)f;
    //获取十分位部分
    int b = (int)(f*10)%10;
    //获取百分位部分
    int c = (int)(f*100)%10;
    //获取千分位部分
    int d = (int)(f*1000)%10;
    
    //判断千分位是否大于等于5
    if (d >= 5) {
        //是，百分位进一位
        c ++;
    }
    
    //乘以系数后相加
    double e = a + b*0.1 + c*0.01;
    
    return e;
}

double get_distance(double lng1, double lat1, double lng2, double lat2)
{
	double radLat1 = lat1 * PI / 180.0;   //角度1˚ = π / 180
	double radLat2 = lat2 * PI / 180.0;   //角度1˚ = π / 180
	double a = radLat1 - radLat2;//纬度之差
	double b = lng1 * PI / 180.0 - lng2* PI / 180.0;  //经度之差k
	double dst = 2 * asin((sqrt(pow(sin(a / 2), 2) + cos(radLat1) * cos(radLat2) * pow(sin(b / 2), 2))));
	dst = dst * EARTH_RADIUS;
	dst=round(2*dst);
	return dst;
}

double get_distance_2(double x1, double y1, double x2, double y2)
{
	double dst = sqrt(pow((x1-x2)*1.0,2) + pow((y1-y2)*1.0,2));
	dst=round2(dst);
	return dst;
}

void get_standard_travel()
{
	for (int i=0;i<N+K-1;i++)
	{
		travel[0][0]=0;
		for (int j=i;j<N+K;j++)
		{
			travel[j][j]=0;
			double tempD=get_distance_2(people[i][1],people[i][2],people[j][1],people[j][2]);
			if(i!=j)
			{
				travel[i][j]=tempD;
				travel[j][i]=tempD;
			}
		}
	}
	ofstream destFile2("travel.txt",ios::out); //以文本模式打开txt备写,若文件已存在则清空原内容
    if(!destFile2) 
	{
		destFile2.close(); //程序结束前不能忘记关闭以前打开过的文件
		exit (-1);
	}
	for(int i = 0; i < N+K;i++)
	{
		for(int j = 0; j < N+K;j++)
		{
			destFile2 <<travel[i][j]<< "\t"; 
		}
		destFile2 <<"\n";
	}
	destFile2.close();
	//cout<<"successfully get travel_cost"<<endl;
}


void get_travel()
{
	for (int i=0;i<N+K-1;i++)
	{
		travel[0][0]=0;
		for (int j=i;j<N+K;j++)
		{
			travel[j][j]=0;
			double tempD=get_distance(people[i][1],people[i][2],people[j][1],people[j][2]);
			if(i!=j)
			{
				travel[i][j]=tempD;
				travel[j][i]=tempD;
			}
		
		}
	}
	ofstream destFile2("travel.txt",ios::out); //以文本模式打开txt备写,若文件已存在则清空原内容
    if(!destFile2) 
	{
		destFile2.close(); //程序结束前不能忘记关闭以前打开过的文件
		exit (-1);
	}
	for(int i = 0; i < N+K;i++)
	{
		for(int j = 0; j < N+K;j++)
		{
			destFile2 <<travel[i][j]<< "\t"; 
		}
		destFile2 <<"\n";
	}
	destFile2.close();
	//cout<<"successfully get travel_cost"<<endl;
}

int calWS(int rownow)
{
	int rowweishu=0;
	int temprow=rownow;
	while(temprow!=0)
	{
		rowweishu++;
		temprow = temprow/10;
	}
	return rowweishu;
}





void get_Bounds()
{

	m_time_lb.clear();
	m_time_ub.clear();
	m_time_lb.resize(N+K, vector< double >(N+K, 0));
	m_time_ub.resize(N+K, vector< double >(N+K, 0));
	m_time_std.clear();
	m_time_std.resize(N+K, vector< double >(N+K, 0));

	m_service_lb.clear();
	m_service_ub.clear();
	m_service_lb.resize(N+K, 0);
	m_service_ub.resize(N+K, 0);
	m_service_std.clear();
	m_service_std.resize(N+K, 0);


    if (DISTRIBUTION == 1)	// uniform
	{
		for(int i=0;i<N+K;i++)
		{
			for (int j=0;j<N+K;j++)
			{
				m_time_lb[i][j] = travel[i][j]*(1-appro_v);
				m_time_ub[i][j] = travel[i][j]*(1+appro_v);
			}
			m_service_lb[i] = people[i][5]*(1-appro_v);
			m_service_ub[i] = people[i][5]*(1+appro_v);
			//double appro_inter_ser=people[i][5]*appro_v/L;
		}
	}

    else if (DISTRIBUTION == 2)	// two-point
	{
		double minCv = 0.1;
		double maxCv = 0.5;
		double stdRatio;
		double std;
		double r;

		for(int i=0;i<N+K;i++)
		{
			for (int j=0;j<N+K;j++)
			{
				stdRatio = minCv + Random() * (maxCv - minCv);
				m_time_std[i][j]=travel[i][j] * stdRatio;
				std=m_time_std[i][j];
				r = 2.0 / sqrt(3.0) * std / travel[i][j];
				m_time_lb[i][j] = (1 - r / 2.0) * travel[i][j];
				m_time_ub[i][j] = (1 + 3.0 * r / 2.0) * travel[i][j];
				//two-point, 0.75 for lb, 0.25 for ub
			}
			stdRatio = minCv + Random() * (maxCv - minCv);
			std =people[i][5] * stdRatio;
			r = 2.0 / sqrt(3.0) * std/ people[i][5];
			m_service_lb[i] = (1 - r / 2.0) * people[i][5];
			m_service_ub[i] = (1 + 3.0 * r / 2.0) * people[i][5];
		}
	}


	else if (DISTRIBUTION == 3)// triangle
	{
		double minCv = 0.1;
		double maxCv = 0.5;
		double stdRatio;
		double std;

		double delta;

		for(int i=0;i<N+K;i++)
		{
			for (int j=0;j<N+K;j++)
			{
				stdRatio = minCv + Random() * (maxCv - minCv);
				m_time_std[i][j] =travel[i][j] * stdRatio;
				std=m_time_std[i][j];
				delta =std * sqrt(18.0 / 13.0);
				m_time_lb[i][j] =  travel[i][j] - 5.0 / 3.0 * delta;
				m_time_ub[i][j] =  travel[i][j] + 7.0 / 3.0 * delta;
			}

			stdRatio = minCv + Random() * (maxCv - minCv);
			m_service_std[i]= people[i][5] * stdRatio;
			std=m_service_std[i];
			delta =std * sqrt(18.0 / 13.0);
			m_service_lb[i] = people[i][5] - 5.0 / 3.0 * delta;
			m_service_ub[i] = people[i][5] + 7.0 / 3.0 * delta;

		}
	}

	// cout<<people[10][5]<<endl;
	// for (int index=0;index<L;index++)
	// {
	// 	cout<< service_points[10][index]<<" ";
	// 	cout<<endl;
	// }
	// exit(-1);

    else
	{
		cout << "Error: DISTRIBUTION assignment error." << endl;
		exit(-1);
	}

	cout<<"get_discrete_points()"<<endl;
	
	
}


double GenerateSample(int c1, int c2)
{
	double lb = m_time_lb[c1][c2];
	double ub = m_time_ub[c1][c2];
	double mean = travel[c1][c2];
	if (ub - lb < eps)
		return ub;
	double sampleTime = 0;
	if (DISTRIBUTION == 1)	// uniform
	{
		sampleTime = lb + Random() * (ub - lb);
	}
	else if (DISTRIBUTION == 2)
	{
		if (Random() < (ub - mean) / (ub - lb))
		{
			sampleTime = lb;
		}
		else
		{
			sampleTime = ub;
		}
	}
	else if (DISTRIBUTION == 3)
	{
		double rnd = Random();
		double delta = m_time_std[c1][c2] * sqrt(18.0 / 13.0);
		double mode = mean - 2.0 / 3.0 * delta;
		double prob_threshould = (mode - lb) / (ub - lb);
		if (rnd <= prob_threshould)
		{
			sampleTime = sqrt(rnd * (ub - lb) * (mode - lb)) + lb;
		}
		else
		{
			sampleTime = ub - sqrt((1 - rnd) * (ub - lb) * (ub - mode));
		}
	}
    else
	{
		cout << "Error: DISTRIBUTION assignment error." << endl;
	}

	return sampleTime;
}


double GenerateSample(int c1)
{
	double lb = m_service_lb[c1];
	double ub = m_service_ub[c1];
	double mean = people[c1][5];
	if (ub - lb < eps)
		return ub;
	double sampleTime = 0;
	if (DISTRIBUTION == 1)	// uniform
	sampleTime = lb + Random() * (ub - lb);
    else if (DISTRIBUTION == 2)
	{
		if (Random() < (ub - mean) / (ub - lb))
		{
			sampleTime = lb;
		}
		else
		{
			sampleTime = ub;
		}
	}
    else if (DISTRIBUTION == 3)
	{
		double rnd = Random();
		double delta = m_service_std[c1] * sqrt(18.0 / 13.0);
		double mode = mean - 2.0 / 3.0 * delta;
		double prob_threshould = (mode - lb) / (ub - lb);
		if (rnd <= prob_threshould)
		{
			sampleTime = sqrt(rnd * (ub - lb) * (mode - lb)) + lb;
		}
		else
		{
			sampleTime = ub - sqrt((1 - rnd) * (ub - lb) * (ub - mode));
		}
	}
    else
	{
		cout << "Error: DISTRIBUTION assignment error." << endl;
	}



	return sampleTime;
}



void GenerateSampleTime()
{
	m_saa_time.clear();
	m_saa_time.resize(m_saa_number, vector< vector<double> >(N+K, vector< double >(N+K, 0)));

	for(int i = 0; i < m_saa_number; ++i)
	{
		for (int c1 = 0; c1 < N+K; ++c1)
		{
			for (int c2 = c1+1; c2 < N+K; ++c2)
			{
				m_saa_time[i][c1][c2] = GenerateSample(c1, c2);
				m_saa_time[i][c2][c1] = m_saa_time[i][c1][c2];
			}
		}
	}

	m_saa_service.clear();
	m_saa_service.resize(m_saa_number,vector< double >(N+K, 0));

	for(int i = 0; i < m_saa_number; ++i)
	{
		for (int c1 = 0; c1 < N+K; ++c1)
		{
			m_saa_service[i][c1]= GenerateSample(c1);
		}
	}
}

// void out_routes()
// {
// 	ofstream destFile("routes.txt",ios::out); //以文本模式打开txt备写,若文件已存在则清空原内容
//     if(!destFile) 
// 	{
// 		destFile.close(); //程序结束前不能忘记关闭以前打开过的文件
// 		exit (-1);
// 	}
// 	for(int it = 0; it != ROUTES.size();it++)
// 	{
// 		for (int i=0;i<N+K;i++)
// 		{
// 			destFile <<ROUTES[it][i]<< " "; 
// 		}
// 		destFile <<ROUTES_COST[it]<< " "; 
// 		destFile <<"\n";
// 	}
// 	destFile.close();

// 	ofstream destFile1("routes_seq.txt",ios::out); //以文本模式打开txt备写,若文件已存在则清空原内容
//     if(!destFile1) 
// 	{
// 		destFile1.close(); //程序结束前不能忘记关闭以前打开过的文件
// 		exit (-1);
// 	}
// 	for(int it = 0; it != ROUTES_SEQ.size();it++)
// 	{
// 		for (int i=0;i<N+2;i++)
// 		{
// 			destFile1 <<ROUTES_SEQ[it][i]<< " "; 
// 		}
// 		destFile1 <<"\n";
// 	}
// 	destFile1.close();
// }




/*
int solve()
{
	int      solstat;
    double   objval;
	double   *x = NULL;
    double   *pi = NULL;
    double   *slack = NULL;
    double   *dj = NULL;


    CPXENVptr     env = NULL;
    CPXLPptr      lp = NULL;
    int status = 0;
    double sol=0.0;
    int  cur_numrows, cur_numcols;
    env = CPXopenCPLEX (&status);
    if ( env == NULL ) {
       char  errmsg[CPXMESSAGEBUFSIZE];
       fprintf (stderr, "Could not open CPLEX environment.\n");
       CPXgeterrorstring (env, status, errmsg);
       fprintf (stderr, "%s", errmsg);
       exit(-1);
    }
    //status = CPXsetdblparam (env, CPXPARAM_TimeLimit, 3600.0);
	if ( status )  
	{
       exit(-1);
    }

    //cout<<"创建问题"<<endl;
	//create problem
    lp = CPXcreateprob (env, &status, "master");
   
    if ( lp == NULL ) {
       fprintf (stderr,"Failed to create subproblem\n");
       status = 1;
       exit(-1);
    }

    status = CPXsetintparam (env, CPX_PARAM_LPMETHOD,CPX_ALG_AUTOMATIC);//CPX_ALG_AUTOMATIC/PRIMAL/DUAL
	//status = CPXsetintparam (env, CPX_PARAM_BARCROSSALG,CPX_ALG_NONE);
    if ( status ) {
       fprintf (stderr, 
               "Failure to set lp method\n");
       exit(-1);
    }
	
	
	double* time;
    time = (double *) malloc (10 * sizeof(double));
	
	status=CPXgetdettime(env, time);
    if ( status )  
    {
       exit(-1);
    }
    cout<<"time"<<time<<endl;
	
    free(time);
	status = CPXchgobjsen (env, lp, CPX_MIN);  // Problem is minimization 
    if ( status )  
    {
       exit(-1);
    }
    //cout<<"最小化问题"<<endl;
	int NUMCOLS;
	int weiShu ;

	double   *obj=NULL;
    double   *lb=NULL;
    double   *ub=NULL;
    char     **colname=NULL;
    char     *ctype=NULL;

	NUMCOLS=day*R;
	weiShu = calWS(NUMCOLS);

	obj = (double *) malloc (NUMCOLS * sizeof(double));
    lb  = (double *) malloc (NUMCOLS * sizeof(double));
    ub  = (double *) malloc (NUMCOLS * sizeof(double));
    colname = (char**) malloc (NUMCOLS * sizeof(char*));
    ctype = (char *) malloc (NUMCOLS * sizeof(char));

	int temp;
	

	for (int d=0;d<day;d++)
    {
		for (int r=0;r<R;r++)
	    {
		    temp=d*R+r;
		    obj[temp]=Routes[r][0];
		    lb[temp]=0;
		    ub[temp]=CPX_INFBOUND;
		    ctype[temp]='C';
		    colname[temp]=(char *) malloc ((3+2*weiShu)* sizeof(char));
		    sprintf(colname[temp],"z_%d_%d",d,r);
	    }
    }
	status = CPXnewcols (env, lp, NUMCOLS, obj, lb, ub, ctype, colname);

    free(obj);
    free(lb);
    free(ub);
    free(colname);
    free(ctype);


	NUMCOLS=N*K;
	weiShu = calWS(NUMCOLS);

	obj = (double *) malloc (NUMCOLS * sizeof(double));
    lb  = (double *) malloc (NUMCOLS * sizeof(double));
    ub  = (double *) malloc (NUMCOLS * sizeof(double));
    colname = (char**) malloc (NUMCOLS * sizeof(char*));
    ctype = (char *) malloc (NUMCOLS * sizeof(char));

	for (int i=0;i<K;i++)
    {
		for (int j=K;j<K+N;j++)
	    {
		    temp=i*N+j-K;
		    obj[temp]=0;
		    lb[temp]=0;
		    ub[temp]=CPX_INFBOUND;
		    ctype[temp]='C';
		    colname[temp]=(char *) malloc ((3+2*weiShu)* sizeof(char));
		    sprintf(colname[temp],"u_%d_%d",i,j);
	    }
    }

	status = CPXnewcols (env, lp, NUMCOLS, obj, lb, ub, ctype, colname);

    free(obj);
    free(lb);
    free(ub);
    free(colname);
    free(ctype);

	cout<<"定义变量结束"<<endl;



	
	int NUMROWS;
	int NUMNZ;

	int      *rmatbeg=NULL;
    int      *rmatind=NULL;
    double   *rmatval=NULL;
    double   *rhs=NULL;
    char     *sense=NULL;
    char     **rowname=NULL;

	//第一条约束
	NUMROWS=day*N;
	weiShu = calWS(NUMROWS);
	NUMNZ=day*N*R;

	rmatbeg = (int *) malloc (NUMROWS * sizeof(int));
    rmatind  = (int *) malloc (NUMNZ * sizeof(int));
    rmatval  = (double *) malloc (NUMNZ * sizeof(double));
    rhs = (double *) malloc (NUMROWS* sizeof(double));
    sense = (char *) malloc (NUMROWS* sizeof(char));
    rowname = (char **) malloc (NUMROWS * sizeof(char*));

	int temp2;
    int temp3;
    for (int d=0;d<day;d++)
    {
	    for (int j=0;j<N;j++)
	    {
		    temp2=d*N+j;//计算是多少行
		    rmatbeg[temp2] = temp2*R; 
		    sense[temp2] = 'G';
		    rhs[temp2]   = people[K+j][6+d];
		    for (int r=0;r<R;r++)
		    {
				temp3=temp2*R+r;
				rmatval[temp3]=Routes[r][K+j+1];
				rmatind[temp3]=d*R+r;
		    }
		    rowname[temp2]=(char *) malloc ((3+weiShu) * sizeof(char));
            sprintf(rowname[temp2],"c0_%d",temp2);
	    }
    }

    status = CPXaddrows (env, lp, 0, NUMROWS, NUMNZ, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);
   
    if ( status )  
    {
       exit(-1);
    }
    free(rmatbeg);
    free(rmatind);
    free(rmatval);
    free(sense);
    free(rowname);
    free(rhs);

	//第二条约束

	NUMROWS=day*K;
	weiShu = calWS(NUMROWS);
	NUMNZ=day*K*R;

	rmatbeg = (int *) malloc (NUMROWS * sizeof(int));
    rmatind  = (int *) malloc (NUMNZ * sizeof(int));
    rmatval  = (double *) malloc (NUMNZ * sizeof(double));
    rhs = (double *) malloc (NUMROWS* sizeof(double));
    sense = (char *) malloc (NUMROWS* sizeof(char));
    rowname = (char **) malloc (NUMROWS * sizeof(char*));

    for (int d=0;d<day;d++)
    {
	    for (int j=0;j<K;j++)
	    {
		    temp2=d*K+j;//计算是多少行
		    rmatbeg[temp2] = temp2*R; 
		    sense[temp2] = 'L';
		    rhs[temp2]   = people[j][6+d];
		    for (int r=0;r<R;r++)
		    {
				temp3=temp2*R+r;
				rmatval[temp3]=Routes[r][j+1];
				rmatind[temp3]=d*R+r;
		    }
		    rowname[temp2]=(char *) malloc ((3+weiShu) * sizeof(char));
            sprintf(rowname[temp2],"c1_%d",temp2);
	    }
    }


   
    status = CPXaddrows (env, lp, 0, NUMROWS, NUMNZ, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);
   
    if ( status )  
    {
       exit(-1);
    }
    free(rmatbeg);
    free(rmatind);
    free(rmatval);
    free(sense);
    free(rowname);
    free(rhs);


	//第三条约束

	NUMROWS=N;
	weiShu = calWS(NUMROWS);
	NUMNZ=N*K;

	rmatbeg = (int *) malloc (NUMROWS * sizeof(int));
    rmatind  = (int *) malloc (NUMNZ * sizeof(int));
    rmatval  = (double *) malloc (NUMNZ * sizeof(double));
    rhs = (double *) malloc (NUMROWS* sizeof(double));
    sense = (char *) malloc (NUMROWS* sizeof(char));
    rowname = (char **) malloc (NUMROWS * sizeof(char*));

    for (int j=0;j<N;j++)
	{
		    temp2=j;//计算是多少行
		    rmatbeg[temp2] = temp2*K; 
		    sense[temp2] = 'L';
		    rhs[temp2]   = Q;
		    for (int i=0;i<K;i++)
		    {
				temp3=temp2*K+i;
				rmatval[temp3]=1;
				rmatind[temp3]=day*R+i*N+j;
		    }
		    rowname[temp2]=(char *) malloc ((3+weiShu) * sizeof(char));
            sprintf(rowname[temp2],"c2_%d",temp2);
    }


  
    status = CPXaddrows (env, lp, 0, NUMROWS, NUMNZ, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);
   
    if ( status )  
    {
       exit(-1);
    }
    free(rmatbeg);
    free(rmatind);
    free(rmatval);
    free(sense);
    free(rowname);
    free(rhs);

	//第四条约束

	NUMROWS=day*N*K;
	weiShu = calWS(NUMROWS);
	NUMNZ=day*N*K*(1+R);

	rmatbeg = (int *) malloc (NUMROWS * sizeof(int));
    rmatind  = (int *) malloc (NUMNZ * sizeof(int));
    rmatval  = (double *) malloc (NUMNZ * sizeof(double));
    rhs = (double *) malloc (NUMROWS* sizeof(double));
    sense = (char *) malloc (NUMROWS* sizeof(char));
    rowname = (char **) malloc (NUMROWS * sizeof(char*));

    for (int d=0;d<day;d++)
    {
	    for (int i=0;i<K;i++)
	    {
			for (int j=0;j<N;j++)
			{
				temp2=d*K*N+i*N+j;//计算是多少行
		        rmatbeg[temp2] = temp2*(1+R); 
		        sense[temp2] = 'L';
		        rhs[temp2]   = 0;
		        for (int r=0;r<R;r++)
		       {
				    temp3=temp2*(1+R)+r;
				    rmatval[temp3]=Routes[r][i+1]*Routes[r][K+j+1];
				    rmatind[temp3]=d*R+r;
		        }
				temp3=temp2*(1+R)+R;
				rmatval[temp3]=-R;
				rmatind[temp3]=day*R+i*N+j;


		        rowname[temp2]=(char *) malloc ((3+weiShu) * sizeof(char));
                sprintf(rowname[temp2],"c3_%d",temp2);
			}
	    }
    }

    status = CPXaddrows (env, lp, 0, NUMROWS, NUMNZ, rhs, sense, rmatbeg,
                        rmatind, rmatval, NULL, rowname);
   
    if ( status )  
    {
       exit(-1);
    }
    free(rmatbeg);
    free(rmatind);
    free(rmatval);
    free(sense);
    free(rowname);
    free(rhs);

	

	cout<<"输出问题"<<endl;
    status=CPXwriteprob(env,lp,"PT_MasterModel.lp",NULL);
	if(status!=0) {
		printf("error in CPXwriteprob\n");
		exit(-1);
	}

	

	// Optimize the problem and obtain solution. 

	//status = CPXmipopt(env, lp);
	status = CPXlpopt (env, lp);
    if ( status ) {
      fprintf (stderr, "Failed to optimize LP.\n");
      exit(-1);
    }
    

    int lpstat=CPXgetstat(env,lp);
    cout<<"solution status\t"<<lpstat<<endl;
	 



    status = CPXgetobjval(env,lp,&sol);
    if ( status ) {
       fprintf (stderr, "Failed to obtain solution.\n");
       exit(-1);
     
    }

    cout<<"objective value\t"<<sol<<endl;

    cur_numrows = CPXgetnumrows (env, lp);
    cur_numcols = CPXgetnumcols (env, lp);
    cout<<"cur_numrows"<<cur_numrows<<endl;
    cout<<"cur_numcols"<<cur_numcols<<endl;

	x = (double *) malloc (cur_numcols * sizeof(double));
    slack = (double *) malloc (cur_numrows * sizeof(double));
    dj = (double *) malloc (cur_numcols * sizeof(double));
    pi = (double *) malloc (cur_numrows * sizeof(double));
	if ( x     == NULL ||
        slack == NULL ||
        dj    == NULL ||
        pi    == NULL   ) {
		status = CPXERR_NO_MEMORY; 
		fprintf (stderr, "Could not allocate memory for solution.\n");
        exit(-1);
     }




	//status = CPXgetmipx(env,lp,x,0,cur_numcols-1);



	
	//对偶的求解
	status = CPXsolution (env, lp, &solstat, &objval, x, pi, slack, dj);
    if ( status ) {
		fprintf (stderr, "Failed to obtain solution.\n");
        exit(-1);
    }



	//Free up the problem as allocated by CPXcreateprob, if necessary 

    if ( lp != NULL ) {
       status = CPXfreeprob (env, &lp);
       if ( status ) {
          fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
       }
    }

    // Free up the CPLEX environment, if necessary 

    if ( env != NULL ) {
       status = CPXcloseCPLEX (&env);

       // Note that CPXcloseCPLEX produces no output,
        // so the only way to see the cause of the error is to use
       //  CPXgeterrorstring.  For other CPLEX routines, the errors will
        // be seen if the CPXPARAM_ScreenOutput indicator is set to CPX_ON. 
	   if ( status ) {
		   char  errmsg[CPXMESSAGEBUFSIZE];
           fprintf (stderr, "Could not close CPLEX environment.\n");
          CPXgeterrorstring (env, status, errmsg);
          fprintf (stderr, "%s", errmsg);
       }
    }


	free(x);
	free(slack);
	free(dj);
	free(pi);

	return (status);
}*/