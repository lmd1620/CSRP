#include <vector>
#include<list>
#include <queue>
#include <cplex.h>
#include "global_variables.h"
#include "global_functions.h"
#include "heurisitic.h"
#include <bitset>
#include <cstdio>
#include "ubitset.h"


using namespace std;

typedef struct pair_t
{
	int index;
	double value;
} pair_t;


typedef struct node
{
	double cap_load;   
	double resource;  
	double load;     
	int unreachable; 
	//vector<int> ng_unreachnode;  
	//bitset<1<<8> bit_value;
	int ng_parent;   
	//int changedstate;   
	vector<int> ng_arcselect;        
	vector<int> nodevisit_indicator;  

	M_CREATESET(ng_unreachnode,128);
	//M_RESET(ng_unreachnode);
	vector<int> subrow_indicator;
	vector<int> subrow_unsubstract;
} node;



class labelcor
{
public:
	vector<list<node*>> Labelist;
	vector<list<node*>> unprocess_Labelist;
	
	int nbCities;
	int src;
	int T;//new_added  day d
	double* pi;//new_added dual variable
	double** travelcost;
	double** traveltime;
	vector<int> E;
	vector<vector<int>> ng_set;
	int** ng_setIndicator_mat;
	int ng_size;
	int num_rows;//new_added total cuts number
	int actual_num_rows;//new_added cuts number of day d
	char domLev;

public:
	labelcor(int,int,int,double**,double**,double *,int,int,char);

	~labelcor()
	{
		

		for(int i=0;i<nbCities;i++)
		{
	
	
			//if(i >=K)
			{
				while(!Labelist[i].empty())
				{

					delete Labelist[i].back();
					Labelist[i].pop_back();

				}
			}
	

			while(!unprocess_Labelist[i].empty())
			{
	
				
				delete unprocess_Labelist[i].back();
				unprocess_Labelist[i].pop_back();
				
			}
		
		}



		for(int i=0;i<nbCities;i++)
		{
			delete [] ng_setIndicator_mat[i];
			delete [] travelcost[i];
			delete [] traveltime[i];
		}
		delete [] ng_setIndicator_mat;
		delete [] travelcost;
		delete [] traveltime;

		delete [] pi;	
	};

/*
	~labelcor()
	{
		while(!Labelist[src].empty())
		{

			delete Labelist[src].back();
			Labelist[src].pop_back();

		}
	};*/
	vector<int> Successors(double**,int,int);

	void LabelAlgorithm(double**, double**);
	
	
	vector<vector<int>> Find_ng_Set(int);

	node* Extend(node*,int,int);
	int USetDom(node*,node*,int,int,char);
	int USetDom_Strong(long unsigned int,long unsigned int);
	int USetDom_Weak(int,int);
	//int USetDom_bit(bitset<1<<8>,bitset<1<<8>);
	vector<int> Extend_arc(vector<int>,int,int);

	bool IsLabelDominated(vector<list<node*>> &,node*,int,char,char);
	

	void printlabels(int);

	void removebadlabels(int);



};
