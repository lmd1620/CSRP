#include <vector>
#include <algorithm>
#include <queue>
#include <list>
#include <math.h>
#include "tabu.h"
#define zero 10e-6

/**********************************************************/
tabu:: tabu(int T_,int src_,int nbCities_,double** travelcost_,double** traveltime_)
/**********************************************************/
{
    T=T_;
    src=src_;
	nbCities=nbCities_;

	travelcost=new double*[nbCities];
	traveltime=new double*[nbCities];
	for(int i=0;i<nbCities;i++)
	{
		travelcost[i]=new double[nbCities]; 
		traveltime[i]=new double[nbCities];
	}

	for(int i=0;i<nbCities;i++)
	{
		for(int j=0;j<nbCities;j++)
		{
			travelcost[i][j]=travelcost_[i][j];
			traveltime[i][j]=traveltime_[i][j];
		}
	}

	basic_columns_tabu=basic_columns[T][src];
}
/**********************************************************/


int tabu:: tabu_search()
{
	//cout<<"enter tabu search"<<basic_columns_tabu.size()<<endl;
	new_generated_routes.clear();
	
	maxIter=10;
	maxCol=300;
    vector<vector<int>>::iterator it=basic_columns_tabu.begin();
	while(!(*it).empty()&& it!=basic_columns_tabu.end()) 
	{
		//cout<<"!(*it).empty()&& it!=basic_columns_tabu.end()"<<endl;

		// for(int col=0;col<N+K;col++)
		// {
		// 	cout<<(*it)[col]<<"      ";   
		// }
		// cout<<endl;
		
		TL_insert.clear();
		TL_remove.clear();
		int iter=0;
		double reduced_cost_temp;
		int pre,succ;

		

		Tabu_Route* r_curr=new Tabu_Route;
		r_curr->reduced_cost=0.0;
		r_curr->ng_arcselect=(*it);
		r_curr->nodevisit_indicator=vector<int>(nbCities,0);

		while(iter<maxIter)
		{
			//cout<<"iter"<<iter<<endl;
			vector<int> ROUTE_single;
			vector<double> ROUTE_time_single;
		    //ROUTE_single.clear();
			//ROUTE_time_single.clear();
			ROUTE_single.push_back(src);
			int col_for_seq=0;
			int flag=1;
			while(flag==1)
			{
				for(int col=0;col<N+K;col++)
				{
					if(r_curr->ng_arcselect[col]==ROUTE_single[col_for_seq])
					{
						if(col==src)
						{
							flag=0;
							break;
						}		
						ROUTE_single.push_back(col);
						col_for_seq++;
						break;
					}
				}
			}
			ROUTE_single.push_back(src);
			//cout<<"after route single "<<endl;
			// for(int col=0;col<ROUTE_single.size();col++)
			// {
			// 	cout<<ROUTE_single[col]<<"      ";   
			// }
			// cout<<endl;
			

			//cout<<"after route single and route time single"<<endl;
			// for(int col=0;col<ROUTE_time_single.size();col++)
			// {
			// 	cout<<ROUTE_time_single[col]<<"      ";   
			// }
			// cout<<endl;

			ROUTE_time_single=vector<double>(ROUTE_single.size(),0);
			ROUTE_time_single[0] = people[src][3];
			for (int i=1; i<ROUTE_single.size(); i++)
			{
				ROUTE_time_single[i]=max(ROUTE_time_single[i-1]+people[ROUTE_single[i-1]][5]+traveltime[ROUTE_single[i-1]][ROUTE_single[i]],people[ROUTE_single[i]][3]);
			}
			flag=1;
			for (int i=1; i<ROUTE_single.size()-1; i++)
			{
				if (ROUTE_time_single[i]>people[ROUTE_single[i]][4])
				{
					flag=0;
					break;
				}
			}
			if (ROUTE_time_single[ROUTE_single.size()-1]>people[src][4]+regulation)
			{
				flag=0;
			}

			if(flag==0)
			{
				break;
			}
			Tabu_Route* r_best=new Tabu_Route;
			r_best->reduced_cost=M;
			r_best->ng_arcselect=vector<int>(nbCities,-1);
			r_best->nodevisit_indicator=vector<int>(nbCities,0);

			int j_best=-1;
			int tabu_insert=-1;
			for(int j_index=0;j_index<tempnumN[T];j_index++)
			{
				int j=tempN[T][j_index];
				if(r_curr->ng_arcselect[j]!=-1)
				{
					//cout<<"if(r_curr->ng_arcselect[j]!=-1)----to remove"<<endl;
					if(!TL_remove.count(j))
					{
						pre=r_curr->ng_arcselect[j];
						for (int i=1;i<ROUTE_single.size()-1;i++)
						{
							if(ROUTE_single[i]==j)
							{
								succ=ROUTE_single[i+1];
								break;
							}
						}
						//cout<<"after find pre and succ"<<endl;
						reduced_cost_temp=r_curr->reduced_cost+travelcost[pre][succ]-travelcost[pre][j]-travelcost[j][succ];
						if (reduced_cost_temp<-zero)
						{
							Tabu_Route* r_temp=new Tabu_Route;
							r_temp->reduced_cost=reduced_cost_temp;
							r_temp->ng_arcselect=r_curr->ng_arcselect;
							r_temp->ng_arcselect[succ]=pre;
							r_temp->ng_arcselect[j]=-1;
							//cout<<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<j<<endl;
							// for(int i=0;i<N+K;i++)
							// {
							// 	cout<<r_curr->ng_arcselect[i]<<"\t";
							// }
							// cout<<endl;
							// for(int i=0;i<N+K;i++)
							// {
							// 	cout<<r_temp->ng_arcselect[i]<<"\t";
							// }
							// cout<<endl;

							r_temp->nodevisit_indicator=vector<int>(N+K,0);
							for (int i=0;i<ROUTE_single.size()-1;i++)
							{
								if(ROUTE_single[i]!=j)
								{
									r_temp->nodevisit_indicator[ROUTE_single[i]]=1;
								}
							}
							new_generated_routes.push_back(r_temp);
							//cout<<"new_generated_routes.push_back(r_temp) by remove"<<j<<endl;
							if(new_generated_routes.size()>=maxCol)
							{
								return 0;
							}
						}
						if (reduced_cost_temp<r_best->reduced_cost-zero)
						{
							//cout<<"if (reduced_cost_temp<r_best->reduced_cost-zero)"<<endl;
							tabu_insert=1;
							j_best=j;
							r_best->reduced_cost=reduced_cost_temp;
							r_best->ng_arcselect=r_curr->ng_arcselect;
							r_best->ng_arcselect[succ]=pre;
							r_best->ng_arcselect[j]=-1;
							r_best->nodevisit_indicator=vector<int>(N+K,0);
							for (int i=0;i<ROUTE_single.size()-1;i++)
							{
								if(ROUTE_single[i]!=j)
								{
									r_best->nodevisit_indicator[ROUTE_single[i]]=1;
								}
							}
						}
					}
				}
				else
				{
					//cout<<"else: (r_curr->ng_arcselect[j]=-1)----to insert "<<endl;
					if(!TL_insert.count(j))
					{
						//cout<<"!TL_insert.count(j)"<<endl;
						double capacity=people[j][6+P+day];
						for (int i=1;i<ROUTE_single.size()-1;i++)
						{
							capacity+=people[ROUTE_single[i]][6+P+day];
						}
						flag=1;
						for (int i=6+day;i<6+day+P;i++)
						{
							if (people[j][i]>people[src][i])
							{
								flag=0;
							}
						}
						
						if(capacity<=people[src][6+P+day] && flag==1)
						{
							//cout<<"after capacity and preference"<<endl;
							for (int i=0; i<ROUTE_single.size()-1; i++)
							{
								//cout<<"for (int i=0; i<ROUTE_single.size()-1; i++)"<<i<<endl;
								pre = ROUTE_single[i];
								succ = ROUTE_single[i+1];
								if(travelcost[pre][j]==M || travelcost[j][succ]==M)
								{
									continue;
								}
								reduced_cost_temp= r_curr->reduced_cost+travelcost[pre][j]+travelcost[j][succ]-travelcost[pre][succ];
								//cout<<"reduced_cost_temp"<<reduced_cost_temp<<endl;
								double new_start_time = ROUTE_time_single[i]+people[pre][5]+traveltime[pre][j];
								//cout<<"new_start_time1\t"<<new_start_time<<endl;
								if (new_start_time < people[j][3])
								{
									new_start_time = people[j][3];
								}
								else if (new_start_time > people[j][4])
								{
									break;
								}
								//cout<<"new_start_time2\t"<<new_start_time<<endl;
								new_start_time = max(people[succ][3],new_start_time+people[j][5]+traveltime[j][succ]);
								//cout<<"calculate new_start_time1"<<endl;
								if (new_start_time <= ROUTE_time_single[i+1])
								{
									if(reduced_cost_temp<-zero)
									{
										Tabu_Route* r_temp=new Tabu_Route;
										r_temp->reduced_cost=reduced_cost_temp;
										r_temp->ng_arcselect=r_curr->ng_arcselect;
										r_temp->ng_arcselect[succ]=j;
										r_temp->ng_arcselect[j]=pre;
										r_temp->nodevisit_indicator=vector<int>(N+K,0);
										for (int node_index=0;node_index<ROUTE_single.size()-1;node_index++)
										{
											r_temp->nodevisit_indicator[ROUTE_single[node_index]]=1;
										}
										r_temp->nodevisit_indicator[j]=1;
										new_generated_routes.push_back(r_temp);
										//cout<<"new_generated_routes.push_back(r_temp) by insert"<<j<<endl;
										if(new_generated_routes.size()>=maxCol)
										{
											return 0;
										}
									}
									
									if (reduced_cost_temp<r_best->reduced_cost-zero)
									{
										//cout<<"if (reduced_cost_temp<r_best->reduced_cost-zero)"<<endl;
										tabu_insert=0;
										j_best=j;
										r_best->reduced_cost=reduced_cost_temp;
										r_best->ng_arcselect=r_curr->ng_arcselect;
										r_best->ng_arcselect[succ]=j;
										r_best->ng_arcselect[j]=pre;
										r_best->nodevisit_indicator=vector<int>(N+K,0);
										for (int node_index=0;node_index<ROUTE_single.size()-1;node_index++)
										{
											r_best->nodevisit_indicator[ROUTE_single[node_index]]=1;
										}
										r_best->nodevisit_indicator[j]=1;
									}
								}
								else if(new_start_time>people[succ][4])
								{
									continue;
								}
								else
								{
									int flag_time=0;
									for(int index=i+1;index<ROUTE_single.size()-2;index++)
									{
										new_start_time = max(people[ROUTE_single[index+1]][3],new_start_time+people[ROUTE_single[index]][5]+traveltime[ROUTE_single[index]][ROUTE_single[index+1]]);
								
										if (new_start_time <= ROUTE_time_single[index+1])
										{
											flag_time=1;
											break;
										}
										else if(new_start_time>people[ROUTE_single[index+1]][4])
										{
											break;
										}
										else if(index==ROUTE_single.size()-3 && ROUTE_single[ROUTE_single.size()-1]==src)
										{
											new_start_time = new_start_time+people[ROUTE_single[index+1]][5]+traveltime[ROUTE_single[index+1]][src];
											if(new_start_time <= people[src][4]+regulation)
											{
												flag_time=1;
												break;
											}

										}
									}

									if(flag_time==1)
									{
										if(reduced_cost_temp<-zero)
										{
											Tabu_Route* r_temp=new Tabu_Route;
											r_temp->reduced_cost=reduced_cost_temp;
											r_temp->ng_arcselect=r_curr->ng_arcselect;
											r_temp->ng_arcselect[succ]=j;
											r_temp->ng_arcselect[j]=pre;
											r_temp->nodevisit_indicator=vector<int>(N+K,0);
											for (int node_index=0;node_index<ROUTE_single.size()-1;node_index++)
											{
												r_temp->nodevisit_indicator[ROUTE_single[node_index]]=1;
											}
											r_temp->nodevisit_indicator[j]=1;
											new_generated_routes.push_back(r_temp);
											//cout<<"new_generated_routes.push_back(r_temp) by insert"<<j<<endl;
											if(new_generated_routes.size()>=maxCol)
											{
												return 0;
											}
										}
										
										if (reduced_cost_temp<r_best->reduced_cost-zero)
										{
											//cout<<"if (reduced_cost_temp<r_best->reduced_cost-zero)"<<endl;
											tabu_insert=0;
											j_best=j;
											r_best->reduced_cost=reduced_cost_temp;
											r_best->ng_arcselect=r_curr->ng_arcselect;
											r_best->ng_arcselect[succ]=j;
											r_best->ng_arcselect[j]=pre;
											r_best->nodevisit_indicator=vector<int>(N+K,0);
											for (int node_index=0;node_index<ROUTE_single.size()-1;node_index++)
											{
												r_best->nodevisit_indicator[ROUTE_single[node_index]]=1;
											}
											r_best->nodevisit_indicator[j]=1;
										}
									}
								}
							}	
						}
					}
				}
			}
			if(r_best->reduced_cost<M-zero)
			{
				if (tabu_insert==1)
				{
					TL_insert.insert(j_best);
				}
				else if(tabu_insert==0)
				{
					TL_remove.insert(j_best);
				}
				//cout<<"update r_curr"<<j_best<<endl;
				r_curr->reduced_cost=r_best->reduced_cost;
				r_curr->ng_arcselect=r_best->ng_arcselect;
				// for(int i=0;i<N+K;i++)
				// {
				// 	cout<<r_curr->ng_arcselect[i]<<"\t";
				// }
				// cout<<endl;
				r_curr->nodevisit_indicator=r_best->nodevisit_indicator;
			}
			iter++;
			delete r_best;
		}
		it++;
		delete r_curr;
	}
	return -1;
}