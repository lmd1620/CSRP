#include "global_variables.h"



int day;
int K;
int N;
int Q;
int P;
double regulation;
double** people;
double** travel;
double*** daytravel;
double*** tempdaytravel;
double**** daydoctravel;
double* extra_routes;
double** costs_sum;
double** sharev;
double** sharevi;
int** routes;
double** routes_time;
int* sequence;
int** tempK;
int** tempN;
double*** places;
int    constraints[4];



int R=0;
double   **Routes=NULL;
// vector<vector<int>> ROUTES;
// vector<double> ROUTES_COST;
// vector<vector<int>> ROUTES_SEQ;
int*    tempnumK;
int*    tempnumN;
int*    consist_N_to_K;



double penalty_cost[4]={1000000,1000000,1000000,1000000}; //{10,10,10,1000}; 

double sum_costs;
double travel_cost=1.0; 
double costs[3]={M,M,M};    
int    route_index_1;
double addcost; 
int out_index=0;

time_t tBegin,timeEnd,currTime;
clock_t time_finish,time_start;
double TIME_LIMIT;
bool STOP_TIME_LIMIT;
double current_time;
int BP_nodes=0;

int L=20;
double appro_p=0.75;
double appro_v=0.2;
vector<vector<vector<double>>> travel_points;
vector<vector<double>> service_points;

vector<vector<double>> m_time_lb;
vector<vector<double>> m_time_ub;
vector<double> m_service_lb;
vector<double> m_service_ub;
vector<vector<double>>  m_time_std;
vector<double> m_service_std;
vector<vector<vector<double>>> m_saa_time;
vector<vector<double>> m_saa_service;
int m_saa_number=100;
double eps = 1e-4;


vector<vector<vector<int>>> assigned_cuts_global;
vector<vector<vector<int>>> unassigned_cuts_global;
vector<vector<vector<int>>> row_point_indicator;

vector<vector<vector<vector<int>>>> basic_columns;