﻿#include <stdio.h>
#include "bp_form.h"
#include<time.h>
#include <stdlib.h>  

#define Z_UB 10e6
#define zero 10e-6
#define EPSILON_BP 0.0001

int whether_cut=1;

int globaliteration=2;
/////////////////////////////////////CPLEX/////////////////////////////////////
CPXENVptr env_MASTER,env_PRICER;
CPXLPptr lp_MASTER,lp_PRICER;
int status= 0;
double obj_value;
double BP_lp_time;

vector<vector<vector<int>>> column_index_global;
vector<vector<vector<vector<int>>>> column_arcs_global;
vector<vector<vector<vector<int>>>> column_node_global;


int node_level;
int**** status_node_couple;
int*** status_node_selection;
int** status_u_selection;
int*** cities_visited;

double ****travelcost;
double ****traveltime;
double ****copy_travelcost;
double ****copy_traveltime;

int counter_all_nodes=0;
int counter_fixed_branching=0;
int counter_realease_branching=0;
int counter_u_enforce_branching=0;
int counter_u_forbidden_branching=0;
int counter_enforce_branching=0;
int counter_forbidden_branching=0;
int Q_max=10;
int Q_total_max=10;

double last_iter_LPvalue=0;
double best_incumbent=M;

using namespace std;


/*****************************************************************/
int my_floor(double a)
/*****************************************************************/
{
	int q;
	q=(int) (a + EPSILON_BP);
	return (q);
}
/*****************************************************************/

/*****************************************************************/
int  my_ceil(double a)
/*****************************************************************/
{
	int q;
	double b;
	b=a+1.0-EPSILON_BP;
	q=(int)(b);
	return (q);
}
/*****************************************************************/

/*****************************************************************/
void master_heur_warmup()
/*****************************************************************/
{
    
	for (int d=0;d<day;d++)
	{
		initialization(d);
	    // int randP,randI; 
	    // for (int i=0; i!= tempnumN; i++)
	    // {
	    // 	randP = rand() % tempnumN;
	    // 	randI = sequence[randP];
	    // 	sequence[randP] = sequence[i];
	    // 	sequence[i] = randI;
	    // }
	    double tempCost=0;
	    totalCosts();

	    tempCost += sum_costs;
	    int pp;
	    for (int ind=0; ind!=tempnumN[d]; ind++)
	    {
		    routesTime();
		    pp = sequence[ind];
    
		    for (int j=0; j!=3; j++)
			    costs[j] = M;
		    for (int index=0; index<tempnumK[d]; index++)
		    {
		    	route_index_1=tempK[d][index];
	 	    	addCostOne(pp);
	    	}
		    for (int k=K; k!=K+N; k++)
		    {  
		    	sharev[k][0] = places[pp][k][0];
	     		sharev[k][1] = places[pp][k][1];
		    	sharev[k][2] = places[pp][k][2];
	    	}
	    	insertion(pp);
	    }
       

	    totalCosts();
		int K_num=K;
		for(int i=0;i<K;i++)
		{
			if(routes[i][1]==0)
			{
				K_num--;
			}
		}
		Routes=new double*[K_num];
		//int** routes_seq;
		//routes_seq=new int*[K_num];
		int col_for_seq;
	    for (int row=0;row<K_num;row++)
	    {
			Routes[row]=new double[N+K+1];
			//routes_seq[row]=new int[2+N];
		}
		
		int row_num=0;
		for (int row=0;row<K;row++)
	    {
			if(routes[row][1]!=0)
			{
				Routes[row_num][N+K]=costs_sum[row][0];
				for(int col=0;col<N+K;col++)
				{
					Routes[row_num][col]=0;
				}
				// for(int col=0;col<2+N;col++)
				// {
				// 	routes_seq[row_num][col]=-1;
				// }
				row_num++;
			}
	    }
		int k_temp_num=0;
		for (int k=0;k<K;k++)
		{
			col_for_seq=0;
			if(routes[k][1]!=0)
			{
				for (int i=2;i<routes[k][1]+4;i++)
				{
					Routes[k_temp_num][routes[k][i]]=1;
					//routes_seq[k_temp_num][col_for_seq++]=routes[k][i];
				}
				k_temp_num++;
			}
		}
	    // vector<int> route_index;
	    // for (int i=0;i<K_num;i++)
	    // {
		//     for (int j=0;j<N+2;j++)
		//     {
		//      	route_index.push_back(routes_seq[i][j]);
	    // 	}
	    //     ROUTES_SEQ.push_back(route_index);
	    //     route_index.clear();
    	// }


		int index=0;

		for (int o=0;o<K;o++)
	    {
			if(routes[o][1]!=0)
			{
				vector<int> column_index_d_o;
				column_index_d_o=column_index_global[d][o];

				vector<vector<int>> column_arc_d_o;
				column_arc_d_o=column_arcs_global[d][o];

				vector<vector<int>> column_node_d_o;
				column_node_d_o=column_node_global[d][o];


				vector<int> column_arc_single=vector<int>(N+K,-1);
				vector<int> column_node_single=vector<int>(N+K,0);

				
		
				for(int node=3;node<routes[o][1]+4;node++)
				{
					if(routes[o][node]!=routes[o][node-1])
					{
						column_arc_single[routes[o][node]]=routes[o][node-1];
					}
				}
		



		
				for (int i=0;i<N+K;i++)
				{
					
					if (column_arc_single[i]!=-1)
					{
						column_node_single[i]=1;
					}
				}
				// bool non_equalcolexist=true;
				// for(int colnum=0;colnum<column_arc_d_o.size();colnum++)
				// {
				// 	if(column_arc_single==column_arc_d_o[colnum])
				// 	{
				// 		non_equalcolexist=false;
				// 		break;
				// 	}
				// }
			
				
					
				column_arc_d_o.push_back(column_arc_single);
				column_node_d_o.push_back(column_node_single);
				column_index_d_o.push_back(N*K+R+index);
				index++;
				
				column_index_global[d][o]=column_index_d_o;
				column_arcs_global[d][o]=column_arc_d_o;
				column_node_global[d][o]=column_node_d_o;
			}
		}
				

		vector<vector<int>> unassigned_cuts_d;

		// if(unassigned_cuts_global[d].empty())
		// {
		// 	cout<<"empty\n";
		// 	exit(0);
		// }

		unassigned_cuts_d=unassigned_cuts_global[d];	
		vector<int> unassigned_cut_single=vector<int>(3,-1);	
		for (int i=0; i<tempnumN[d]-2; i++)//new_added initialize the total unassigned cuts
		{
			unassigned_cut_single[0]=tempN[d][i];
	 		for (int j=i+1; j<tempnumN[d]-1; j++)
			{
				unassigned_cut_single[1]=tempN[d][j];
				for (int k=j+1; k<tempnumN[d]; k++)
				{
					unassigned_cut_single[2]=tempN[d][k];
					unassigned_cuts_d.push_back(unassigned_cut_single);
				}
			}
	    }
		unassigned_cuts_global[d]=unassigned_cuts_d;


	    master_column_add_seperate(d,Routes,NULL,K_num);
		if(status!=0) {
			printf("error in CPXwriteprob\n");
			exit(-1);
		}
		


		for(int k=0;k<K_num;k++)
		{
			delete [] Routes[k];
		}

		delete [] Routes;

		// for(int k=0;k<K_num;k++)
		// {
		// 	delete [] routes_seq[k];
		// }
		// delete [] routes_seq;
	}
	


	for (int d=0;d<day;d++)
	{
		for (int o=0;o<K;o++)
		{
			for (int i=0;i<N+K;i++)
			{
				for (int j=0;j<N+K;j++)
				{
					if(i<K&&i!=o)
					{
						travelcost[d][o][i][j]=M;
						travelcost[d][o][j][i]=M;
						traveltime[d][o][i][j]=M;
						traveltime[d][o][j][i]=M;
					}
					else if(j<K&&j!=o)
					{
						travelcost[d][o][i][j]=M;
						travelcost[d][o][j][i]=M;
						traveltime[d][o][i][j]=M;
						traveltime[d][o][j][i]=M;
					}
					else if(i==j)
					{
						travelcost[d][o][i][j]=M;						
						traveltime[d][o][i][j]=M;

					}
					else
					{
						travelcost[d][o][i][j]=travel_cost*daytravel[d][i][j];
						traveltime[d][o][i][j]=daytravel[d][i][j];

						// cout<<"\t"<<i<<"\t"<<j<<"\t"<<travelcost[d][o][i][j]<<endl;
					}
				}
			}
		}
	}
		
}
/*****************************************************************/



/*****************************************************************/
void master_heur_warmup_consistent()
/*****************************************************************/
{
    
	for (int d=0;d<day;d++)
	{
		initialization(d);
	    // int randP,randI; 
	    // for (int i=0; i!= tempnumN; i++)
	    // {
	    // 	randP = rand() % tempnumN;
	    // 	randI = sequence[randP];
	    // 	sequence[randP] = sequence[i];
	    // 	sequence[i] = randI;
	    // }
	    double tempCost=0;
	    totalCosts();

	    tempCost += sum_costs;
	    int pp;
	    for (int ind=0; ind!=tempnumN[d]; ind++)
	    {
		    routesTime();
		    pp = sequence[ind];
    
		    for (int j=0; j!=3; j++)
			    costs[j] = M;

			if (consist_N_to_K[pp]==-1)
			{
				for (int index=0; index<tempnumK[d]; index++)
		    	{
		    		route_index_1=tempK[d][index];
	 	    		addCostOne(pp);
	    		}
			}	
			else
			{
				route_index_1=consist_N_to_K[pp];
				addCostOne(pp);
			}


		    
		    for (int k=K; k!=K+N; k++)
		    {  
		    	sharev[k][0] = places[pp][k][0];
	     		sharev[k][1] = places[pp][k][1];
		    	sharev[k][2] = places[pp][k][2];
	    	}
	    	insertion(pp);
	    }
       

	    totalCosts();
		int K_num=K;
		for(int i=0;i<K;i++)
		{
			if(routes[i][1]==0)
			{
				K_num--;
			}
		}
		Routes=new double*[K_num];
		// int** routes_seq;
		// routes_seq=new int*[K_num];
		//int col_for_seq;
	    for (int row=0;row<K_num;row++)
	    {
			Routes[row]=new double[N+K+1];
			//routes_seq[row]=new int[2+N];
		}
		
		int row_num=0;
		for (int row=0;row<K;row++)
	    {
			if(routes[row][1]!=0)
			{
				Routes[row_num][N+K]=costs_sum[row][0];
				for(int col=0;col<N+K;col++)
				{
					Routes[row_num][col]=0;
				}
				// for(int col=0;col<2+N;col++)
				// {
				// 	routes_seq[row_num][col]=-1;
				// }
				row_num++;
			}
	    }
		int k_temp_num=0;
	    for (int k=0;k<K;k++)
        {
			//col_for_seq=0;
			if(routes[k][1]!=0)
			{
				for (int i=2;i<routes[k][1]+4;i++)
				{
					Routes[k_temp_num][routes[k][i]]=1;
					//routes_seq[k_temp_num][col_for_seq++]=routes[k][i];
				}
				k_temp_num++;
			}
	    }
	    // vector<int> route_index;
	    // for (int i=0;i<K_num;i++)
	    // {
		//     for (int j=0;j<N+2;j++)
		//     {
		//      	route_index.push_back(routes_seq[i][j]);
	    // 	}
	    //     ROUTES_SEQ.push_back(route_index);
	    //     route_index.clear();
    	// }


		int index=0;

		for (int o=0;o<K;o++)
	    {
			vector<int> column_index_d_o;
			column_index_d_o=column_index_global[d][o];

			vector<vector<int>> column_arc_d_o;
		    column_arc_d_o=column_arcs_global[d][o];

		    vector<vector<int>> column_node_d_o;
		    column_node_d_o=column_node_global[d][o];


			vector<int> column_arc_single=vector<int>(N+K,-1);
			vector<int> column_node_single=vector<int>(N+K,0);

			
	
			for(int node=3;node<routes[o][1]+4;node++)
			{
				if(routes[o][node]!=routes[o][node-1])
				{
					column_arc_single[routes[o][node]]=routes[o][node-1];
				}
			}
	



			
			int tempflag=0;
			for (int i=0;i<N+K;i++)
			{
				
				if (column_arc_single[i]!=-1)
				{
					column_node_single[i]=1;
					tempflag=1;
				}
			}
			bool non_equalcolexist=true;
			for(int colnum=0;colnum<column_arc_d_o.size();colnum++)
			{
				if(column_arc_single==column_arc_d_o[colnum])
				{
					non_equalcolexist=false;
					break;
				}
			}
		
			if(tempflag==1)
			{
				
				column_arc_d_o.push_back(column_arc_single);
				column_node_d_o.push_back(column_node_single);
				column_index_d_o.push_back(N*K+R+index);
				index++;
			}
			column_index_global[d][o]=column_index_d_o;
			column_arcs_global[d][o]=column_arc_d_o;
			column_node_global[d][o]=column_node_d_o;
		}
				

		vector<vector<int>> unassigned_cuts_d;

		// if(unassigned_cuts_global[d].empty())
		// {
		// 	cout<<"empty\n";
		// 	exit(0);
		// }

		unassigned_cuts_d=unassigned_cuts_global[d];	
		vector<int> unassigned_cut_single=vector<int>(3,-1);	
		for (int i=0; i<tempnumN[d]-2; i++)//new_added initialize the total unassigned cuts
		{
			unassigned_cut_single[0]=tempN[d][i];
	 		for (int j=i+1; j<tempnumN[d]-1; j++)
			{
				unassigned_cut_single[1]=tempN[d][j];
				for (int k=j+1; k<tempnumN[d]; k++)
				{
					unassigned_cut_single[2]=tempN[d][k];
					unassigned_cuts_d.push_back(unassigned_cut_single);
				}
			}
	    }
		unassigned_cuts_global[d]=unassigned_cuts_d;


	    master_column_add_seperate(d,Routes,NULL,K_num);
		if(status!=0) {
			printf("error in CPXwriteprob\n");
			exit(-1);
		}
		


		for(int k=0;k<K_num;k++)
		{
			delete [] Routes[k];
		}

		delete [] Routes;

		// for(int k=0;k<K_num;k++)
		// {
		// 	delete [] routes_seq[k];
		// }
		// delete [] routes_seq;
	}
	


	for (int d=0;d<day;d++)
	{
		for (int o=0;o<K;o++)
		{
			for (int i=0;i<N+K;i++)
			{
				for (int j=0;j<N+K;j++)
				{
					if(i<K&&i!=o)
					{
						travelcost[d][o][i][j]=M;
						travelcost[d][o][j][i]=M;
						traveltime[d][o][i][j]=M;
						traveltime[d][o][j][i]=M;
					}
					else if(j<K&&j!=o)
					{
						travelcost[d][o][i][j]=M;
						travelcost[d][o][j][i]=M;
						traveltime[d][o][i][j]=M;
						traveltime[d][o][j][i]=M;
					}
					else if(i==j)
					{
						travelcost[d][o][i][j]=M;						
						traveltime[d][o][i][j]=M;

					}
					else
					{
						travelcost[d][o][i][j]=travel_cost*daytravel[d][i][j];
						traveltime[d][o][i][j]=daytravel[d][i][j];

						// cout<<"\t"<<i<<"\t"<<j<<"\t"<<travelcost[d][o][i][j]<<endl;
					}
				}
			}
		}
	}
		
}
/*****************************************************************/


/*****************************************************************/
double master_tabu_solve_lp()
/*****************************************************************/
{
	double current_LP=M;
	// cout<<"begin_master tabu_solve_lp"<<endl;
	status=CPXlpopt(env_MASTER,lp_MASTER);

	if(status!=0) {
		printf("error in CPXlpopt\n");
		exit(-1);
	}

	int lpstat;
	lpstat=CPXgetstat(env_MASTER,lp_MASTER);
		
	if(lpstat!=1)
	{
		cout<<"lpstat\t"<<lpstat<<endl;
		printf("error in lpstat\n");
		//status=CPXwriteprob(env_MASTER,lp_MASTER,"MastertabuModel.lp",NULL);
		return M;
	}

	status=CPXgetobjval(env_MASTER,lp_MASTER,&current_LP);
	if(status!=0) {
		printf("error in CPXgetobjval\n");
	}

    int cur_numrows = CPXgetnumrows (env_MASTER,lp_MASTER);
	
    int n_var = CPXgetnumcols (env_MASTER,lp_MASTER);
	double   *pi = NULL;
	
	pi=new double[cur_numrows];
	
	status=CPXgetpi(env_MASTER,lp_MASTER,pi,0,cur_numrows-1);
	if(status!=0) {
		printf("error in CPXgetpi_assign\n");
	}
	basic_columns.clear();
	//basic_columns.swap(vector<vector<vector<vector<int>>>>());
	for(int d=0;d<day;d++)
	{
		vector<vector<vector<int>>> basic_columns_d;
		basic_columns.push_back(basic_columns_d);

		for (int o=0;o<K;o++)
		{
			vector<vector<int>> basic_columns_d_o;
		    basic_columns[d].push_back(basic_columns_d_o);
		}
	}

	double *x_master=new double[n_var];
	status=CPXgetx(env_MASTER,lp_MASTER,x_master,0,n_var-1); 

	if(status!=0)
	{
		printf("error in CPXgetx master_check_integrality_node\n");
		exit(-1);
	}
	

	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			vector<vector<int>> basic_columns_d_o;
		    basic_columns_d_o=basic_columns[d][o];

			for(int current_route=0;current_route<column_arcs_global[d][o].size();current_route++)
			{
				int var=column_index_global[d][o][current_route];
				if(x_master[var]>0)
				{
					basic_columns_d_o.push_back(column_arcs_global[d][o][current_route]);
				}
			}
			basic_columns[d][o]=basic_columns_d_o;
		}
	}
	double reduced_cost;

	
	reduced_cost=tabu_solver(pi);
	
	double last_iter_LP=0;

	int iteration=0;
	while(reduced_cost<-1e-5 && (last_iter_LP - current_LP)>zero )
	{
		//cout<<"while(reduced_cost<-1e-5)"<<iteration<<"reduced_cost"<<reduced_cost<<endl;
		memset(pi,0,sizeof(pi));
		// for(int i=0;i<cur_numrows;i++)
		// {
		// 	pi[i]=0;
		// }
		status=CPXlpopt(env_MASTER,lp_MASTER);
		if(status!=0) {
			printf("error in CPXlpopt\n");

			return M;
		}
		
        
        iteration++;
		last_iter_LP=current_LP;
		CPXgetobjval(env_MASTER,lp_MASTER,&current_LP);
		
		// cout<<"current_LP\t"<<current_LP<<endl;


		basic_columns.clear();
		//basic_columns.swap(vector<vector<vector<vector<int>>>>());
		for(int d=0;d<day;d++)
		{
			vector<vector<vector<int>>> basic_columns_d;
			basic_columns.push_back(basic_columns_d);

			for (int o=0;o<K;o++)
			{
				vector<vector<int>> basic_columns_d_o;
				basic_columns[d].push_back(basic_columns_d_o);
			}
		}

		double *x_master=new double[n_var];
		status=CPXgetx(env_MASTER,lp_MASTER,x_master,0,n_var-1); 

		if(status!=0)
		{
			printf("error in CPXgetx master_check_integrality_node\n");
			exit(-1);
		}
		

		for(int d=0;d<day;d++)
		{
			for(int o=0;o<K;o++)
			{
				vector<vector<int>> basic_columns_d_o;
				basic_columns_d_o=basic_columns[d][o];

				for(int current_route=0;current_route<column_arcs_global[d][o].size();current_route++)
				{
					int var=column_index_global[d][o][current_route];
					if(x_master[var]>0)
					{
						basic_columns_d_o.push_back(column_arcs_global[d][o][current_route]);
					}
				}
				basic_columns[d][o]=basic_columns_d_o;
			}
		}

		status=CPXgetpi(env_MASTER,lp_MASTER,pi,0,cur_numrows-1);
		if(status!=0) {
		printf("error in CPXgetpi_assign\n");
		
		return M;
		
		}
		
		reduced_cost=tabu_solver(pi);
		// cout<<"reduced_cost\t"<<reduced_cost<<endl;
	}

	delete pi;
	
	status=CPXlpopt(env_MASTER,lp_MASTER);
		if(status!=0) {
			printf("error in CPXlpopt\n");

			return M;
		}
	
	CPXgetobjval(env_MASTER,lp_MASTER,&current_LP);
	// cout<<"end_master tabu_solve_lp"<<endl;

	return current_LP;
}

/*****************************************************************/
double tabu_solver(double *pi)
/*****************************************************************/
{
	// cout<<"enter tabu solver"<<endl;
	int num_new_r;
	double reduced_cost=M;
	double**** travelcost_;
	double**** traveltime_;

	double new_r_cost;
	int row_index;
	// int* routes_seq;
	// routes_seq= new int[N+2];
	vector<int> route_index;
	int col_for_seq;
	int flag,flag1;

	travelcost_=new double***[day];
	traveltime_=new double***[day];
	for(int d=0;d<day;d++)
	{
		travelcost_[d]=new double**[K];
		traveltime_[d]=new double**[K];
		for(int o=0;o<K;o++)
		{
			travelcost_[d][o]=new double*[N+K];
			traveltime_[d][o]=new double*[N+K];
			for (int i=0;i<N+K;i++)
			{
				travelcost_[d][o][i]=new double[N+K];
				traveltime_[d][o][i]=new double[N+K];

			}
		}
	}

	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			for (int i=0;i<N+K;i++)
			{
				for (int j=0;j<N+K;j++)
				{
					travelcost_[d][o][i][j]=travelcost[d][o][i][j];
					traveltime_[d][o][i][j]=traveltime[d][o][i][j];
				}
			}
		}
	}

	

	int temp;


	for (int d=0;d<day;d++)
	{
		for (int o=0;o<K;o++)
		{
			for (int j=0;j<N;j++)
			{
				temp=d*N+j;
				for (int i=0;i<N+K;i++)
				{
					if (i!=j+K&&traveltime_[d][o][j+K][i]<M)
					{
						travelcost_[d][o][j+K][i]=travelcost_[d][o][j+K][i]-pi[temp];
					}
				}
			}
		}
	}

	for (int d=0;d<day;d++)
	{
		for (int i=0;i<K;i++)
		{
			temp=day*N+d*K+i;
			for (int j=0;j<N+K;j++)
			{
				if (i!=j&&traveltime_[d][i][i][j]<M)
				{
					travelcost_[d][i][i][j]=travelcost_[d][i][i][j]-pi[temp];
				}
			}
		}
	}

	for (int d=0;d<day;d++)
	{
		for (int i=0;i<K;i++)
		{
			for (int j=0;j<N;j++)
			{
				temp=day*(N+K)+N+d*K*N+i*N+j;
				travelcost_[d][i][i][K+j]=travelcost_[d][i][i][K+j]-pi[temp];
				for (int index=0;index<N;index++)
				{
					if(index!=j)
					{
						travelcost_[d][i][K+index][K+j]=travelcost_[d][i][K+index][K+j]-pi[temp];
					}
				}
			}
		}
	}


	

	for(int d=0;d<day;d++)
	{
		// cout<<"----------------day\t"<<d<<endl;
		for(int o=0;o<K;o++)
		{
			// cout<<"-----------------------doct\t"<<o<<endl;
			if(basic_columns[d][o].size()>0)
			{
				vector<vector<int>> basic_columns_d_o=basic_columns[d][o];
				tabu tabusolver(d,o,N+K,travelcost_[d][o],traveltime_[d][o]);
				tabusolver.tabu_search();
				
				num_new_r=int(tabusolver.new_generated_routes.size());
				//cout<<"num_new_r\t"<<num_new_r<<endl;
				//exit(-1);
				
				// cout<<"num_new_r\t"<<num_new_r<<endl;
				if(num_new_r > 0 && tabusolver.new_generated_routes.front()!=NULL)
				{
					//cout<<"add routes"<<endl;
					Routes = new double*[num_new_r];
					for (int i=0;i<num_new_r;i++)
					{
						Routes[i]=new double[N+K+1];
					}
			
				
					row_index=0;

					

					for(vector<Tabu_Route*>::iterator it=tabusolver.new_generated_routes.begin();it!=tabusolver.new_generated_routes.end();it++)
					{
						new_r_cost=0;
						for(int j=0;j<tabusolver.nbCities;j++)
						{
							if((*it)->ng_arcselect[j]!=-1)
							{
								Routes[row_index][j]=1;
								new_r_cost+=travel_cost*travel[(*it)->ng_arcselect[j]][j];
								
							}
							else
							{
								Routes[row_index][j]=0;
							}
						}
						Routes[row_index][N+K]=new_r_cost;
						row_index++;
					}
				

			
					vector<int> column_index_d_o;
					column_index_d_o=column_index_global[d][o];

					vector<vector<int>> column_arc_d_o;
					column_arc_d_o=column_arcs_global[d][o];

					vector<vector<int>> column_node_d_o;
					column_node_d_o=column_node_global[d][o];

					int index=0;
					int n_var=CPXgetnumcols(env_MASTER,lp_MASTER);

					for(vector<Tabu_Route*>::iterator it=tabusolver.new_generated_routes.begin();it!=tabusolver.new_generated_routes.end();it++)
					{
						vector<int> column_arc_single;
						vector<int> column_node_single;

							

						for(int node=0;node<N+K;node++)
						{
							column_arc_single.push_back((*it)->ng_arcselect[node]);
							
							if((*it)->nodevisit_indicator[node]>0)
							{
								column_node_single.push_back(1);
							}
							else
							{
								column_node_single.push_back(0);
							}
						}
						column_arc_d_o.push_back(column_arc_single);
						column_node_d_o.push_back(column_node_single);
						column_index_d_o.push_back(n_var+index);
						index++;							
								
								
					}

					column_index_global[d][o]=column_index_d_o;
					column_arcs_global[d][o]=column_arc_d_o;
					column_node_global[d][o]=column_node_d_o;
					
					master_column_add_seperate(d,Routes,NULL,num_new_r);//
					
					for (int i=0;i<num_new_r;i++)
					{
						delete [] Routes[i];
						
					}
					delete [] Routes;
				}
			}
			//cout<<"finish doc\t"<<o<<endl;
		}
		
		//cout<<"finish day\t"<<d<<endl;
	
	}






	for(int d=0;d<day;d++)
	{	
		for(int o=0;o<K;o++)
		{
			for(int i=0;i<N+K;i++)
			{
				delete [] travelcost_[d][o][i];
				delete [] traveltime_[d][o][i];
			}
		}
	}
	for(int d=0;d<day;d++)
	{	
		for(int o=0;o<K;o++)
		{
			delete [] travelcost_[d][o];
			delete [] traveltime_[d][o];
		}
	}
	for(int d=0;d<day;d++)
	{
		delete [] travelcost_[d];
        delete [] traveltime_[d];
	}
	delete [] travelcost_;
	delete [] traveltime_;
	// delete [] routes_seq;
	// cout<<"exit tabu solver"<<endl;
	return reduced_cost;
}


/*****************************************************************/
void master_initialize()
/*****************************************************************/
{
	cities_visited=new int**[day];
	for(int d=0;d<day;d++)
	{
		cities_visited[d]=new int*[K];
		for(int o=0;o<K;o++)
		{
			cities_visited[d][o]=new int[N+K];
			for(int i=0;i<N+K;i++)
			{
				cities_visited[d][o][i]=-1;
			}
		}
	}

	travelcost=new double***[day];
	traveltime=new double***[day];
	copy_travelcost=new double***[day];
	copy_traveltime=new double***[day];
	for(int d=0;d<day;d++)
	{
		travelcost[d]=new double**[K];
		traveltime[d]=new double**[K];
		copy_travelcost[d]=new double**[K];
		copy_traveltime[d]=new double**[K];
		for(int o=0;o<K;o++)
		{
			travelcost[d][o]=new double*[N+K];
			traveltime[d][o]=new double*[N+K];
			copy_travelcost[d][o]=new double*[N+K];
			copy_traveltime[d][o]=new double*[N+K];
			for(int i=0;i<N+K;i++)
			{
				travelcost[d][o][i]=new double[N+K];
				traveltime[d][o][i]=new double[N+K];
				copy_travelcost[d][o][i]=new double[N+K];
				copy_traveltime[d][o][i]=new double[N+K];
			}
		}
	}

		



	

	tBegin = time(NULL);
	TIME_LIMIT=3600;

	for(int d=0;d<day;d++)
	{
		vector<vector<int>> column_index_d;
		column_index_global.push_back(column_index_d);

		for (int o=0;o<K;o++)
		{
			vector<int> column_index_d_o;
			column_index_global[d].push_back(column_index_d_o);
		}

		
		vector<vector<vector<int>>> column_arc_d;
		column_arcs_global.push_back(column_arc_d);

		for (int o=0;o<K;o++)
		{
			vector<vector<int>> column_arc_d_o;
		    column_arcs_global[d].push_back(column_arc_d_o);
		}

		vector<vector<vector<int>>> column_node_d;
		column_node_global.push_back(column_node_d);
		for (int o=0;o<K;o++)
		{
			vector<vector<int>> column_node_d_o;
		    column_node_global[d].push_back(column_node_d_o);
		}

		vector<vector<int>> assigned_cuts_d;//new_added 
		assigned_cuts_global.push_back(assigned_cuts_d);

		vector<vector<int>> unassigned_cuts_d;
		unassigned_cuts_global.push_back(unassigned_cuts_d);

		vector<vector<int>> row_point_d;
		row_point_indicator.push_back(row_point_d);
		for (int j=0;j<N;j++)
		{
			vector<int> row_point_d_j;
		    row_point_indicator[d].push_back(row_point_d_j);
		}
	}



	status_node_couple=new int***[day];



	for(int d=0;d<day;d++)
	{
		status_node_couple[d]=new int**[K];
		for(int o=0;o<K;o++)
		{
			status_node_couple[d][o]=new int*[N+K];
			for(int i=0;i<N+K;i++)
			{
				status_node_couple[d][o][i]=new int[N+K];
			}
		}
	}

	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			for(int i=0;i<N+K;i++)
			{
				for(int j=0;j<N+K;j++)
				{
					status_node_couple[d][o][i][j]=0;
				}
			}
		}
	}

	status_node_selection=new int**[day];



	for(int d=0;d<day;d++)
	{
		status_node_selection[d]=new int*[K];
		for(int o=0;o<K;o++)
		{
			status_node_selection[d][o]=new int[N+K];
		}
	}

	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			for(int i=0;i<N+K;i++)
			{
				status_node_selection[d][o][i]=0;
			}
		}
	}

	status_u_selection=new int*[K];
	for(int i=0;i<K;i++)
	{
		status_u_selection[i]=new int[N];
	}

	for(int i=0;i<K;i++)
	{
		for (int j=0;j<N;j++)
		{
			status_u_selection[i][j]=0;
		}
	}
	

}
/*****************************************************************/

/*****************************************************************/
void master_build()
/*****************************************************************/
{
	env_MASTER=CPXopenCPLEX(&status);

	if(status!=0)
	{
		printf("cannot open CPLEX environment\n");
		exit(-1);

	}
	
	lp_MASTER=CPXcreateprob(env_MASTER,&status,"MASTER");
	if(status!=0) {
		printf("cannot create problem\n");
		exit(-1);
	}
	
	
	CPXchgobjsen(env_MASTER,lp_MASTER,CPX_MIN);

	
	double   *rhs=NULL;
    char     *sense=NULL;
	char     **rowname=NULL;
	int NUMROWS;
	
	int temp;
   
	NUMROWS=constraints[0];

	//cout<<"constraints[0]\t"<<constraints[0]<<"\n";
	

	rhs=(double*) malloc(NUMROWS * sizeof(double));
	sense =(char*) malloc(NUMROWS * sizeof(char));
	

	rowname =new char*[NUMROWS];
	for (int d=0;d<day;d++)
    {
	    for (int j=0;j<N;j++)
	    {
		    temp=d*N+j;
		    sense[temp] = 'G';
		    rhs[temp]   = people[K+j][6+d];
			rowname[temp]=new char[256];
		  
			sprintf(rowname[temp],"c0_%d_%d_%d",temp,d,j+K);
	    }
    }
	status=CPXnewrows(env_MASTER,lp_MASTER,NUMROWS,rhs,sense,NULL,rowname);
	
	if(status!=0) {
		printf("error in assign CPXaddrows\n");
		exit(-1);
	}
	
	free(sense);
	for (int j=0;j<NUMROWS;j++)
	{
		delete [] rowname[j];
	}
    delete [] rowname;
	
    free(rhs);
	
   
	NUMROWS=constraints[1];
	
	//cout<<"constraints[1]\t"<<constraints[1]<<"\n";

	rhs=(double*) malloc(NUMROWS*sizeof(double));
	sense =(char*) malloc(NUMROWS*sizeof(char));
	rowname =new char*[NUMROWS];

	for (int d=0;d<day;d++)
    {
	    for (int j=0;j<K;j++)
	    {
		    temp=d*K+j;
		    sense[temp] = 'L';
		    rhs[temp]   = people[j][6+d]; 
			rowname[temp]=new char[256];
			sprintf(rowname[temp],"c1_%d_%d_%d",temp,d,j);
	    }
    }
	
	status=CPXnewrows(env_MASTER,lp_MASTER,NUMROWS,rhs,sense,NULL,rowname);//rowname
	if(status!=0) {
		printf("error in assign CPXaddrows\n");
		exit(-1);
	}
	free(sense);
	for (int j=0;j<NUMROWS;j++)
	{
		delete [] rowname[j];
	}
    delete [] rowname;
    free(rhs);
	
   
	NUMROWS=constraints[2];
	//cout<<"constraints[2]\t"<<constraints[2]<<"\n";


	rhs=(double*) calloc(NUMROWS,sizeof(double));
	sense =(char*) calloc(NUMROWS,sizeof(char));
	rowname =new char*[NUMROWS];
	
	for (int j=0;j<N;j++)
	{
		    temp=j;
		    sense[temp] = 'L';
		    rhs[temp]   = Q;
		    rowname[temp]=new char[256];
            sprintf(rowname[temp],"c2_%d",temp);
    }
	status=CPXnewrows(env_MASTER,lp_MASTER,NUMROWS,rhs,sense,NULL,rowname);

	if(status!=0) {
		printf("error in assign CPXaddrows\n");
		exit(-1);
	}	
	free(sense);
	for (int j=0;j<NUMROWS;j++)
	{
		delete [] rowname[j];
	}
    delete [] rowname;
    free(rhs);


	NUMROWS=constraints[3];
	//cout<<"constraints[3]\t"<<constraints[3]<<"\n";


	rhs=(double*) calloc(NUMROWS,sizeof(double));
	sense =(char*) calloc(NUMROWS,sizeof(char));
	rowname =new char*[NUMROWS];

	for (int d=0;d<day;d++)
    {
	    for (int i=0;i<K;i++)
	    {
			for (int j=0;j<N;j++)
			{
				temp=d*K*N+i*N+j;
		        sense[temp] = 'L';
		        rhs[temp]   = 0;
		        rowname[temp]=new char[256];
                sprintf(rowname[temp],"c3_%d",temp);
			}
	    }
    }
	status=CPXnewrows(env_MASTER,lp_MASTER,NUMROWS,rhs,sense,NULL,rowname);

	if(status!=0) {
		printf("error in assign CPXaddrows\n");
		exit(-1);
	}
	free(sense);
	for (int j=0;j<NUMROWS;j++)
	{
		delete [] rowname[j];
	}
    delete [] rowname;
    free(rhs);

	
	double   *obj=NULL;
    double   *lb=NULL;
    double   *ub=NULL;
    char     **colname=NULL;
    int      *matbeg;
    int      *matind;
    double   *matval;

	int NUMCOLS;
	int NUMNZ;
	int tempcols;
	int tempnz;

	NUMCOLS=N*K;
	
	NUMNZ=(1+day)*NUMCOLS;
	//cout<<"NUMNZ\t"<<NUMNZ<<"\n";


	obj=(double *) malloc (NUMCOLS* sizeof(double));
	lb = (double *) malloc (NUMCOLS* sizeof(double));
    ub = (double *) malloc (NUMCOLS* sizeof(double));
	colname =new char*[NUMCOLS];
	matbeg = (int *) malloc (NUMCOLS * sizeof(int));
    matind  = (int *) malloc (NUMNZ * sizeof(int));
    matval  = (double *) malloc (NUMNZ * sizeof(double));
    
	for (int i=0;i<K;i++)
	{
		for(int j=0;j<N;j++)
		{
			tempcols=i*N+j;
			//cout<<"tempcols\t"<<tempcols<<"\ti,j\t"<<i<<"\t"<<j<<endl;
			matbeg[tempcols]=(1+day)*tempcols;
			obj[tempcols]=0;
			lb[tempcols]=0;
			ub[tempcols]=CPX_INFBOUND;
			colname[tempcols] =new char[256];
		    sprintf(colname[tempcols],"u_%d_%d",i,j+K);

			tempnz=(1+day)*tempcols;
			matind[tempnz]=day*(N+K)+j;
			matval[tempnz]=1;
			for (int d=1;d<=day;d++)
			{
				tempnz=(1+day)*tempcols+d;
			    matind[tempnz]=day*(N+K)+N+(d-1)*N*K+i*N+j;
			    matval[tempnz]=-1;
			}
		}
	}

	status = CPXaddcols (env_MASTER,lp_MASTER, NUMCOLS, NUMNZ, obj, matbeg,matind, matval, lb, ub, colname);
    //by columns, matbeg is the begin of each column, matind is the row, and matval is the coefficient.
    //matbeg[j] containing the index of the beginning of column j and matcnt[j] containing the number of entries in column j
	//For each k, matind[k] specifies the row number of the corresponding coefficient, matval[k]
	if ( status )  
    {
       exit(-1);
    }

	free(obj);
    free(lb);
    free(ub);
	for (int j=0;j<NUMCOLS;j++)
	{
		delete [] colname[j];
	}
    delete [] colname;
    free(matbeg);
	free(matind);
	free(matval);



	/*
	status=CPXwriteprob(env_MASTER,lp_MASTER,"PT_MasterModel.lp",NULL);
	if(status!=0) {
		printf("error in CPXwriteprob\n");
		exit(-1);
	}
	*/
	

	master_initialize();

	master_heur_warmup();
	master_heur_warmup_consistent();
	
	//cout<<"after master_heur_warmup_consistent"<<"start tabu\n";
	master_tabu_solve_lp();
	// cout<<"end  tabu\n";
	time_start=time(NULL);

	
}
/*****************************************************************/

/*****************************************************************/
int master_column_add_seperate(int map_d,double** newroutesgenerate,int** column_row_indicator, int NUMR)
/*****************************************************************/
{
	// cout<<"master_column_add_seperate"<<endl;
	double   *obj=NULL;
    double   *lb=NULL;
    double   *ub=NULL;
    char     **colname=NULL;
    int      *matbeg;
    int      *matind;
    double   *matval;

	int NUMCOLS;
	int NUMNZ;
	int tempcols;
	int tempnz;

	NUMCOLS=NUMR;
	NUMNZ=NUMCOLS*(N+K+N*K+assigned_cuts_global[map_d].size());

	obj=(double *) malloc (NUMCOLS* sizeof(double));
	lb = (double *) malloc (NUMCOLS* sizeof(double));
    ub = (double *) malloc (NUMCOLS* sizeof(double));
    colname =new char* [NUMCOLS];
	matbeg = (int *) malloc (NUMCOLS * sizeof(int));
    matind  = (int *) malloc (NUMNZ * sizeof(int));
    matval  = (double *) malloc (NUMNZ * sizeof(double));

	
	for(int r=0;r<NUMR;r++)
	{
		tempcols=r;
		matbeg[tempcols]=(N+K+N*K+assigned_cuts_global[map_d].size())*tempcols;
		obj[tempcols]=newroutesgenerate[r][N+K];
		lb[tempcols]=0;
		ub[tempcols]=CPX_INFBOUND;
		colname[tempcols] =new char[256];
		sprintf(colname[tempcols],"z_%d_%d",map_d,R+r);
		for(int j=0;j<N;j++)
		{
			tempnz=(N+K+N*K+assigned_cuts_global[map_d].size())*tempcols+j;
			matind[tempnz]=map_d*N+j;
			matval[tempnz]=newroutesgenerate[r][j+K];
		}
		for (int i=0;i<K;i++)
		{
			tempnz=(N+K+N*K+assigned_cuts_global[map_d].size())*tempcols+N+i;
			matind[tempnz]=day*N+map_d*K+i;
			matval[tempnz]=newroutesgenerate[r][i];
		}
			
		for (int i=0;i<K;i++)
		{
			for(int j=0;j<N;j++)
			{
				tempnz=(N+K+N*K+assigned_cuts_global[map_d].size())*tempcols+N+K+i*N+j;
				matind[tempnz]=day*(N+K)+N+map_d*N*K+i*N+j;
			    matval[tempnz]=newroutesgenerate[r][i]*newroutesgenerate[r][j+K];
			}
		}
		for (int i=0;i<assigned_cuts_global[map_d].size();i++)//new_added the subset row constraints
		{
			tempnz=(N+K+N*K+assigned_cuts_global[map_d].size())*tempcols+N+K+N*K+i;
			matind[tempnz]=assigned_cuts_global[map_d][i][3];
			matval[tempnz]=column_row_indicator[r][i];
		}
	}
	

	status = CPXaddcols (env_MASTER,lp_MASTER, NUMCOLS, NUMNZ, obj, matbeg,matind, matval, lb, ub, colname);



	free(obj);
    free(lb);
    free(ub);
	for (int j=0;j<NUMCOLS;j++)
	{
		delete [] colname[j];
	}
    delete [] colname;
    free(matbeg);
	free(matind);
	free(matval);

	if ( status )  
    {
       exit(-1);
    }


	R+=NUMR;
	
	
	// cout<<"input variablesnew routes"<<endl;
	
    // status=CPXwriteprob(env_MASTER,lp_MASTER,"PT_MasterModel.lp",NULL);
	// if(status!=0) {
	// 	printf("error in CPXwriteprob\n");
	// 	exit(-1);
	// }
	


	// vector<int> route_index;
	// for (int i=0;i<NUMR;i++)
	// {
	// 	for (int j=0;j<N+K;j++)
	// 	{
	// 		route_index.push_back(int(newroutesgenerate[i][j]));
	// 	}
	//     ROUTES.push_back(route_index);
	// 	ROUTES_COST.push_back(newroutesgenerate[i][N+K]);
	//     route_index.clear();
	// }
	
	return(-1);
}
/*****************************************************************/

/*****************************************************************/
double price_solver(double *pi, int num_rows)
/*****************************************************************/
{
	// cout<<"begin_price_solver"<<endl;

	int num_new_r;
	double new_r_cost;
	int row_index;
	// int* routes_seq;
	// routes_seq= new int[N+2];
	vector<int> route_index;
	int col_for_seq;
	int flag,flag1;
	double reduced_cost=M;
	double**** travelcost_;
	double**** traveltime_;

	travelcost_=new double***[day];
	traveltime_=new double***[day];
	for(int d=0;d<day;d++)
	{
		travelcost_[d]=new double**[K];
		traveltime_[d]=new double**[K];
		for(int o=0;o<K;o++)
		{
			travelcost_[d][o]=new double*[N+K];
			traveltime_[d][o]=new double*[N+K];
			for (int i=0;i<N+K;i++)
			{
				travelcost_[d][o][i]=new double[N+K];
				traveltime_[d][o][i]=new double[N+K];

			}
		}
	}

	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			for (int i=0;i<N+K;i++)
			{
				for (int j=0;j<N+K;j++)
				{
					travelcost_[d][o][i][j]=travelcost[d][o][i][j];
					traveltime_[d][o][i][j]=traveltime[d][o][i][j];
					// cout<<"\t"<<i<<"\t"<<j<<"\t"<<travelcost_[d][o][i][j]<<"\t"<<traveltime_[d][o][i][j]<<endl;
				}
			}
		}
	}


		// for (int j=0;j<N+K;j++)
		// {
		// 	cout<<"\t"<<0<<"\t"<<j<<"\t"<<travelcost_[0][0][0][j]<<"\t"<<traveltime_[0][0][0][j]<<endl;
		// }


	int temp;


	for (int d=0;d<day;d++)
	{
		for (int o=0;o<K;o++)
		{
			for (int j=0;j<N;j++)
			{
				temp=d*N+j;
				for (int i=0;i<N+K;i++)
				{
					if (i!=j+K&&traveltime_[d][o][j+K][i]<M)
					{
						travelcost_[d][o][j+K][i]=travelcost_[d][o][j+K][i]-pi[temp];
					}
				}
			}
		}
	}

	// for (int j=0;j<N+K;j++)
	// {
	// 	cout<<"\t"<<0<<"\t"<<j<<"\t"<<travelcost_[0][0][0][j]<<"\t"<<traveltime_[0][0][0][j]<<endl;
	// }



	for (int d=0;d<day;d++)
	{
		for (int o=0;o<K;o++)
		{
			for (int i=0;i<K;i++)
			{
				temp=day*N+d*K+i;
				for (int j=0;j<N+K;j++)
				{
					if (i!=j&&traveltime_[d][o][i][j]<M)
					{
						// cout<<d<<"\t"<<o<<"\t"<<i<<"\t"<<j<<"\t"<<pi[temp]<<endl;
						travelcost_[d][o][i][j]=travelcost_[d][o][i][j]-pi[temp];
					}
				}
			}
		}
	}


	// for (int j=0;j<N+K;j++)
	// {
	// 	cout<<"\t"<<0<<"\t"<<j<<"\t"<<travelcost_[0][0][0][j]<<"\t"<<traveltime_[0][0][0][j]<<endl;
	// }

	// exit(-4);

	for (int d=0;d<day;d++)
	{
		for (int o=0;o<K;o++)
		{
			for (int i=0;i<K;i++)
			{
				for (int j=0;j<N;j++)
				{
					if(i==o)
					{
						temp=day*(N+K)+N+d*K*N+i*N+j;
						travelcost_[d][o][i][K+j]=travelcost_[d][o][i][K+j]-pi[temp];
						for (int index=0;index<N;index++)
						{
							if(index!=j)
							{
								travelcost_[d][o][K+index][K+j]=travelcost_[d][o][K+index][K+j]-pi[temp];
							}
						}
					}
				}
			}
		}
	}



	// for (int d=0;d<day;d++)
	// {
	// 	for (int o=0;o<K;o++)
	// 	{
	// 		for (int i=0;i<K;i++)
	// 		{
	// 			for (int j=0;j<N;j++)
	// 			{

	// 				cout<<"\t"<<i<<"\t"<<K+j<<"\t"<<travelcost_[d][o][i][K+j]<<endl;
	// 			}
	// 		}
	// 	}
	// }

	// cout<<"day\t"<<day<<endl;
	for(int d=0;d<day;d++)
	{
		// cout<<"----------------day\t"<<d<<endl;
		int actual_num_rows=assigned_cuts_global[d].size();
		// cout<<"actual_num_rows\t"<<actual_num_rows<<endl;
		for(int o=0;o<K;o++)
		{
			// cout<<"-----------------------doct\t"<<o<<endl;
			
			labelcor label(d,o,N+K,travelcost_[d][o],traveltime_[d][o],pi, num_rows,actual_num_rows,'s');
			
			// cout<<"enter label setting construct"<<endl;
	        
			label.LabelAlgorithm(label.travelcost,label.traveltime);
			// exit(-1);
			// cout<<"exit label setting construct"<<endl;

			num_new_r=int(label.Labelist[o].size());
			// cout<<"num_new_r\t"<<num_new_r<<endl;
			//exit(-1);
			vector<int> feasiblepathindex;
			int counter_feasible=0;

			if(num_new_r > 0 && label.Labelist[o].front()!=NULL)
			{
				for(list<node*>::iterator it=label.Labelist[o].begin();it!=label.Labelist[o].end();it++)					
				{	
					int flag1=0;
					
					if((*it)->load>=-zero || (*it)->resource<=zero)
					{
						num_new_r--;
						feasiblepathindex.push_back(0);
					}
					else
					{
						bool doc_depot_counter=0;

						for(int index_i=0;index_i<N+K;index_i++)
						{
							if ((*it)->nodevisit_indicator[index_i]>1)
							{
								num_new_r--;
								flag1=1;
								break;
							}
							
						}

						if ((*it)->ng_arcselect[o]!=-1)
						{
							doc_depot_counter=doc_depot_counter+1;
						}	
						if(flag1==0 && doc_depot_counter>=1)
						{
							feasiblepathindex.push_back(1);
							// cout<<"feasiblepathindex.push_back(1)"<<endl;
							// for(int col=0;col<N+K;col++)
							// {
					    	// 	cout<<(*it)->ng_arcselect[col]<<"\t";
							// }
							counter_feasible++;
						}
						else
						{
							feasiblepathindex.push_back(0);
						}				
					}
				}

				if(num_new_r!=counter_feasible)
				{
					cout<<"there is an error in num_new_r\n";
					// cout<<num_new_r<<"\t"<<counter_feasible<<"\n";
					exit(-1);
				}
			}




			// cout<<"num_new_r\t"<<num_new_r<<endl;
			if(num_new_r > 0 && label.Labelist[o].front()!=NULL)
			{
				Routes = new double*[num_new_r];
				for (int i=0;i<num_new_r;i++)
				{
					Routes[i]=new double[N+K+1];
				}
		
				int** column_row_indicator;
				column_row_indicator=new int*[num_new_r];
				for (int i=0;i<num_new_r;i++)
				{
					column_row_indicator[i]=new int[actual_num_rows];
				}

			    row_index=0;

				int counter_search=0;

			    for(list<node*>::iterator it=label.Labelist[o].begin();it!=label.Labelist[o].end();it++)
			    {
					//what's the meaning of this block
				    if((*it)->load<reduced_cost)
				    {
					    reduced_cost=(*it)->load;
			    	}
					
					if(feasiblepathindex[counter_search]==1)
					{			
						//cout<<"reduced_cost\t"<<reduced_cost<<endl;								
						// cout<<"column_row_indicator\t"<<endl;
						for(int col_num=0;col_num<actual_num_rows;col_num++)
						{
							if ((*it)->subrow_unsubstract[col_num]>=2)//new_added, the cuts the route related to
							{
								column_row_indicator[row_index][col_num]=1;
								
							}
							else
							{
								column_row_indicator[row_index][col_num]=0;
							}
						}
						// for(int col_num=0;col_num<actual_num_rows;col_num++)
						// {
						// 	cout<<column_row_indicator[row_index][col_num]<<"\t";
						// }
						//cout<<"end the cout of column_row_indicator"<<endl;
						
						// for(int col=0;col<N+2;col++)
						// {
				    	// 	routes_seq[col]=-1;
			    		// }

						//routes_seq[0]=o;
						//col_for_seq=0;
						//flag=1;
						
						
						// cout<<endl;
						// cout<<"nodevisit_indicator[col]"<<"\t"<<endl;
						// for(int col=0;col<N+K;col++)
						// {
						// 	// cout<<"(*it)->ng_arcselect[col]\t"<<(*it)->ng_arcselect[col]<<"\t"<<routes_seq[col_for_seq]<<endl;
					    // 	cout<<(*it)->nodevisit_indicator[col]<<"\t";
						// }
						// cout<<endl;

						// while(flag==1)
						// {
						// 	int counter=0;
						// 	bool infeasibleroute=false;
						// 	for(int col=0;col<N+K;col++)
						// 	{
						// 		counter++;
						// 		//  cout<<"(*it)->ng_arcselect[col]\t"<<(*it)->ng_arcselect[col]<<"\t"<<routes_seq[col_for_seq]<<"\t"<<counter<<endl;
					    // 		if((*it)->ng_arcselect[col]==routes_seq[col_for_seq])
					    // 		{
						// 			if(col==o)
						// 			{
						// 	    		flag=0;
						// 				break;
						//     		}
						// 			col_for_seq++;
						// 			routes_seq[col_for_seq]=col;
					 	// 			break;
					    // 		}

						// 		if(counter==N+K)
						// 		{
						// 			infeasibleroute=true;
						// 			break;
						// 		}
				    	// 	}

						// 	if(infeasibleroute)
						// 	{
						// 		feasiblepathindex[counter_search]=0;
						// 		break;
						// 	}

						// }

						// if(feasiblepathindex[counter_search]==0)
						// {
						// 	// cout<<"infeasible\n";
						// 	counter_search++;
						// 	// exit(-1);
						// 	continue;
						// }
						
						// routes_seq[col_for_seq+1]=o;

						// for(int col=0;col<N+2;col++)
						// {
				    	// 	cout<<routes_seq[col]<<"\t";
			    		// }
						// cout<<endl;

						


						//cout<<"while end"<<endl;
						
						
						
						// for (int j=0;j<N+2;j++)
						// {
		     			// 	route_index.push_back(routes_seq[j]);
	    				// }
						// ROUTES_SEQ.push_back(route_index);
						// route_index.clear();
    
						//cout<<"here1"<<endl;
						new_r_cost=0;
						for(int j=0;j<label.nbCities;j++)
						{
							if((*it)->ng_arcselect[j]!=-1)
							{
								Routes[row_index][j]=1;
								//cout<<"j"<<j<<"(*it)->ng_arcselect[j]"<<(*it)->ng_arcselect[j]<<endl;
								new_r_cost+=travel_cost*travel[(*it)->ng_arcselect[j]][j];
							
							}
							else
							{
								Routes[row_index][j]=0;
							}
						}
						Routes[row_index][N+K]=new_r_cost;
						row_index++;
						//cout<<"row_index++"<<row_index<<endl;
					}

					
					counter_search++;
					
				}

		
				vector<int> column_index_d_o;
				column_index_d_o=column_index_global[d][o];

				vector<vector<int>> column_arc_d_o;
		        column_arc_d_o=column_arcs_global[d][o];

		        vector<vector<int>> column_node_d_o;
		        column_node_d_o=column_node_global[d][o];

				int index=0;
				int n_var=CPXgetnumcols(env_MASTER,lp_MASTER);

				int counter_while=0;
			 	for(list<node*>::iterator it=label.Labelist[o].begin();it!=label.Labelist[o].end();it++)
			    {

					if(feasiblepathindex[counter_while]==1)
					{
						vector<int> column_arc_single;
						vector<int> column_node_single;

						

						for(int node=0;node<N+K;node++)
						{
							column_arc_single.push_back((*it)->ng_arcselect[node]);
						
							if((*it)->nodevisit_indicator[node]>0)
							{
								column_node_single.push_back(1);
							}
							else
							{
								column_node_single.push_back(0);
							}
						}


						if((*it)->load<-zero && (*it)->resource>zero)
						{
							column_arc_d_o.push_back(column_arc_single);
							column_node_d_o.push_back(column_node_single);
							column_index_d_o.push_back(n_var+index);
							index++;							
							
						}
					}

					counter_while++;				
				}

				column_index_global[d][o]=column_index_d_o;
				column_arcs_global[d][o]=column_arc_d_o;
				column_node_global[d][o]=column_node_d_o;
				
				// cout<<"master_column_add_seperate\t"<<o<<endl;
				master_column_add_seperate(d,Routes,column_row_indicator,num_new_r);//
				
				// cout<<"release\t"<<o<<endl;
				for (int i=0;i<num_new_r;i++)
				{
					delete [] Routes[i];
					
				}
				delete [] Routes;

				for (int i=0;i<num_new_r;i++)
				{
					delete [] column_row_indicator[i];
					
				}
				delete [] column_row_indicator;
				
			}
			

			if(!feasiblepathindex.empty())
			{
				feasiblepathindex.clear();
			}
			// cout<<"finish doc\t"<<o<<endl;
			
			
		}
		
		// cout<<"finish day\t"<<d<<endl;
	}

	for(int d=0;d<day;d++)
	{	
		for(int o=0;o<K;o++)
		{
			for(int i=0;i<N+K;i++)
			{
				delete [] travelcost_[d][o][i];
				delete [] traveltime_[d][o][i];
			}
		}
	}
	for(int d=0;d<day;d++)
	{	
		for(int o=0;o<K;o++)
		{
			delete [] travelcost_[d][o];
			delete [] traveltime_[d][o];
		}
	}
	for(int d=0;d<day;d++)
	{
		delete [] travelcost_[d];
        delete [] traveltime_[d];
	}
	delete [] travelcost_;
	delete [] traveltime_;
	
	//delete [] routes_seq;
	
	// cout<<"end_price_solver"<<reduced_cost<<endl;
	return reduced_cost;
}
/*****************************************************************/

/*****************************************************************/
double master_solve_lp(data* Homecare_instance)
/*****************************************************************/
{
	
	double current_LP=M;
	double reduced_cost;
	int num_new_cuts=1;
	while(num_new_cuts>0 && !STOP_TIME_LIMIT)
	{

		// cout<<"begin_master_solve_lp"<<endl;
		//status=CPXwriteprob(env_MASTER,lp_MASTER,"MasterModel2.lp",NULL);
		// cout<<"wrtie the prob\n";
		
		//cout<<"before cpxlpopt"<<endl;
		status=CPXlpopt(env_MASTER,lp_MASTER);
		// cout<<"after cpxlpopt"<<endl;

		if(status!=0) {
			printf("error in CPXlpopt\n");
			exit(-1);
		}


		int lpstat;
		lpstat=CPXgetstat(env_MASTER,lp_MASTER);
			
		if(lpstat!=1)
		{
			
			printf("error in lpstat\n");
			//status=CPXwriteprob(env_MASTER,lp_MASTER,"MasterModel.lp",NULL);
			return M;
		}

		status=CPXgetobjval(env_MASTER,lp_MASTER,&current_LP);
		if(status!=0) {
			printf("error in CPXgetobjval\n");
		}

		// cout<<"lpstat\t"<<lpstat<<"\t"<<current_LP<<endl;
		

		
	
		int cur_numrows = CPXgetnumrows (env_MASTER,lp_MASTER);
		double   *pi = NULL;
		pi=new double[cur_numrows];
		
		// cout<<"before get pi"<<endl;
		status=CPXgetpi(env_MASTER,lp_MASTER,pi,0,cur_numrows-1);
		if(status!=0) 
		{
			printf("error in CPXgetpi_assign\n");
		}
		// cout<<"after get pi"<<endl;
		reduced_cost=price_solver(pi,cur_numrows);
		// cout<<"after price solver"<<reduced_cost<<endl;
		/*	
		status=CPXfreeprob(env_MASTER,&(lp_MASTER));
		if(status!=0) {printf("error in CPXfreeprob\n");exit(-2);}
		if(env_MASTER != NULL){
			status = CPXcloseCPLEX(&env_MASTER);
		}


		exit(-1);
		*/
		int iteration=0;
		
		while(reduced_cost<-1e-5 && !STOP_TIME_LIMIT)
		{
			// cout<<"start one iteration mp\n";
			for(int i=0;i<cur_numrows;i++)
			{
				pi[i]=0;
			}
			
			//status=CPXwriteprob(env_MASTER,lp_MASTER,"MasterModel3.lp",NULL);
			// cout<<"wrtie the prob iter\n";
			
			//cout<<"before cpxlpoptiter"<<endl;

			status=CPXlpopt(env_MASTER,lp_MASTER);
			if(status!=0) {
				printf("error in CPXlpopt\n");

				return M;
			}
			// cout<<"after cpxlpoptiter"<<endl;
			
			
			iteration++;
			
			CPXgetobjval(env_MASTER,lp_MASTER,&current_LP);

			//cout<<"current_LP\t"<<current_LP<<endl;

			
			status=CPXgetpi(env_MASTER,lp_MASTER,pi,0,cur_numrows-1);
			if(status!=0) {
			printf("error in CPXgetpi_assign\n");
			
			return M;
			
			}
			globaliteration++;
			// cout<<"enter column generation"<<endl;
			reduced_cost=price_solver(pi,cur_numrows);
			// cout<<"exit column generation"<<endl;
			// cout<<"finish one iteration mp\n";

			Homecare_instance->stop_time=time(NULL);
			double current_time = (double) difftime(Homecare_instance->stop_time,Homecare_instance->start_time);

			// cout<<"current_time\t"<<current_time<<endl;
			
			if(current_time>TIME_LIMIT){
				STOP_TIME_LIMIT=true;
			}

		}

		delete pi;
		// cout<<"after final column generation"<<endl;
		//status=CPXwriteprob(env_MASTER,lp_MASTER,"master_solve_lp_Problem.lp",NULL);

		num_new_cuts=0;

		whether_cut=0;
		if (whether_cut==1)//new_added 
		{
			// cout<<"enter SRC section"<<endl;
			int num_var=CPXgetnumcols(env_MASTER,lp_MASTER);
			// cout<<"num cols\t"<<num_var-N*K<<endl;

			// exit(-1);
			double *x_temp=new double[num_var];
			status=CPXgetx(env_MASTER,lp_MASTER,x_temp,0,num_var-1); 

			// for(int i=0;i<num_var;i++)
			// {
			// 	if(x_temp[i]>0)
			// 	{
			// 		cout<<i<<"\t"<<x_temp[i]<<"\n";
			// 	}
				
			// }
			// cout<<endl;
			
			int      *matind;
			double   *matval;
			matind  = (int *) malloc (num_var * sizeof(int));
			matval  = (double *) malloc (num_var * sizeof(double));

			double flag_subrow;
			
			
			
			for (int d=0;d<day;d++)
			{
				num_new_cuts=0;
				if(true)
				{
					vector<vector<int>>::iterator it=unassigned_cuts_global[d].begin();
					while(assigned_cuts_global[d].size()<=Q_total_max && num_new_cuts<Q_max && unassigned_cuts_global[d].size()>0 && (it!=unassigned_cuts_global[d].end()))
					//for (int i=0;i<unassigned_cuts_global[d].size();i++)
					{
						// cout<<"search SRC"<<(*it)[0]<<"_"<<(*it)[1]<<"_"<<(*it)[2]<<endl;
						// exit(-5);
						flag_subrow=0;
						int non_zero_add=0;
						memset(matind,0,sizeof(matind));
						memset(matval,0,sizeof(matval));
						for(int o=0;o<K;o++)
						{
							for(int current_route=0;current_route<column_arcs_global[d][o].size();current_route++)
							{
								int var=column_index_global[d][o][current_route];
								

								int r_subset=column_node_global[d][o][current_route][(*it)[0]]>0?1:0+column_node_global[d][o][current_route][(*it)[1]]>0?1:0+column_node_global[d][o][current_route][(*it)[2]]>0?1:0;
								//cout<<"var, r_subset\t"<<var<<"\t"<<r_subset<<endl;
								
								//if(r_subset>1){cout<<"r_subset"<<r_subset<<endl;}
								if(r_subset>1.5)
								{
									// cout<<"flag 2\t"<<var-N*K<<"\t"<<x_temp[var]<<endl;
									flag_subrow=flag_subrow+x_temp[var]*1;
									matind[non_zero_add]=var;
									matval[non_zero_add++]=1;
									
								}
								// else
								// {
								// 	matval[non_zero_add++]=0;
								// }
							}
							
						}
						// cout<<"flag_subrow"<<flag_subrow<<endl;

						
						if(flag_subrow>1+zero)//new_added add the new cut to the model
						{
							// cout<<"SRC: larger than 1 !!!!!!!"<<(*it)[0]<<"_"<<(*it)[1]<<"_"<<(*it)[2]<<endl;
							double   rhs[1]={1};
							char     sense[1]={'L'};
							char     **rowname=NULL;
							int      matbeg[1]={0};
							

							int NUMROWS;
							int NUMNZ;

							NUMROWS=1;
							NUMNZ=non_zero_add;

							//rhs=(double*) calloc(NUMROWS,sizeof(double));
							//sense =(char*) calloc(NUMROWS,sizeof(char));
							rowname =new char*[NUMROWS];
							rowname[0] =new char[256];
							//matbeg = (int *) malloc (NUMROWS * sizeof(int));
							sprintf(rowname[0],"subrow_%d",cur_numrows+num_new_cuts);
							
							// cout<<"wrtie prob\n";
							//status=CPXwriteprob(env_MASTER,lp_MASTER,"master_before_src_Problem.lp",NULL);
							// cout<<"finish wrtie prob\n";
							
							status = CPXaddrows (env_MASTER,lp_MASTER,0 , NUMROWS, NUMNZ,rhs,sense, matbeg,matind, matval, NULL, rowname);
							//by columns, matbeg is the begin of each column, matind is the row, and matval is the coefficient.
							//matbeg[j] containing the index of the beginning of column j and matcnt[j] containing the number of entries in column j
							//For each k, matind[k] specifies the row number of the corresponding coefficient, matval[k]
							if ( status )  
							{
								exit(-1);
							}

							//status=CPXwriteprob(env_MASTER,lp_MASTER,"master_aft_src_Problem.lp",NULL);
							// exit(-5);

							
							vector<int> assigned_cut_single=vector<int>(4,-1);
							assigned_cut_single[0]=(*it)[0];
							assigned_cut_single[1]=(*it)[1];
							assigned_cut_single[2]=(*it)[2];
							assigned_cut_single[3]=cur_numrows+num_new_cuts;
							num_new_cuts++;
							
							// cout<<"assigned_cuts_global[d].size()\t"<<assigned_cuts_global[d].size()<<endl;
							row_point_indicator[d][(*it)[0]-K].push_back(assigned_cuts_global[d].size());
							row_point_indicator[d][(*it)[1]-K].push_back(assigned_cuts_global[d].size());
							row_point_indicator[d][(*it)[2]-K].push_back(assigned_cuts_global[d].size());

							assigned_cuts_global[d].push_back(assigned_cut_single);

							if(unassigned_cuts_global[d].size()>1)
							{
								it=unassigned_cuts_global[d].erase(it);
							}
							else
							{	
								//elete unassigned_cuts_global[d].back();
								//unassigned_cuts_global[d].pop_back();
								unassigned_cuts_global[d].clear();
								it=unassigned_cuts_global[d].begin();
							}	
							

							//free(sense);
							for (int j=0;j<NUMROWS;j++)
							{
								delete [] rowname[j];
							}
							delete [] rowname;
							//free(rhs);
							//free(matbeg);
							
						}
						else
						{
							it++;
							// cout<<"it++"<<endl;
						}
						// if (num_new_cuts>=Q_max)
						// 	break;
					}
				}
				else
				{
					break;
				}
			}


			
		
			delete [] x_temp;
			free(matind);
			free(matval);

			// cout<<"after SRC pro"<<endl;
			//status=CPXwriteprob(env_MASTER,lp_MASTER,"master_p_src_Problem.lp",NULL);

			// cout<<"exit SRC section"<<endl;

			// cout<<"num_new_cuts\t"<<num_new_cuts<<endl;
			/*
			if(num_new_cuts>0)
			{
				cout<<"since num_new_cuts>0, master_solve_lp"<<endl;
				// // master_solve_lp(tolerance);
				// cout<<"src before cpxlpopt"<<endl;
				// status=CPXlpopt(env_MASTER,lp_MASTER);
				// cout<<"src after cpxlpopt"<<endl;

				// cout<<"exit master_solve_lp"<<endl;

				
				// exit(-5);


			}
			else
			{
				// cout<<"break here\n";
				break;
				//return 1;
			}*/
		}
		// cout<<"after if"<<endl;
		

	}

	// cout<<"end_after src pro"<<endl;

	status=CPXlpopt(env_MASTER,lp_MASTER);
	if(status!=0) {
		printf("error in CPXlpopt\n");

		return M;
	}
	
	CPXgetobjval(env_MASTER,lp_MASTER,&current_LP);

	/*	
	ofstream destFile2("routes_arcs.txt",ios::out);
    if(!destFile2) 
	{
		destFile2.close(); 
		exit (-1);
	}
	for(int d = 0; d < day;d++)
	{
		for (int o=0;o<K;o++)
		{
			for (int it = 0; it != column_arcs_global[d][o].size();it++)
			{
				for(int node=0; node< N+K;node++)
				{
					destFile2 <<column_arcs_global[d][o][it][node]<< " "; 
				}
				destFile2 <<"\n";
			}	
		}
	}
	destFile2.close();
	*/
	// cout<<"end_master_solve_lp"<<endl;
	return current_LP;
}
/*****************************************************************/

/*****************************************************************/
bool master_check_integrality_arc()
{
	status=CPXlpopt(env_MASTER,lp_MASTER);

	if(status!=0) {
		printf("error in CPXlpopt\n");
		exit(-1);
	}
	int lpstat;
	lpstat=CPXgetstat(env_MASTER,lp_MASTER);
	if(lpstat!=1)
	{	
		//exit(-1);
	}
	bool integer=true;
	int n_var=CPXgetnumcols(env_MASTER,lp_MASTER);
	double *x_master=new double[n_var];
	status=CPXgetx(env_MASTER,lp_MASTER,x_master,0,n_var-1); 

	if(status!=0)
	{
		printf("error in CPXgetx master_check_integrality_node\n");
		exit(-1);
	}


	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			for(int vertex_i=0;vertex_i<N+K;vertex_i++)
			{
				for(int vertex_j=0;vertex_j<N+K;vertex_j++)
				{
					double xi_value=0.0;
					for(int current_route=0;current_route<column_arcs_global[d][o].size();current_route++)
					{
						int var=column_index_global[d][o][current_route];
						if(column_arcs_global[d][o][current_route][vertex_j]==vertex_i)
						{
							xi_value=xi_value+x_master[var]*1;
						}
						else
						{
							xi_value=xi_value+x_master[var]*0;
						}
					}

					

					if ((fabs(xi_value - floor(xi_value)) > EPSILON_BP) && (fabs(xi_value - floor(xi_value) - 1.0)> EPSILON_BP))
					{
						integer=0;
						delete [] x_master;
						return integer;
					}
				}
			}		
		}
	}

	delete [] x_master;
	
	return integer;
}
/*****************************************************************/

/*****************************************************************/
bool master_check_integrality_node()
{
	status=CPXlpopt(env_MASTER,lp_MASTER);

	if(status!=0) {
		printf("error in CPXlpopt\n");
		exit(-1);
	}
	int lpstat;
	lpstat=CPXgetstat(env_MASTER,lp_MASTER);
	if(lpstat!=1)
	{	
		//exit(-1);
	}
	bool integer=true;
	int n_var=CPXgetnumcols(env_MASTER,lp_MASTER);
	double* x_master=new double[n_var];

	status=CPXgetx(env_MASTER,lp_MASTER,x_master,0,n_var-1);
	if(status!=0)
	{
		printf("error in CPXgetx check_integrality_arc\n");
	}


	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			for(int vertex_i=0;vertex_i<N+K;vertex_i++)
			{
				double collected_i=0;

				for(int current_route=0;current_route<column_arcs_global[d][o].size();current_route++)
				{
					int var=column_index_global[d][o][current_route];
					double xi_value=x_master[var];

					if(xi_value>10e-6 && column_arcs_global[d][o][current_route][vertex_i] > -1 + 10e-6 )
					{
						collected_i=xi_value+collected_i;
					}
				}

				if((fabs(collected_i-floor(collected_i)) > EPSILON_BP) && (fabs(collected_i-floor(collected_i)-1.0)>EPSILON_BP))
				{
					integer=0;
				
					
					delete [] x_master;

					return integer;
				}
			}
		}
	}

	delete [] x_master;
	return integer;

}
/*****************************************************************/

/*****************************************************************/
bool master_check_integrality_u()
{
	status=CPXlpopt(env_MASTER,lp_MASTER);

	if(status!=0) {
		printf("error in CPXlpopt\n");
		exit(-1);
	}
	int lpstat;
	lpstat=CPXgetstat(env_MASTER,lp_MASTER);
	if(lpstat!=1)
	{	
		//exit(-1);
	}
	bool integer=true;
	int n_var=CPXgetnumcols(env_MASTER,lp_MASTER);
	double* x_master=new double[n_var];

	status=CPXgetx(env_MASTER,lp_MASTER,x_master,0,n_var-1);
	if(status!=0)
	{
		printf("error in CPXgetx check_integrality_arc\n");
	}

	
	int temp;
	for(int i=0;i<K;i++)
	{
		for(int j=0;j<N;j++)
		{
			temp=i*N+j;
			double xi_value=x_master[temp];


			if((fabs(xi_value-floor(xi_value)) >= 1/M) && (fabs(xi_value-floor(xi_value)-1.0)>=1/M))
			{
				integer=0;
				
				delete [] x_master;

				return integer;
			}

		}
	}	

	delete [] x_master;
	return integer;

}
/*****************************************************************/

/*****************************************************************/
bool branch_select_u_branching(int* node_i,int* node_j)
{
	int n_var=CPXgetnumcols(env_MASTER,lp_MASTER);
	double *x_master=new double[n_var];
	status=CPXgetx(env_MASTER,lp_MASTER,x_master,0,n_var-1); //x_master get the optimal RMP solution for this node

	if(status!=0)
	{
		printf("error in CPXgetx branch_select_node_branching\n");
		exit(-1);
	}
	int temp;
	double criteria=0.0;
	bool nodebranch=false;
	for(int i=0;i<K;i++)
	{
		for(int j=0;j<N;j++)
		{
			if(status_u_selection[i][j]!=0)
			{
				continue;
			}
			else
			{
				temp=i*N+j;
			    double xi_value=x_master[temp];

				if((fabs(xi_value-floor(xi_value)) >=1/M) && (fabs(xi_value-floor(xi_value)-1.0)>1/M))
				{
					if(criteria<xi_value)
					{
						criteria=xi_value;
						*node_i=i;
						*node_j=j+K;
						nodebranch=true;
					}
				}
			}
		}
	}
	delete [] x_master;
	return nodebranch;
}
/*****************************************************************/

/*****************************************************************/
bool branch_select_node_branching(int* map_d,int*map_o,int* node_i)
{
	int n_var=CPXgetnumcols(env_MASTER,lp_MASTER);
	double *x_master=new double[n_var];
	status=CPXgetx(env_MASTER,lp_MASTER,x_master,0,n_var-1); 

	if(status!=0)
	{
		printf("error in CPXgetx branch_select_node_branching\n");
		exit(-1);
	}

	double criteria=0.0;
	
	bool nodebranch=false;
	
	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			for(int vertex_i=0;vertex_i<N+K;vertex_i++)
			{
				if(status_node_selection[d][o][vertex_i]!=0)
				{
					continue;
				}
				else
				{
					double collected_i=0;
					for(int current_route=0;current_route<column_arcs_global[d][o].size();current_route++)
					{
						int varnum=CPXgetnumcols(env_MASTER,lp_MASTER);
						int var=column_index_global[d][o][current_route];
						double xi_value=x_master[var];
						if(xi_value>10e-6 && column_arcs_global[d][o][current_route][vertex_i] > -1 + 10e-6 )
						{
							collected_i=collected_i+xi_value;
						}

					}

					if((fabs(collected_i-floor(collected_i)) > EPSILON_BP) && (fabs(collected_i-floor(collected_i)-1.0)>EPSILON_BP))
					{
						if(vertex_i<K)
						{
							*node_i=vertex_i;
							*map_d=d;
							*map_o=o;
							nodebranch=true;
							delete [] x_master;
							return nodebranch;
						}

						if(criteria<collected_i)
						{
							criteria=collected_i;
							*node_i=vertex_i;
							*map_d=d;
							*map_o=o;
							nodebranch=true;
						}
					}
				}

				
			}
		}
	}

	delete [] x_master;
	return nodebranch;
}
/*****************************************************************/

/*****************************************************************/
LPnode* branch_u_enforce(data* Homecare_instance,int node_i,int node_j,CPXLPptr currentLPptr,double best_incumbent_current,int level)
{
	if (level>1)
	{
		whether_cut=0;
	}
	//cout<<"begin_branch_u_enforce"<<endl;
	counter_all_nodes++;
	CPXLPptr lp_clone_u_enforce=CPXcloneprob(env_MASTER,currentLPptr,&status);
	

	if(status)
	{
		fprintf (stderr,"CPXcloneprob enforce failed.\n");
		exit(-1);
	}

	counter_u_enforce_branching++;

	int temp_u_selection=status_u_selection[node_i][node_j-K];
	status_u_selection[node_i][node_j-K]=1;

	
	int ind;
	double d;
	char lu;
//	cout<<"\tnode_i\t"<<node_i<<"\tnode_j\t"<<node_j<<endl;
	ind=node_i*N+node_j-K;
	d=1.0;
	lu='L';
			
	status=CPXchgbds(env_MASTER,lp_clone_u_enforce,1,&ind,&lu,&d);
	if (status != 0)
	{
		cout  << "error in CPXchgbds \n";
		exit(-1);
	}

	lu='U';
	status=CPXchgbds(env_MASTER,lp_clone_u_enforce,1,&ind,&lu,&d);
	if (status != 0)
	{
		cout  << "error in CPXchgbds \n";
		exit(-1);
	}

	lp_MASTER=lp_clone_u_enforce;
	//status=CPXwriteprob(env_MASTER,lp_MASTER,"lp_clone_u_enforce1.lp",NULL);
	double current_LP=master_solve_lp(Homecare_instance);

	//cout<<"current_LP\t"<<current_LP<<"\t"<<best_incumbent_current<<endl;
	//status=CPXwriteprob(env_MASTER,lp_clone_u_enforce,"lp_clone_u_enforce2.lp",NULL);
	
	if(current_LP>=best_incumbent_current)
	{
		LPnode* u_enforceNode=new LPnode;
		(*u_enforceNode).current_LP=M;
		(*u_enforceNode).key_lp=NULL;
		(*u_enforceNode).column_arcs_global_branch.clear();
		(*u_enforceNode).column_index_global_branch.clear();
		(*u_enforceNode).column_node_global_branch.clear();
		(*u_enforceNode).assigned_cuts_global_branch.clear();
		(*u_enforceNode).unassigned_cuts_global_branch.clear();
		(*u_enforceNode).row_point_indicator_branch.clear();

		(*u_enforceNode).Node_travelcost=NULL;
		(*u_enforceNode).Node_traveltime=NULL;
		(*u_enforceNode).Node_status_u_selection=NULL;
		(*u_enforceNode).Node_status_node_couple=NULL;
		(*u_enforceNode).Node_status_node_selection=NULL;

		if(lp_clone_u_enforce!=NULL)
		{
			status = CPXfreeprob (env_MASTER, &lp_clone_u_enforce);
			if ( status ) {
				fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
			}
		}

		
		status_u_selection[node_i][node_j-K]=temp_u_selection;
		

		return u_enforceNode;
	}
	else
	{
	

		LPnode* u_enforceNode=new LPnode;
		
		(*u_enforceNode).level=level;
		(*u_enforceNode).key_lp=lp_clone_u_enforce;
		(*u_enforceNode).node_i=node_i;
		(*u_enforceNode).node_j=node_j;
		(*u_enforceNode).branch_name="u_enforce";
		(*u_enforceNode).current_LP=current_LP;
		(*u_enforceNode).number=counter_all_nodes;
		(*u_enforceNode).branch_type=5;



		(*u_enforceNode).column_arcs_global_branch=column_arcs_global;
		(*u_enforceNode).column_index_global_branch=column_index_global;
		(*u_enforceNode).column_node_global_branch=column_node_global;
		(*u_enforceNode).assigned_cuts_global_branch=assigned_cuts_global;
		(*u_enforceNode).unassigned_cuts_global_branch=unassigned_cuts_global;
		(*u_enforceNode).row_point_indicator_branch=row_point_indicator;

		(*u_enforceNode).Node_travelcost=new double***[day];
		(*u_enforceNode).Node_traveltime=new double***[day];

		for(int d=0;d<day;d++)
		{
			(*u_enforceNode).Node_travelcost[d]=new double**[K];
			(*u_enforceNode).Node_traveltime[d]=new double**[K];
			for (int o=0;o<K;o++)
			{
				(*u_enforceNode).Node_travelcost[d][o]=new double*[N+K];
				(*u_enforceNode).Node_traveltime[d][o]=new double*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*u_enforceNode).Node_travelcost[d][o][i]=new double[N+K];
					(*u_enforceNode).Node_traveltime[d][o][i]=new double[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*u_enforceNode).Node_travelcost[d][o][i][j]=travel_cost*travelcost[d][o][i][j];
						(*u_enforceNode).Node_traveltime[d][o][i][j]=traveltime[d][o][i][j];
					}
				}
			}

		}

		(*u_enforceNode).Node_status_node_couple=new int***[day];
		for(int d=0;d<day;d++)
		{
			(*u_enforceNode).Node_status_node_couple[d]=new int**[K];
			for (int o=0;o<K;o++)
			{
				(*u_enforceNode).Node_status_node_couple[d][o]=new int*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*u_enforceNode).Node_status_node_couple[d][o][i]=new int[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*u_enforceNode).Node_status_node_couple[d][o][i][j]=status_node_couple[d][o][i][j];
					}
				}
			}
		}

		(*u_enforceNode).Node_status_u_selection=new int*[K];
		for(int i=0;i<K;i++)
		{
			(*u_enforceNode).Node_status_u_selection[i]=new int[N];
			for(int j=0;j<N;j++)
			{
				(*u_enforceNode).Node_status_u_selection[i][j]=status_u_selection[i][j];
			}
		}

	
		(*u_enforceNode).Node_status_node_selection=new int**[day];
		for(int d=0;d<day;d++)
		{
			(*u_enforceNode).Node_status_node_selection[d]=new int*[K];
			for (int o=0;o<K;o++)
			{
				(*u_enforceNode).Node_status_node_selection[d][o]=new int[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*u_enforceNode).Node_status_node_selection[d][o][i]=status_node_selection[d][o][i];
				}
			}
		}

		
		status_u_selection[node_i][node_j-K]=temp_u_selection;
		return u_enforceNode;
	}
}
/*****************************************************************/

/*****************************************************************/
LPnode* branch_u_forbidden(data* Homecare_instance,int node_i,int node_j,CPXLPptr currentLPptr,double best_incumbent_current, int level)
{
	if (level>1)
	{
		whether_cut=0;
	}
	// cout<<"begin_branch_u_forbidden"<<endl;
	counter_all_nodes++;
	CPXLPptr lp_clone_u_forbidden=CPXcloneprob(env_MASTER,currentLPptr,&status);
	
	if(status)
	{
		fprintf (stderr,"CPXcloneprob enforce failed.\n");
		exit(-1);
	}

	counter_u_forbidden_branching++;

	int temp_u_selection=status_u_selection[node_i][node_j-K];
	status_u_selection[node_i][node_j-K]=-1;

	int *temp_node_selection;
	temp_node_selection = new int [day];
	for(int d=0;d<day;d++)
	{
		temp_node_selection[d]=status_node_selection[d][node_i][node_j-K];
		status_node_selection[d][node_i][node_j-K]=-1;
	}


	int ind;
	double dd;
	char lu;

	ind=node_i*N+node_j-K;
	dd=0.0;
	lu='U';
			
	status=CPXchgbds(env_MASTER,lp_clone_u_forbidden,1,&ind,&lu,&dd);
	if (status != 0)
	{
		cout  << "error in CPXchgbds \n";
		exit(-1);
	}

	
	for(int d=0;d<day;d++)
	{
		for(int i=0;i<column_arcs_global[d][node_i].size();i++)
		{
			if(column_arcs_global[d][node_i][i][node_j] != -1)
			{
				int var_index=column_index_global[d][node_i][i];
				ind=var_index;
				dd=0.0;
				lu='U';
			
				status=CPXchgbds(env_MASTER,lp_clone_u_forbidden,1,&ind,&lu,&dd);
				if (status != 0)
				{
					cout  << "error in CPXchgbds \n";
					exit(-1);
				}
			}
		}
	}
	
	for(int d=0;d<day;d++)
	{
		for(int j=0;j<N+K;j++)
		{
			if(j!=node_j)
			{
				travelcost[d][node_i][node_j][j]=M;
				traveltime[d][node_i][node_j][j]=M;
	
			}
		}
	

		for(int i=0;i<N+K;i++)
		{
			if(i!=node_j)
			{
				travelcost[d][node_i][i][node_j]=M;
				traveltime[d][node_i][i][node_j]=M;
			}
		}
	}


	lp_MASTER=lp_clone_u_forbidden;

	double current_LP=master_solve_lp(Homecare_instance);
	//CPXwriteprob(env_MASTER,lp_MASTER,"branch_u_forbidden.lp",NULL);

	if(current_LP>=best_incumbent_current)
	{

		LPnode* u_forbiddenNode=new LPnode;

		(*u_forbiddenNode).current_LP=M;
		(*u_forbiddenNode).key_lp=NULL;
		(*u_forbiddenNode).column_arcs_global_branch.clear();
		(*u_forbiddenNode).column_index_global_branch.clear();
		(*u_forbiddenNode).column_node_global_branch.clear();
		(*u_forbiddenNode).assigned_cuts_global_branch.clear();
		(*u_forbiddenNode).unassigned_cuts_global_branch.clear();
		(*u_forbiddenNode).row_point_indicator_branch.clear();
		(*u_forbiddenNode).Node_travelcost=NULL;
		(*u_forbiddenNode).Node_traveltime=NULL;
		(*u_forbiddenNode).Node_status_u_selection=NULL;
		(*u_forbiddenNode).Node_status_node_couple=NULL;
		(*u_forbiddenNode).Node_status_node_selection=NULL;

		if(lp_clone_u_forbidden!=NULL)
		{
			status = CPXfreeprob (env_MASTER, &lp_clone_u_forbidden);
			if ( status ) {
				fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
			}
		}

		
		status_u_selection[node_i][node_j-K]=temp_u_selection;
		for(int d=0;d<day;d++)
		{
			status_node_selection[d][node_i][node_j-K]=temp_node_selection[d];
		}
	
		delete [] temp_node_selection;
		return u_forbiddenNode;
	}
	else
	{

		LPnode* u_forbiddenNode=new LPnode;
		
		(*u_forbiddenNode).level=level;
		(*u_forbiddenNode).key_lp=lp_clone_u_forbidden;
		(*u_forbiddenNode).node_i=node_i;
		(*u_forbiddenNode).node_j=node_j;
		(*u_forbiddenNode).branch_name="u_forbidden";
		(*u_forbiddenNode).current_LP=current_LP;
		(*u_forbiddenNode).number=counter_all_nodes;
		(*u_forbiddenNode).branch_type=6;



		(*u_forbiddenNode).column_arcs_global_branch=column_arcs_global;
		(*u_forbiddenNode).column_index_global_branch=column_index_global;
		(*u_forbiddenNode).column_node_global_branch=column_node_global;
		(*u_forbiddenNode).assigned_cuts_global_branch=assigned_cuts_global;
		(*u_forbiddenNode).unassigned_cuts_global_branch=unassigned_cuts_global;
		(*u_forbiddenNode).row_point_indicator_branch=row_point_indicator;

		(*u_forbiddenNode).Node_travelcost=new double***[day];
		(*u_forbiddenNode).Node_traveltime=new double***[day];

		for(int d=0;d<day;d++)
		{
			(*u_forbiddenNode).Node_travelcost[d]=new double**[K];
			(*u_forbiddenNode).Node_traveltime[d]=new double**[K];
			for (int o=0;o<K;o++)
			{
				(*u_forbiddenNode).Node_travelcost[d][o]=new double*[N+K];
				(*u_forbiddenNode).Node_traveltime[d][o]=new double*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*u_forbiddenNode).Node_travelcost[d][o][i]=new double[N+K];
					(*u_forbiddenNode).Node_traveltime[d][o][i]=new double[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*u_forbiddenNode).Node_travelcost[d][o][i][j]=travel_cost*travelcost[d][o][i][j];
						(*u_forbiddenNode).Node_traveltime[d][o][i][j]=traveltime[d][o][i][j];
					}
				}
			}

		}

		(*u_forbiddenNode).Node_status_node_couple=new int***[day];
		for(int d=0;d<day;d++)
		{
			(*u_forbiddenNode).Node_status_node_couple[d]=new int**[K];
			for (int o=0;o<K;o++)
			{
				(*u_forbiddenNode).Node_status_node_couple[d][o]=new int*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*u_forbiddenNode).Node_status_node_couple[d][o][i]=new int[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*u_forbiddenNode).Node_status_node_couple[d][o][i][j]=status_node_couple[d][o][i][j];
					}
				}
			}
		}

		(*u_forbiddenNode).Node_status_u_selection=new int*[K];
		for(int i=0;i<K;i++)
		{
			(*u_forbiddenNode).Node_status_u_selection[i]=new int[N];
			for(int j=0;j<N;j++)
			{
				(*u_forbiddenNode).Node_status_u_selection[i][j]=status_u_selection[i][j];
			}
		}

		
		(*u_forbiddenNode).Node_status_node_selection=new int**[day];
		for(int d=0;d<day;d++)
		{
			(*u_forbiddenNode).Node_status_node_selection[d]=new int*[K];
			for (int o=0;o<K;o++)
			{
				(*u_forbiddenNode).Node_status_node_selection[d][o]=new int[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*u_forbiddenNode).Node_status_node_selection[d][o][i]=status_node_selection[d][o][i];
				}
			}
		}

		
		status_u_selection[node_i][node_j-K]=temp_u_selection;
		for(int d=0;d<day;d++)
		{
			status_node_selection[d][node_i][node_j-K]=temp_node_selection[d];
		}
		
		delete [] temp_node_selection;
		return u_forbiddenNode;
	}
}
/*****************************************************************/

/*****************************************************************/
LPnode* branch_enforce(data* Homecare_instance,int map_d,int map_o,int node_i,CPXLPptr currentLPptr,double best_incumbent_current, int level)
{
	if (level>1)
	{
		whether_cut=0;
	}
	counter_all_nodes++;

	CPXLPptr lp_clone_enforce=CPXcloneprob(env_MASTER,currentLPptr,&status);
	
	if(status)
	{
		fprintf (stderr,"CPXcloneprob enforce failed.\n");
		exit(-1);
	}

	counter_enforce_branching++;

	int temp_node_selection=status_node_selection[map_d][map_o][node_i];
	status_node_selection[map_d][map_o][node_i]=1;


	int n_row=CPXgetnumrows(env_MASTER,lp_clone_enforce);

	int row_node_i;
	if (node_i<K)
	{
		row_node_i=day*N+map_d*K+node_i;
	}
	else
	{
		row_node_i=map_d*N+node_i-K;
	}

	int cnt_enforce=1;


	int *indices_enforce=(int*) calloc(cnt_enforce,sizeof(int));
	indices_enforce[0]=row_node_i;

	char *sense_enforce=(char*) calloc(cnt_enforce,sizeof(char));
	sense_enforce[0]='E';

	status=CPXchgsense(env_MASTER,lp_clone_enforce,cnt_enforce,indices_enforce,sense_enforce);
	if(status)
	{
		fprintf (stderr, "CPXchgsense enforce failed.\n");
		exit(-1);
	}

	free(indices_enforce);
	free(sense_enforce);
	




	int ind;
	double d;
	char lu;
	for(int k=0;k<K;k++)
	{
		if(k!=map_o)
		{
			for(int i=0;i<column_arcs_global[map_d][k].size();i++)
			{
				if(column_arcs_global[map_d][k][i][node_i] != -1)
				{
					int var_index=column_index_global[map_d][k][i];
					ind=var_index;
					d=0.0;
					lu='U';
			
					status=CPXchgbds(env_MASTER,lp_clone_enforce,1,&ind,&lu,&d);
					if (status != 0)
					{
						cout  << "error in CPXchgbds \n";
						exit(-1);
					}
				}
			}

			for(int j=0;j<N+K;j++)
			{
				if(j!=node_i)
				{
					travelcost[map_d][k][node_i][j]=M;
					traveltime[map_d][k][node_i][j]=M;
	
				}
			}

			for(int i=0;i<N+K;i++)
			{
				if(i!=node_i)
				{
					travelcost[map_d][k][i][node_i]=M;
					traveltime[map_d][k][i][node_i]=M;
				}
			}
		}
	}

	
	// cout<<"branch_enforce mp solve start\n";
	lp_MASTER=lp_clone_enforce;
	double current_LP=master_solve_lp(Homecare_instance);
	//CPXwriteprob(env_MASTER,lp_MASTER,"branch_enforce.lp",NULL);
	// cout<<"branch_enforce mp solve end\n";
	if(current_LP>=best_incumbent_current)
	{

		LPnode* enforceNode=new LPnode;

		(*enforceNode).current_LP=M;
		(*enforceNode).key_lp=NULL;
		(*enforceNode).column_arcs_global_branch.clear();
		(*enforceNode).column_index_global_branch.clear();
		(*enforceNode).column_node_global_branch.clear();
		(*enforceNode).assigned_cuts_global_branch.clear();
		(*enforceNode).unassigned_cuts_global_branch.clear();
		(*enforceNode).row_point_indicator_branch.clear();
		(*enforceNode).Node_travelcost=NULL;
		(*enforceNode).Node_traveltime=NULL;
		(*enforceNode).Node_status_u_selection=NULL;
		(*enforceNode).Node_status_node_couple=NULL;
		(*enforceNode).Node_status_node_selection=NULL;

		if(lp_clone_enforce!=NULL)
		{
			status = CPXfreeprob (env_MASTER, &lp_clone_enforce);
			if ( status ) {
				fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
			}
		}

		
		status_node_selection[map_d][map_o][node_i]=temp_node_selection;
	
		return enforceNode;


	}
	else
	{
	

		LPnode* enforceNode=new LPnode;
		(*enforceNode).level=level;
		(*enforceNode).key_lp=lp_clone_enforce;
		(*enforceNode).node_i=node_i;
		(*enforceNode).map_d=map_d;
		(*enforceNode).map_o=map_o;
		(*enforceNode).branch_name="enforce";
		(*enforceNode).current_LP=current_LP;
		(*enforceNode).number=counter_all_nodes;
		(*enforceNode).branch_type=1;



		(*enforceNode).column_arcs_global_branch=column_arcs_global;
		(*enforceNode).column_index_global_branch=column_index_global;
		(*enforceNode).column_node_global_branch=column_node_global;
		(*enforceNode).assigned_cuts_global_branch=assigned_cuts_global;
		(*enforceNode).unassigned_cuts_global_branch=unassigned_cuts_global;
		(*enforceNode).row_point_indicator_branch=row_point_indicator;

		

		(*enforceNode).Node_travelcost=new double***[day];
		(*enforceNode).Node_traveltime=new double***[day];

		for(int d=0;d<day;d++)
		{
			(*enforceNode).Node_travelcost[d]=new double**[K];
			(*enforceNode).Node_traveltime[d]=new double**[K];
			for (int o=0;o<K;o++)
			{
				(*enforceNode).Node_travelcost[d][o]=new double*[N+K];
				(*enforceNode).Node_traveltime[d][o]=new double*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*enforceNode).Node_travelcost[d][o][i]=new double[N+K];
					(*enforceNode).Node_traveltime[d][o][i]=new double[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*enforceNode).Node_travelcost[d][o][i][j]=travel_cost*travelcost[d][o][i][j];
						(*enforceNode).Node_traveltime[d][o][i][j]=traveltime[d][o][i][j];
					}
				}
			}

		}

		(*enforceNode).Node_status_node_couple=new int***[day];
		for(int d=0;d<day;d++)
		{
			(*enforceNode).Node_status_node_couple[d]=new int**[K];
			for (int o=0;o<K;o++)
			{
				(*enforceNode).Node_status_node_couple[d][o]=new int*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*enforceNode).Node_status_node_couple[d][o][i]=new int[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*enforceNode).Node_status_node_couple[d][o][i][j]=status_node_couple[d][o][i][j];
					}
				}
			}
		}

		(*enforceNode).Node_status_u_selection=new int*[K];
		for(int i=0;i<K;i++)
		{
			(*enforceNode).Node_status_u_selection[i]=new int[N];
			for(int j=0;j<N;j++)
			{
				(*enforceNode).Node_status_u_selection[i][j]=status_u_selection[i][j];
			}
		}

		
		(*enforceNode).Node_status_node_selection=new int**[day];
		for(int d=0;d<day;d++)
		{
			(*enforceNode).Node_status_node_selection[d]=new int*[K];
			for (int o=0;o<K;o++)
			{
				(*enforceNode).Node_status_node_selection[d][o]=new int[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*enforceNode).Node_status_node_selection[d][o][i]=status_node_selection[d][o][i];
				}
			}
		}

		
		status_node_selection[map_d][map_o][node_i]=temp_node_selection;
		
		return enforceNode;
	}
}
/*****************************************************************/

/*****************************************************************/
LPnode* branch_forbidden(data* Homecare_instance,int map_d,int map_o,int node_i,CPXLPptr currentLPptr,double best_incumbent_current, int level)
{
	if (level>1)
	{
		whether_cut=0;
	}
	counter_all_nodes++;


	CPXLPptr lp_clone_forbidden=CPXcloneprob(env_MASTER,currentLPptr,&status);
	//status = CPXwriteprob(env_MASTER, lp_clone_forbidden, "tourpackge_forbidden_before.lp", NULL);

	if(status)
	{
		fprintf (stderr, "CPXcloneprob forbidden failed.\n");
		exit(-1);
	}

	counter_forbidden_branching++;

	int temp_node_selection=status_node_selection[map_d][map_o][node_i];
	status_node_selection[map_d][map_o][node_i]=-1;

	

	int ind;
	double d;
	char lu;

	for(int i=0;i<column_arcs_global[map_d][map_o].size();i++)
	{
		if(column_arcs_global[map_d][map_o][i][node_i] != -1)
		{
			int var_index=column_index_global[map_d][map_o][i];
			ind=var_index;
			d=0.0;
			lu='U';
			
			status=CPXchgbds(env_MASTER,lp_clone_forbidden,1,&ind,&lu,&d);
			if (status != 0)
			{
				cout  << "error in CPXchgbds \n";
				exit(-1);
			}
		}

	}

	


	for(int j=0;j<N+K;j++)
	{
		if(j!=node_i)
		{
			travelcost[map_d][map_o][node_i][j]=M;
			traveltime[map_d][map_o][node_i][j]=M;
	
		}
	}

	for(int i=0;i<N+K;i++)
	{
		if(i!=node_i)
		{
			travelcost[map_d][map_o][i][node_i]=M;
			traveltime[map_d][map_o][i][node_i]=M;
		}
	}



	lp_MASTER=lp_clone_forbidden;
	double current_LP=master_solve_lp(Homecare_instance);
	//CPXwriteprob(env_MASTER,lp_MASTER,"branch_forbidden.lp",NULL);

	if(current_LP>=best_incumbent_current)
	{
		LPnode* forbiddenNode=new LPnode;

		(*forbiddenNode).current_LP=10e-10;
		(*forbiddenNode).key_lp=NULL;
		(*forbiddenNode).column_arcs_global_branch.clear();
		(*forbiddenNode).column_index_global_branch.clear();
		(*forbiddenNode).column_node_global_branch.clear();
		(*forbiddenNode).assigned_cuts_global_branch.clear();
		(*forbiddenNode).unassigned_cuts_global_branch.clear();
		(*forbiddenNode).row_point_indicator_branch.clear();
		(*forbiddenNode).Node_travelcost=NULL;
		(*forbiddenNode).Node_traveltime=NULL;
		(*forbiddenNode).Node_status_u_selection=NULL;
		(*forbiddenNode).Node_status_node_couple=NULL;
		(*forbiddenNode).Node_status_node_selection=NULL;

		if(lp_clone_forbidden!=NULL)
		{
			status = CPXfreeprob (env_MASTER, &lp_clone_forbidden);
			if ( status ) {
				fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
			}
		}

		//recover
		status_node_selection[map_d][map_o][node_i]=temp_node_selection;
		//recover travel matrix
		
		for(int j=0;j<N+K;j++)
	    {
		    if(j!=node_i)
		    {
				travelcost[map_d][map_o][node_i][j]=copy_travelcost[map_d][map_o][node_i][j];
				traveltime[map_d][map_o][node_i][j]=copy_traveltime[map_d][map_o][node_i][j];
		
			}
		}

		for(int i=0;i<N+K;i++)
		{
			if(i!=node_i)
			{
				travelcost[map_d][map_o][i][node_i]=copy_travelcost[map_d][map_o][i][node_i];
				traveltime[map_d][map_o][i][node_i]=copy_traveltime[map_d][map_o][i][node_i];
			}
		}

		return forbiddenNode;


	}
	else
	{
		

		LPnode* forbiddenNode=new LPnode;
		(*forbiddenNode).level=level;
		(*forbiddenNode).key_lp=lp_clone_forbidden;
		(*forbiddenNode).node_i=node_i;
		(*forbiddenNode).map_d=map_d;
		(*forbiddenNode).map_o=map_o;
		(*forbiddenNode).branch_name="forbidden";
		(*forbiddenNode).current_LP=current_LP;
		(*forbiddenNode).number=counter_all_nodes;
		(*forbiddenNode).branch_type=2;


		(*forbiddenNode).column_arcs_global_branch=column_arcs_global;
		(*forbiddenNode).column_index_global_branch=column_index_global;
		(*forbiddenNode).column_node_global_branch=column_node_global;
		(*forbiddenNode).assigned_cuts_global_branch=assigned_cuts_global;
		(*forbiddenNode).unassigned_cuts_global_branch=unassigned_cuts_global;
		(*forbiddenNode).row_point_indicator_branch=row_point_indicator;


		(*forbiddenNode).Node_travelcost=new double***[day];
		(*forbiddenNode).Node_traveltime=new double***[day];

		for(int d=0;d<day;d++)
		{
			(*forbiddenNode).Node_travelcost[d]=new double**[K];
			(*forbiddenNode).Node_traveltime[d]=new double**[K];
			for (int o=0;o<K;o++)
			{
				(*forbiddenNode).Node_travelcost[d][o]=new double*[N+K];
				(*forbiddenNode).Node_traveltime[d][o]=new double*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*forbiddenNode).Node_travelcost[d][o][i]=new double[N+K];
					(*forbiddenNode).Node_traveltime[d][o][i]=new double[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*forbiddenNode).Node_travelcost[d][o][i][j]=travel_cost*travelcost[d][o][i][j];
						(*forbiddenNode).Node_traveltime[d][o][i][j]=traveltime[d][o][i][j];
					}
				}
			}

		}

		(*forbiddenNode).Node_status_node_couple=new int***[day];
		for(int d=0;d<day;d++)
		{
			(*forbiddenNode).Node_status_node_couple[d]=new int**[K];
			for (int o=0;o<K;o++)
			{
				(*forbiddenNode).Node_status_node_couple[d][o]=new int*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*forbiddenNode).Node_status_node_couple[d][o][i]=new int[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*forbiddenNode).Node_status_node_couple[d][o][i][j]=status_node_couple[d][o][i][j];
					}
				}
			}
		}

		(*forbiddenNode).Node_status_u_selection=new int*[K];
		for(int i=0;i<K;i++)
		{
			(*forbiddenNode).Node_status_u_selection[i]=new int[N];
			for(int j=0;j<N;j++)
			{
				(*forbiddenNode).Node_status_u_selection[i][j]=status_u_selection[i][j];
			}
		}

		//a 2-d matrix denotes whether a node i in route q is branching or not:free 0, forbiden 1, enforce -1
		(*forbiddenNode).Node_status_node_selection=new int**[day];
		for(int d=0;d<day;d++)
		{
			(*forbiddenNode).Node_status_node_selection[d]=new int*[K];
			for (int o=0;o<K;o++)
			{
				(*forbiddenNode).Node_status_node_selection[d][o]=new int[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*forbiddenNode).Node_status_node_selection[d][o][i]=status_node_selection[d][o][i];
				}
			}
		}

		//recover everything with pointer
		status_node_selection[map_d][map_o][node_i]=temp_node_selection;
		//travel matrix no recover here	

		for(int j=0;j<N+K;j++)
	    {
		    if(j!=node_i)
		    {
				travelcost[map_d][map_o][node_i][j]=copy_travelcost[map_d][map_o][node_i][j];
				traveltime[map_d][map_o][node_i][j]=copy_traveltime[map_d][map_o][node_i][j];
		
			}
		}

		for(int i=0;i<N+K;i++)
		{
			if(i!=node_i)
			{
				travelcost[map_d][map_o][i][node_i]=copy_travelcost[map_d][map_o][i][node_i];
				traveltime[map_d][map_o][i][node_i]=copy_traveltime[map_d][map_o][i][node_i];
			}
		}

		

		return forbiddenNode;
	}
}
/*****************************************************************/

/*****************************************************************/
bool branch_select_couple_branching(int* map_d,int*map_o,int* node_i,int* node_j)//ѡ��
{
	int n_var=CPXgetnumcols(env_MASTER,lp_MASTER);
	double *x_master=new double[n_var];
	status=CPXgetx(env_MASTER,lp_MASTER,x_master,0,n_var-1); //x_master get the optimal RMP solution for this node

	if(status!=0)
	{
		printf("error in CPXgetx branch_select_couple_branching\n");
		exit(-1);
	}


	double min_incumbent=Z_UB;
	double dummy=0.0;	

	for(int d=0;d<day;d++)
	{
		for (int o=0;o<K;o++)
		{
			for(int vertex_i=0;vertex_i<N+K;vertex_i++)
			{
				for(int vertex_j=0;vertex_j<N+K;vertex_j++)
				{
					if(vertex_i!=vertex_j)
					{
						if((traveltime[d][o][vertex_i][vertex_j]==M)|| status_node_couple[d][o][vertex_i][vertex_j]!=0)
						{
							continue;
						}
						else
						{
							double xi_value=0.0;
							for(int current_route=0;current_route<column_arcs_global[d][o].size();current_route++)
							{
								int var=column_index_global[d][o][current_route];
								if(column_arcs_global[d][o][current_route][vertex_j]==vertex_i)
								{
									xi_value=xi_value+x_master[var]*1;
								}
								else
								{
									xi_value=xi_value+x_master[var]*0;
								}
							}
							if((fabs(xi_value-floor(xi_value))>EPSILON_BP) && (fabs(xi_value-floor(xi_value)-1.0)>EPSILON_BP))
							{
								if(fabs(xi_value-0.50)<min_incumbent && fabs(xi_value-0.50)<0.50)
								{
									min_incumbent=fabs(xi_value-0.50);
									*map_d=d;
									*map_o=o;
									*node_i=vertex_i;
									*node_j=vertex_j;
									dummy=xi_value;//an indicator to check whether to find an minimized arc
								}
							}
						}
					}
				}
			}
		}
	}


	if((fabs(dummy-floor(dummy))>EPSILON_BP) && (fabs(dummy-floor(dummy)-1.0)>EPSILON_BP))
	{
		delete [] x_master;
		return true;
	}
	else
	{
		delete [] x_master;
		return false;
	}
		
}
/*****************************************************************/

/*****************************************************************/
LPnode* branch_fixed(data* Homecare_instance,int map_d,int map_o,int node_i,int node_j,CPXLPptr currentLPptr, int level)//��ô��
{
	if (level>1)
	{
		whether_cut=0;
	}
	counter_all_nodes++;

	CPXLPptr lp_clone_fixed=CPXcloneprob(env_MASTER,currentLPptr,&status);

	if(status)
	{
		fprintf (stderr, "CPXcloneprob failed.\n");
		exit(-1);
	}

	counter_fixed_branching++;

	int temp_node_couple=status_node_couple[map_d][map_o][node_i][node_j];
	status_node_couple[map_d][map_o][node_i][node_j]=1;

	int n_var=CPXgetnumcols(env_MASTER,lp_clone_fixed);

	int ind;
	double d;
	char lu;

	for(int current_route=0;current_route<column_arcs_global[map_d][map_o].size();current_route++)
	{
		

		if(column_arcs_global[map_d][map_o][current_route][node_j]!=node_i)
		{
			int var=column_index_global[map_d][map_o][current_route];
		

			ind=var;
			d=0.0;
			lu='U';
			
			status=CPXchgbds(env_MASTER,lp_clone_fixed,1,&ind,&lu,&d);
			if (status != 0)
			{
				cout  << "error in CPXchgbds \n";
				exit(-1);
			}
		}
	}

	for(int i=0;i<N+K;i++)
	{		
		if(i!=node_i)
		{	
			travelcost[map_d][map_o][i][node_j]=M;
			traveltime[map_d][map_o][i][node_j]=M;
		}
	}

	for(int j=0;j<N+K;j++)
	{
		if(j!=node_j)
		{
			travelcost[map_d][map_o][node_i][j]=M;
			traveltime[map_d][map_o][node_i][j]=M;
		}
	}


	lp_MASTER=lp_clone_fixed;
	double current_LP=master_solve_lp(Homecare_instance);
	//CPXwriteprob(env_MASTER,lp_MASTER,"branch_fixed.lp",NULL);

	if(current_LP>=best_incumbent)
	{
		LPnode* fixedNode = new LPnode;
		fixedNode->current_LP=current_LP;
		fixedNode->column_arcs_global_branch.clear();
		fixedNode->column_index_global_branch.clear();
		fixedNode->column_node_global_branch.clear();
		fixedNode->assigned_cuts_global_branch.clear();
		fixedNode->unassigned_cuts_global_branch.clear();
		fixedNode->row_point_indicator_branch.clear();
		fixedNode->key_lp=NULL;

		(*fixedNode).Node_travelcost=NULL;
		(*fixedNode).Node_traveltime=NULL;
		(*fixedNode).Node_status_u_selection=NULL;
		(*fixedNode).Node_status_node_couple=NULL;
		(*fixedNode).Node_status_node_selection=NULL;

		if(lp_clone_fixed!=NULL)
		{
			status = CPXfreeprob (env_MASTER, &lp_clone_fixed);
			if ( status ) {
				fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
			}
		}

		//recover

		status_node_couple[map_d][map_o][node_i][node_j]=temp_node_couple;

		for(int i=0;i<N+K;i++)
		{		
			if(i!=node_i)
			{	
				travelcost[map_d][map_o][i][node_i]=copy_travelcost[map_d][map_o][i][node_i];
				traveltime[map_d][map_o][i][node_i]=copy_traveltime[map_d][map_o][i][node_i];
			}
		}

		for(int j=0;j<N+K;j++)
		{
			if(j!=node_j)
			{
				travelcost[map_d][map_o][node_i][j]=copy_travelcost[map_d][map_o][node_i][j];
				traveltime[map_d][map_o][node_i][j]=copy_traveltime[map_d][map_o][node_i][j];
			}
		}

		return fixedNode;
	}
	else
	{
		LPnode* fixedNode = new LPnode;
        (*fixedNode).level=level;
		(*fixedNode).key_lp=lp_clone_fixed;
		(*fixedNode).node_i=node_i;
		(*fixedNode).node_j=node_j;
		(*fixedNode).map_d=map_d;
		(*fixedNode).map_o=map_o;
		fixedNode->branch_name="fixed";
		fixedNode->current_LP=current_LP;
		fixedNode->number=counter_all_nodes;
		fixedNode->branch_type=3;

		fixedNode->column_arcs_global_branch=column_arcs_global;
		fixedNode->column_index_global_branch=column_index_global;
		fixedNode->column_node_global_branch=column_node_global;
		fixedNode->assigned_cuts_global_branch=assigned_cuts_global;
		fixedNode->unassigned_cuts_global_branch=unassigned_cuts_global;
		fixedNode->row_point_indicator_branch=row_point_indicator;

		(*fixedNode).Node_travelcost=new double***[day];
		(*fixedNode).Node_traveltime=new double***[day];

		for(int d=0;d<day;d++)
		{
			(*fixedNode).Node_travelcost[d]=new double**[K];
			(*fixedNode).Node_traveltime[d]=new double**[K];
			for (int o=0;o<K;o++)
			{
			    (*fixedNode).Node_travelcost[d][o]=new double*[N+K];
				(*fixedNode).Node_traveltime[d][o]=new double*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*fixedNode).Node_travelcost[d][o][i]=new double[N+K];
				    (*fixedNode).Node_traveltime[d][o][i]=new double[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*fixedNode).Node_travelcost[d][o][i][j]=travel_cost*travelcost[d][o][i][j];
						(*fixedNode).Node_traveltime[d][o][i][j]=traveltime[d][o][i][j];
					}
				}
			}

		}

		(*fixedNode).Node_status_node_couple=new int***[day];
		for(int d=0;d<day;d++)
		{
			(*fixedNode).Node_status_node_couple[d]=new int**[K];
			for (int o=0;o<K;o++)
			{
				(*fixedNode).Node_status_node_couple[d][o]=new int*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*fixedNode).Node_status_node_couple[d][o][i]=new int[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*fixedNode).Node_status_node_couple[d][o][i][j]=status_node_couple[d][o][i][j];
					}
				}
			}
		}

		(*fixedNode).Node_status_u_selection=new int*[K];
		for(int i=0;i<K;i++)
		{
			(*fixedNode).Node_status_u_selection[i]=new int[N];
			for(int j=0;j<N;j++)
			{
				(*fixedNode).Node_status_u_selection[i][j]=status_u_selection[i][j];
			}
		}

		(*fixedNode).Node_status_node_selection=new int**[day];
		for(int d=0;d<day;d++)
		{
			(*fixedNode).Node_status_node_selection[d]=new int*[K];
			for (int o=0;o<K;o++)
			{
				(*fixedNode).Node_status_node_selection[d][o]=new int[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*fixedNode).Node_status_node_selection[d][o][i]=status_node_selection[d][o][i];
				}
			}
		}

		status_node_couple[map_d][map_o][node_i][node_j]=temp_node_couple;
	

		for(int j=0;j<N+K;j++)
	    {
		    if(j!=node_i)
		    {
				travelcost[map_d][map_o][node_i][j]=copy_travelcost[map_d][map_o][node_i][j];
				traveltime[map_d][map_o][node_i][j]=copy_traveltime[map_d][map_o][node_i][j];
			}
		}

		for(int i=0;i<N+K;i++)
		{
			if(i!=node_i)
			{
				travelcost[map_d][map_o][i][node_i]=copy_travelcost[map_d][map_o][i][node_i];
				traveltime[map_d][map_o][i][node_i]=copy_traveltime[map_d][map_o][i][node_i];
			}
		}
		return fixedNode;

	}
}
/*****************************************************************/

/*****************************************************************/
LPnode* branch_release(data* Homecare_instance,int map_d,int map_o,int node_i,int node_j,CPXLPptr currentLPptr, int level)
{
	if (level>1)
	{
		whether_cut=0;
	}
	counter_all_nodes++;

	CPXLPptr lp_clone_release=CPXcloneprob(env_MASTER,currentLPptr,&status);

	if(status)
	{
		fprintf (stderr, "CPXcloneprob failed.\n");
		exit(-1);
	}

	counter_realease_branching++;

	int temp_node_couple=status_node_couple[map_d][map_o][node_i][node_j];
	status_node_couple[map_d][map_o][node_i][node_j]=-1;

	int n_var=CPXgetnumcols(env_MASTER,lp_clone_release);

	int ind;
	double d;
	char lu;

	for(int current_route=0;current_route<column_arcs_global[map_d][map_o].size();current_route++)
	{
		if(column_arcs_global[map_d][map_o][current_route][node_j]==node_i)
		{
			int var=column_index_global[map_d][map_o][current_route];
			ind=var;
			d=0.0;
			lu='U';
			
			status=CPXchgbds(env_MASTER,lp_clone_release,1,&ind,&lu,&d);
			if (status != 0)
			{
				cout  << "error in CPXchgobj \n";
				exit(-1);
			}

		}
	}

	travelcost[map_d][map_o][node_i][node_j]=M;
	traveltime[map_d][map_o][node_i][node_j]=M;
	lp_MASTER=lp_clone_release;
	double current_LP=master_solve_lp(Homecare_instance);
	//CPXwriteprob(env_MASTER,lp_MASTER,"branch_release.lp",NULL);

	if(current_LP >=best_incumbent)
	{
		LPnode* releaseNode=new LPnode;
		releaseNode->current_LP=current_LP;
		releaseNode->column_arcs_global_branch.clear();
		releaseNode->column_index_global_branch.clear();
		releaseNode->column_node_global_branch.clear();
		releaseNode->assigned_cuts_global_branch.clear();
		releaseNode->unassigned_cuts_global_branch.clear();
		releaseNode->row_point_indicator_branch.clear();
		releaseNode->key_lp=NULL;

	

		(*releaseNode).Node_travelcost=NULL;
		(*releaseNode).Node_traveltime=NULL;
		(*releaseNode).Node_status_node_couple=NULL;
		(*releaseNode).Node_status_u_selection=NULL;
		(*releaseNode).Node_status_node_selection=NULL;

		if(lp_clone_release!=NULL)
		{
			status = CPXfreeprob (env_MASTER, &lp_clone_release);
			if ( status ) {
				fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
			}
		}

		//recover 
		status_node_couple[map_d][map_o][node_i][node_j]=temp_node_couple;
		travelcost[map_d][map_o][node_i][node_j]=copy_travelcost[map_d][map_o][node_i][node_j];
		traveltime[map_d][map_o][node_i][node_j]=copy_traveltime[map_d][map_o][node_i][node_j];


		return releaseNode;
	}
	else
	{
		LPnode* releaseNode=new LPnode;
		(*releaseNode).level=level;
		releaseNode->node_i=node_i;
		(*releaseNode).key_lp=lp_clone_release;
		(*releaseNode).node_j=node_j;
		(*releaseNode).map_d=map_d;
		(*releaseNode).map_o=map_o;
		(*releaseNode).branch_name="release";
		(*releaseNode).current_LP=current_LP;
		(*releaseNode).number=counter_all_nodes;
		(*releaseNode).branch_type=4;



		(*releaseNode).column_arcs_global_branch=column_arcs_global;
		(*releaseNode).column_index_global_branch=column_index_global;
		(*releaseNode).column_node_global_branch=column_node_global;
		(*releaseNode).assigned_cuts_global_branch=assigned_cuts_global;
		(*releaseNode).unassigned_cuts_global_branch=unassigned_cuts_global;
		(*releaseNode).row_point_indicator_branch=row_point_indicator;

		(*releaseNode).Node_travelcost=new double***[day];
		(*releaseNode).Node_traveltime=new double***[day];

		for(int d=0;d<day;d++)
		{
			(*releaseNode).Node_travelcost[d]=new double**[K];
			(*releaseNode).Node_traveltime[d]=new double**[K];
			for (int o=0;o<K;o++)
			{
			   (*releaseNode).Node_travelcost[d][o]=new double*[N+K];
				(*releaseNode).Node_traveltime[d][o]=new double*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*releaseNode).Node_travelcost[d][o][i]=new double[N+K];
				    (*releaseNode).Node_traveltime[d][o][i]=new double[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*releaseNode).Node_travelcost[d][o][i][j]=travel_cost*travelcost[d][o][i][j];
						(*releaseNode).Node_traveltime[d][o][i][j]=traveltime[d][o][i][j];
					}
				}
			}
		}

		(*releaseNode).Node_status_node_couple=new int***[day];
		for(int d=0;d<day;d++)
		{
			(*releaseNode).Node_status_node_couple[d]=new int**[K];
			for (int o=0;o<K;o++)
			{
				(*releaseNode).Node_status_node_couple[d][o]=new int*[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*releaseNode).Node_status_node_couple[d][o][i]=new int[N+K];
					for(int j=0;j<N+K;j++)
					{
						(*releaseNode).Node_status_node_couple[d][o][i][j]=status_node_couple[d][o][i][j];
					}
				}
			}
		}

		(*releaseNode).Node_status_u_selection=new int*[K];
		for(int i=0;i<K;i++)
		{
			(*releaseNode).Node_status_u_selection[i]=new int[N];
			for(int j=0;j<N;j++)
			{
				(*releaseNode).Node_status_u_selection[i][j]=status_u_selection[i][j];
			}
		}

		(*releaseNode).Node_status_node_selection=new int**[day];
		for(int d=0;d<day;d++)
		{
			(*releaseNode).Node_status_node_selection[d]=new int*[K];
			for (int o=0;o<K;o++)
			{
				(*releaseNode).Node_status_node_selection[d][o]=new int[N+K];
				for(int i=0;i<N+K;i++)
				{
					(*releaseNode).Node_status_node_selection[d][o][i]=status_node_selection[d][o][i];
				}
			}
		}

		//recover 
		status_node_couple[map_d][map_o][node_i][node_j]=temp_node_couple;
		travelcost[map_d][map_o][node_i][node_j]=copy_travelcost[map_d][map_o][node_i][node_j];
		traveltime[map_d][map_o][node_i][node_j]=copy_traveltime[map_d][map_o][node_i][node_j];



		return releaseNode;

	}
}
/*****************************************************************/

/*****************************************************************/
double MIPSolver_Bound(CPXLPptr currentLPptr)
{
	CPXLPptr lp_mip_bound=CPXcloneprob(env_MASTER,currentLPptr,&status);
	if(status)
	{
		fprintf (stderr, "CPXcloneprob failed.\n");
		exit(-1);

	}

	int n_var=CPXgetnumcols(env_MASTER,lp_mip_bound);

	
	int* colindice=(int*) calloc(n_var,sizeof(int));
	char* type=(char*) calloc(n_var,sizeof(char));
	
	double d=1.0;
	char lu='U';
	int ind;


	//starting from N*K is the z variables
	//0-N*K-1 are u_ij varaibles
	for(int i=0;i<n_var;i++)
	{
		
		if(i<N*K)
		{
			colindice[i]=i;
			type[i]='C';
		}
		if(i>=N*K)
		{
			colindice[i]=i;
			type[i]='B';

			ind=i;
			status=CPXchgbds(env_MASTER,lp_mip_bound,1,&ind,&lu,&d);
			if (status != 0)
			{
				cout  << "error in CPXchgobj \n";
				exit(-1);
			}

		}
		
	}


/*	
	int counter=0;
	int terminationloop=20000;
	for(int i=N*K;i<n_var;i++)
	{
		d=1.0;
		char lu='U';
		
		int rndnum= rand() % (n_var-N*K) + N*K;
		ind=rndnum;
		counter++;
		status=CPXchgbds(env_MASTER,lp_mip_bound,1,&ind,&lu,&d);
		if (status != 0)
		{
			cout  << "error in CPXchgobj \n";
			exit(-1);
		}

		if(counter>terminationloop)
		{
			break;
		}

		
	}
*/
	
	status=CPXchgctype(env_MASTER,lp_mip_bound,n_var,colindice,type);

	if(status)
	{
		printf("error in CPXchgctype\n");
		exit(-1);
	}

	free(colindice);
	free(type);
	//status=CPXwriteprob(env_MASTER,lp_mip_bound,"MIPProblem.lp",NULL);
	

	//CPXsetintparam (env_MASTER, CPX_PARAM_SCRIND, CPX_ON);

	double total_time_limit_MIP=0.05*TIME_LIMIT;
	status = CPXsetdblparam (env_MASTER, CPX_PARAM_TILIM,total_time_limit_MIP);
	if(status)
	{
		printf("error in CPXsetdblparam\n");
		return M;
	}

	status=CPXmipopt(env_MASTER,lp_mip_bound);
		
	if(status)
	{
		printf("error in CPXmipopt\n");
		return M;
	}

	double current_LP;
	status=CPXgetobjval(env_MASTER,lp_mip_bound,&current_LP);
	
	if(status)
	{
		printf("error in CPXgetobjval in MIPSolver_Bound\n");
		return M;
	}

	double* x_mip=new double[n_var];

	status=CPXgetmipx(env_MASTER,lp_mip_bound,x_mip,0,n_var-1);

	if(current_LP<best_incumbent)
	{
		//status =CPXsolwrite(env_MASTER,lp_mip_bound,"MIPSolution.txt");

		//std:ofstream outfile;
		//outfile.open("MIPcolumn.txt",std::ios::out);

		for(int d=0;d<day;d++)
		{
			for(int o=0;o<K;o++)
			{
				for(int i=0;i<N+K;i++)
				{
					cities_visited[d][o][i]=-1;
				}
			}
		}

		for(int d=0;d<day;d++)
		{	
			for(int o=0;o<K;o++)
			{
				for(int i=0;i<column_arcs_global[d][o].size();i++)
				{
					int var_index=column_index_global[d][o][i];
				
					if(x_mip[var_index]>1e-10)
					{
							//outfile<<d<<'\t'<<o<<'\t'<<var_index<<'\t'<<x_mip[var_index]<<'\n';
							for(int j=0;j<column_arcs_global[d][o][i].size();j++)
							{
								//outfile<<column_arcs_global[d][o][i][j]<<"\t";
							
								cities_visited[d][o][j]=column_arcs_global[d][o][i][j];
							}
							//outfile<<'\n';
					

							// int *routes_seq;
							// routes_seq=new int [N+K];
							// for(int numi=0;numi<N+K;numi++)
							// {
							// 	routes_seq[numi] = -1;
							// }

							// routes_seq[0]=o;
							// int col_for_seq=0;
							// int flag=1;
							// while(flag==1)
							// {
							// 	for(int col=0;col<N+K;col++)
							// 	{
					    	// 		if(column_arcs_global[d][o][i][col]==routes_seq[col_for_seq])
					    	// 		{
							// 			if(col==o)
							// 			{
							//     			flag=0;
							// 				break;
						    // 			}
							// 			col_for_seq++;
							// 			routes_seq[col_for_seq]=col;
					 		// 			break;
					    	// 		}
				    		// 	}
							// }
							// routes_seq[col_for_seq+1]=o;
							// //outfile<<"visulization"<<'\n';
							// for(int j=0;j<N+2;j++)
							// {
							// //	outfile<<routes_seq[j]<<"\t";
							// }
							// //outfile<<'\n';
							// delete [] routes_seq;
					}
				}
			}
		}
	}
	else
	{
		current_LP=M;
	}

	status = CPXsetdblparam (env_MASTER, CPX_PARAM_TILIM,TIME_LIMIT);
	if (status)
	{
		printf ("error for CPX_PARAM_EPRHS\n");
	}


	status = CPXfreeprob(env_MASTER, &lp_mip_bound);
	if ( status ) 
	{
		fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
    }

	

	delete [] x_mip;
	return current_LP;
}
/*****************************************************************/

/*****************************************************************/
int branch_and_price(data* Homecare_instance, int level)
{
	
	
	// CPXsetintparam (env_MASTER, CPX_PARAM_SCRIND, CPX_ON);
	// CPXsetintparam (env_MASTER, CPX_PARAM_THREADS, 1);
 
	cout<<"begin_branch_and_price"<<endl;

	int optimalIndicator=0;//0 not optimal; 1 optimal

	STOP_TIME_LIMIT=false;
	if (!STOP_TIME_LIMIT)
	{
		Homecare_instance->stop_time=time(NULL);
		double current_time = (double) difftime(Homecare_instance->stop_time,Homecare_instance->start_time);

		//cout<<"current_time\t"<<current_time<<endl;

		if(current_time>TIME_LIMIT){
			STOP_TIME_LIMIT=true;
		}

		if (STOP_TIME_LIMIT){
			return -1;
		}
	}
	else
	{
		return -1;
	}

	priority_queue<LPnode> BP_Tree_pq;
	BP_nodes++;

	cout<<"root node start\n";
	int n_var,lpstat;
	double current_LP=master_solve_lp(Homecare_instance);
	// status=CPXwriteprob(env_MASTER,lp_MASTER,"IntegerProblem_pr08.lp",NULL);
	// exit(-1);
	double root_LP=current_LP;
	double last_lp_value=current_LP;
		
	cout<<"root node solved\n";

	if(root_LP==M)
	{

		status=CPXfreeprob(env_MASTER,&(lp_MASTER));
		if(status!=0) {printf("error in CPXfreeprob\n");exit(-2);}

		optimalIndicator=-1;
		cout<<"*********************************"<<endl;
		cout<<"Infeasible for LP! Not optimal"<<endl;
		cout<<"LP value in root node is\t"<<root_LP<<endl;
		cout<<"LP value in last node is\t"<<last_iter_LPvalue<<endl;
		cout<<"LB\t"<<best_incumbent<<endl;
		cout<<"Number of branch nodes\t"<<BP_nodes<<endl;
		cout<<"Number of total nodes\t"<<counter_all_nodes<<endl;
		cout<<"Final tours components of cities\n";

		if(optimalIndicator==-1)
		{
			Homecare_instance->stop_time=time(NULL);
			double duration = (double) difftime(Homecare_instance->stop_time,Homecare_instance->start_time);


			ofstream info_SUMMARY("info_BP.txt", ios::app);
		
			info_SUMMARY << fixed
					<< Homecare_instance->istname << "\t"
					<< optimalIndicator << "\t"
					<< duration  << "\t"
					<< root_LP << "\t"
					<< last_iter_LPvalue <<"\t"
					<< best_incumbent <<"\t"
					<< BP_nodes <<"\t"
					<< counter_all_nodes <<"\t"
					<< endl;
		}
	}


	if(level==0)
	{
		LPnode root;

		counter_all_nodes=1;

		root.level=0;
		root.key_lp=CPXcloneprob(env_MASTER,lp_MASTER,&status);

		root.column_arcs_global_branch=column_arcs_global;
		root.column_index_global_branch=column_index_global;
		root.column_node_global_branch=column_node_global;
		root.assigned_cuts_global_branch=assigned_cuts_global;
		root.unassigned_cuts_global_branch=unassigned_cuts_global;
		root.row_point_indicator_branch=row_point_indicator;
		root.current_LP=current_LP;
		
		root.Node_status_u_selection=status_u_selection;
		root.Node_status_node_couple=status_node_couple;
		root.Node_status_node_selection=status_node_selection;
		root.Node_travelcost=travelcost;
		root.Node_traveltime=traveltime;

		root.number=counter_all_nodes;
		root.branch_name="root";
		BP_Tree_pq.push(root);

		time_finish=time(NULL);
		current_time=(double)(time_finish-time_start)/(double)CLOCKS_PER_SEC;
		BP_lp_time=current_time;
	}

	bool integer_arc=master_check_integrality_arc();
	bool integer_u=master_check_integrality_u();

	//std:ofstream outfile;
	
	if(integer_arc)
	{
		if(best_incumbent>=current_LP)
		{
			best_incumbent=current_LP;
			//status=CPXsolwrite(env_MASTER,lp_MASTER,"IntegerSolution.txt");
			//status=CPXwriteprob(env_MASTER,lp_MASTER,"IntegerProblem.lp",NULL);

			n_var=CPXgetnumcols(env_MASTER,lp_MASTER);
			double* x_master=new double[n_var];

			status=CPXgetx(env_MASTER,lp_MASTER,x_master,0,n_var-1);
			if(status!=0)
			{
				printf("error in CPXgetx check_integrality_arc\n");
	
			}

			//outfile.open("IntegerSolutionColumn.txt",std::ios::out);
			for(int d=0;d<day;d++)
			{
				for(int o=0;o<K;o++)
				{
					for(int i=0;i<N+K;i++)
					{
						cities_visited[d][o][i]=-1;
					}
				}
			}
			for(int d=0;d<day;d++)
			{	
				for(int o=0;o<K;o++)
				{		
					for(int i=0;i<column_arcs_global[d][o].size();i++)
					{
						int var_index=column_index_global[d][o][i];
					
						if(x_master[var_index]>1e-10)
						{
							//outfile<<d<<'\t'<<o<<'\t'<<var_index<<'\t'<<x_master[var_index]<<'\n';
							if ((fabs(x_master[var_index] - floor(x_master[var_index])) > EPSILON_BP) && (fabs(x_master[var_index] - floor(x_master[var_index]) - 1.0)> EPSILON_BP))
							{
								cout<<"current outcome is not an integer solution"<<endl;
							}
							for(int j=0;j<column_arcs_global[d][o][i].size();j++)
							{
								//outfile<<column_arcs_global[d][o][i][j]<<"\t";
								
								cities_visited[d][o][j]=column_arcs_global[d][o][i][j];
							}
							//outfile<<'\n';
						

							// int *routes_seq;
							// routes_seq=new int [N+K];
							// for(int numi=0;numi<N+K;numi++)
							// {
							// 	routes_seq[numi] = -1;
							// }

							// routes_seq[0]=o;
							// int col_for_seq=0;
							// int flag=1;
							// while(flag==1)
							// {
							// 	for(int col=0;col<N+K;col++)
							// 	{
					    	// 		if(column_arcs_global[d][o][i][col]==routes_seq[col_for_seq])
					    	// 		{
							// 			if(col==o)
							// 			{
							//     			flag=0;
							// 				break;
						    // 			}
							// 			col_for_seq++;
							// 			routes_seq[col_for_seq]=col;
					 		// 			break;
					    	// 		}
				    		// 	}
							// }
							// routes_seq[col_for_seq+1]=o;
							// //outfile<<"visualization"<<'\n';
							// //for(int j=0;j<N+2;j++)
							// {
							// //	outfile<<routes_seq[j]<<"\t";
							// }
							// //outfile<<'\n';
							// delete [] routes_seq;
						}
					}
				}
			}

			delete [] x_master;
		}

		optimalIndicator=1;
		if(optimalIndicator==1)
		{


			Homecare_instance->stop_time=time(NULL);
			double duration = (double) difftime(Homecare_instance->stop_time,Homecare_instance->start_time);


			ofstream info_SUMMARY("info_BP.txt", ios::app);
		
			info_SUMMARY << fixed
					<< Homecare_instance->istname << "\t"
					<< optimalIndicator << "\t"
					<< duration  << "\t"
					<< root_LP << "\t"
					<< last_iter_LPvalue <<"\t"
					<< best_incumbent <<"\t"
					<< BP_nodes <<"\t"
					<< counter_all_nodes <<"\t"
					<< endl;
			info_SUMMARY.close();
		}

		status=CPXfreeprob(env_MASTER,&(lp_MASTER));
		if(status!=0) {printf("error in CPXfreeprob\n");exit(-2);}

		cout<<"current_LP"<<current_LP<<endl;
		int out_flag;
		for(int d=0;d<day;d++)
		{	
			for(int o=0;o<K;o++)
			{		
				out_flag=0;
				for (int j=0;j<N+K;j++)
				{
					if(cities_visited[d][o][j]!=-1)
					{
						out_flag=1;
					}
				}
				if(out_flag==1)
				{
					cout<<"This is tour "<<"day"<<d<<"doctor"<<o<<endl;
					for(int j=0;j<N+K;j++)
					{
						cout<<cities_visited[d][o][j]<<"\t";
					}
					cout<<endl;
				}
			}
		}
		cout<<"Solution\t"<<best_incumbent<<endl;
		return 1;// value 1 means that find an integer solution, and stop seraching for this branch
	}
	else
	{
		cout<<"Not integer!!\t" << integer_arc << "\tvalue\t" << current_LP <<  endl;
		best_incumbent=MIPSolver_Bound(lp_MASTER);
		cout<<best_incumbent<<endl;
	}

	

	while(!BP_Tree_pq.empty())
	{


		if (!STOP_TIME_LIMIT)
		{
			Homecare_instance->stop_time=time(NULL);
			double current_time =(double) difftime(Homecare_instance->stop_time,Homecare_instance->start_time);

			// cout<<"current_time\t"<<current_time<<endl;

			if(current_time>TIME_LIMIT){
				STOP_TIME_LIMIT=true;
			}
		}
		else
		{
			
			optimalIndicator=0;
			cout<<"*********************************"<<endl;
			cout<<"Exceed the time limit! Not optimal"<<endl;
			cout<<"LP value in root node is\t"<<root_LP<<endl;
			cout<<"LP value in last node is\t"<<last_iter_LPvalue<<endl;
			cout<<"LB\t"<<best_incumbent<<endl;
			cout<<"Number of branch nodes\t"<<BP_nodes<<endl;
			cout<<"Number of total nodes\t"<<counter_all_nodes<<endl;
			cout<<"Final tours components of cities\n";

			if(optimalIndicator==0)
			{
				Homecare_instance->stop_time=time(NULL);
				double duration = (double) difftime(Homecare_instance->stop_time,Homecare_instance->start_time);


				ofstream info_SUMMARY("info_BP.txt", ios::app);
			
				info_SUMMARY << fixed
						<< Homecare_instance->istname << "\t"
						<< optimalIndicator << "\t"
						<< duration  << "\t"
						<< root_LP << "\t"
						<< last_iter_LPvalue <<"\t"
						<< best_incumbent <<"\t"
						<< BP_nodes <<"\t"
						<< counter_all_nodes <<"\t"
						<< endl;
			}
		

			int out_flag;
			for(int d=0;d<day;d++)
			{	
				for(int o=0;o<K;o++)
				{		
					out_flag=0;
					for (int j=0;j<N+K;j++)
					{
						if(cities_visited[d][o][j]!=-1)
						{
							out_flag=1;
						}
					}
					if(out_flag==1)
					{
						cout<<"This is tour "<<"day"<<d<<"doctor"<<o<<endl;
						for(int j=0;j<N+K;j++)
						{
							cout<<cities_visited[d][o][j]<<"\t";
						}
						cout<<endl;
					}
				}
			}


			return -1;
		}
		LPnode currentNode=BP_Tree_pq.top();
		
		BP_Tree_pq.pop();

		BP_nodes++;
		cout<<"There are "<<BP_Tree_pq.size()<<" nodes in the Tree"<<endl;
		cout<<"best_incumbent\t"<<best_incumbent<<endl;

		lp_MASTER=currentNode.key_lp;
		double current_LP=(currentNode.current_LP); //since the coeff of obj are integers, the current_LP could round up
		cout<<"current_LP\t"<<current_LP<<endl;
		last_lp_value=current_LP;

		if(lp_MASTER==NULL||(fabs(current_LP-M)<10e-6)) 
		{

			cout<<"Prune by infeasible MASTER"<<endl;

			continue;
		}

		if(best_incumbent<=current_LP)
		{
			cout<<"Cutting branch by a bound!"<<endl;

			if(currentNode.key_lp!=NULL)
			{
				for(int d=0;d<day;d++)
				{
					for(int o=0;o<K;o++)
					{
						for(int i=0;i<N+K;i++)
						{
							delete [] currentNode.Node_travelcost[d][o][i];
							delete [] currentNode.Node_traveltime[d][o][i];
							delete [] currentNode.Node_status_node_couple[d][o][i];
						}
					}
				}

				for(int d=0;d<day;d++)
				{
					for(int o=0;o<K;o++)
					{
						delete [] currentNode.Node_travelcost[d][o];
						delete [] currentNode.Node_traveltime[d][o];
						delete [] currentNode.Node_status_node_couple[d][o];
						delete [] currentNode.Node_status_node_selection[d][o];
					}
				}

				for(int d=0;d<day;d++)
				{
					delete [] currentNode.Node_travelcost[d];
					delete [] currentNode.Node_traveltime[d];
					delete [] currentNode.Node_status_node_couple[d];
					delete [] currentNode.Node_status_node_selection[d];
				}

				delete [] currentNode.Node_travelcost;
				delete [] currentNode.Node_traveltime;
				delete [] currentNode.Node_status_node_couple;
				delete [] currentNode.Node_status_node_selection;

				for(int i=0;i<K;i++)
				{
					delete [] currentNode.Node_status_u_selection[i];
				}
				delete [] currentNode.Node_status_u_selection;

				status = CPXfreeprob (env_MASTER, &currentNode.key_lp);
				if ( status ) {
					fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
				}
			}
			continue;
		}

		status = CPXlpopt(env_MASTER,lp_MASTER);
		lpstat = CPXgetstat(env_MASTER,lp_MASTER);
		last_iter_LPvalue=current_LP;
		
		
		column_arcs_global=currentNode.column_arcs_global_branch;
		column_index_global=currentNode.column_index_global_branch;
		column_node_global=currentNode.column_node_global_branch;
		assigned_cuts_global=currentNode.assigned_cuts_global_branch;
		unassigned_cuts_global=currentNode.unassigned_cuts_global_branch;
		row_point_indicator=currentNode.row_point_indicator_branch;


		
		bool integer_arc=master_check_integrality_arc();

		if(integer_arc)
		{
			cout<<"integer!!\t" << integer_arc << "\tvalue\t" << current_LP <<  endl;

			if(best_incumbent>current_LP)
			{
				best_incumbent=current_LP;
				//status=CPXsolwrite(env_MASTER,lp_MASTER,"IntegerSolution.txt");
				//status=CPXwriteprob(env_MASTER,lp_MASTER,"IntegerProblem.lp",NULL);

				n_var=CPXgetnumcols(env_MASTER,lp_MASTER);
				double* x_master=new double[n_var];

				status=CPXgetx(env_MASTER,lp_MASTER,x_master,0,n_var-1);
				if(status!=0)
				{
					printf("error in CPXgetx check_integrality_arc\n");
					//exit(-1);
				}
				
				//outfile.open("IntegerSolutionColumn.txt",std::ios::out);
				
				for(int d=0;d<day;d++)
				{
					for(int o=0;o<K;o++)
					{
						for(int i=0;i<N+K;i++)
						{
							cities_visited[d][o][i]=-1;
						}
					}
				}

				for(int d=0;d<day;d++)
				{	
					for(int o=0;o<K;o++)
					{		
						for(int i=0;i<column_arcs_global[d][o].size();i++)
						{
							int var_index=column_index_global[d][o][i];
					
							if(x_master[var_index]>1e-10)
							{
								//outfile<<d<<'\t'<<o<<'\t'<<var_index<<'\t'<<x_master[var_index]<<'\n';
								if ((fabs(x_master[var_index] - floor(x_master[var_index])) > EPSILON_BP) && (fabs(x_master[var_index] - floor(x_master[var_index]) - 1.0)> EPSILON_BP))
								{
									cout<<"current outcome is not an integer solution"<<endl;
								}
								for(int j=0;j<column_arcs_global[d][o][i].size();j++)
								{
									//outfile<<column_arcs_global[d][o][i][j]<<"\t";
									//cout<<column_arcs_global[d][o][i][j]<<"\t";
									cities_visited[d][o][j]=column_arcs_global[d][o][i][j];
								}
								//outfile<<'\n';
								cout<<endl;
								
								// int *routes_seq;
								// routes_seq=new int [N+K];
								// for(int numi=0;numi<N+K;numi++)
								// {
								// 	routes_seq[numi] = -1;
								// }

								// routes_seq[0]=o;
								// int col_for_seq=0;
								// int flag=1;
								// while(flag==1)
								// {
								// 	for(int col=0;col<N+K;col++)
								// 	{
					    		// 		if(column_arcs_global[d][o][i][col]==routes_seq[col_for_seq])
					    		// 		{
								// 			if(col==o)
								// 			{
							    // 				flag=0;
								// 				break;
						    	// 			}
								// 			col_for_seq++;
								// 			routes_seq[col_for_seq]=col;
					 			// 			break;
					    		// 		}
				    			// 	}
								// }
								// routes_seq[col_for_seq+1]=o;
								// //outfile<<"visulization"<<'\n';
								// //or(int j=0;j<N+2;j++)
								// {
								// //	outfile<<routes_seq[j]<<"\t";
								// }
								// //outfile<<'\n';
								// delete [] routes_seq;
							}
						}
					}
				}
								
				
				delete [] x_master;
			}

			cout<<"Prune by finding an local optimal solution!"<<endl;
			
			lp_MASTER=NULL;
			if(currentNode.key_lp!=NULL)
			{
				for(int d=0;d<day;d++)
				{	
					for(int o=0;o<K;o++)
					{
						for(int i=0;i<N+K;i++)
						{
							delete [] currentNode.Node_travelcost[d][o][i];
							delete [] currentNode.Node_traveltime[d][o][i];
							delete [] currentNode.Node_status_node_couple[d][o][i];
						}
					}
				}
				for(int d=0;d<day;d++)
				{
					for(int o=0;o<K;o++)
					{
						delete [] currentNode.Node_travelcost[d][o];
						delete [] currentNode.Node_traveltime[d][o];
						delete [] currentNode.Node_status_node_couple[d][o];
						delete [] currentNode.Node_status_node_selection[d][o];
					}
				}

				for(int d=0;d<day;d++)
				{
					delete [] currentNode.Node_travelcost[d];
					delete [] currentNode.Node_traveltime[d];
					delete [] currentNode.Node_status_node_couple[d];
					delete [] currentNode.Node_status_node_selection[d];
				}

				for(int i=0;i<K;i++)
				{
					delete [] currentNode.Node_status_u_selection[i];
				}

				delete [] currentNode.Node_status_u_selection;
				delete [] currentNode.Node_travelcost;
				delete [] currentNode.Node_traveltime;
				delete [] currentNode.Node_status_node_couple;
				delete [] currentNode.Node_status_node_selection;

				status = CPXfreeprob (env_MASTER, &currentNode.key_lp);
				if ( status ) {
					fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
				}
			}
			continue;
		}
		else
		{
			for(int d=0;d<day;d++)
			{	
				for(int o=0;o<K;o++)
				{
					for(int i=0;i<N+K;i++)
					{
						for(int j=0;j<N+K;j++)
						{
							copy_travelcost[d][o][i][j]=currentNode.Node_travelcost[d][o][i][j];
							copy_traveltime[d][o][i][j]=currentNode.Node_traveltime[d][o][i][j];
						}
					}
				}
			}
			
			lp_MASTER=currentNode.key_lp;
			column_arcs_global=currentNode.column_arcs_global_branch;
			column_index_global=currentNode.column_index_global_branch;
			column_node_global=currentNode.column_node_global_branch;
			assigned_cuts_global=currentNode.assigned_cuts_global_branch;
			unassigned_cuts_global=currentNode.unassigned_cuts_global_branch;
			row_point_indicator=currentNode.row_point_indicator_branch;
			status_node_selection=currentNode.Node_status_node_selection;

			// cout<<"MIP Branch 1\n";
			if(BP_nodes%10==0)
			{
				double MIPBOUND=MIPSolver_Bound(lp_MASTER);
				if(MIPBOUND<best_incumbent)
					best_incumbent=MIPBOUND;
			}
			// cout<<"MIP Branch 2\n";
			bool integer_node=master_check_integrality_node();
			// cout<<"MIP Branch 3\n";

			if(!integer_node)
			{
				cout<<"Not integer on node !!\t" << integer_node << "\tvalue\t" << current_LP <<  endl;
				int map_select_d;
				int map_select_o;
				int node_select_i;

				
				bool _foundNode=branch_select_node_branching(&map_select_d,&map_select_o,&node_select_i);

				if(_foundNode)
				{
					column_arcs_global=currentNode.column_arcs_global_branch;
					column_index_global=currentNode.column_index_global_branch;
					column_node_global=currentNode.column_node_global_branch;
					assigned_cuts_global=currentNode.assigned_cuts_global_branch;
					unassigned_cuts_global=currentNode.unassigned_cuts_global_branch;
					row_point_indicator=currentNode.row_point_indicator_branch;
					lp_MASTER=currentNode.key_lp;
					
					node_level=currentNode.level;
					travelcost=currentNode.Node_travelcost;
					traveltime=currentNode.Node_traveltime;
					status_u_selection=currentNode.Node_status_u_selection;
					status_node_couple=currentNode.Node_status_node_couple;
					status_node_selection=currentNode.Node_status_node_selection;
				
					// cout<<"before branch_enforce \n";
					LPnode* child_enforce=branch_enforce(Homecare_instance,map_select_d,map_select_o,node_select_i,lp_MASTER,best_incumbent,node_level);
					if((*child_enforce).current_LP<best_incumbent)
					{
						BP_Tree_pq.push(*child_enforce);
					}
					// cout<<"finish branch_enforce \n";


					node_level=currentNode.level;			
					column_arcs_global=currentNode.column_arcs_global_branch;
					column_index_global=currentNode.column_index_global_branch;
					column_node_global=currentNode.column_node_global_branch;
					assigned_cuts_global=currentNode.assigned_cuts_global_branch;
					unassigned_cuts_global=currentNode.unassigned_cuts_global_branch;
					row_point_indicator=currentNode.row_point_indicator_branch;
					travelcost=currentNode.Node_travelcost;
					traveltime=currentNode.Node_traveltime;
					status_u_selection=currentNode.Node_status_u_selection;
					status_node_couple=currentNode.Node_status_node_couple;
					status_node_selection=currentNode.Node_status_node_selection;
					
					lp_MASTER=currentNode.key_lp;

					// cout<<"before branch_forbidden \n";
					LPnode* child_forbidden=branch_forbidden(Homecare_instance,map_select_d,map_select_o,node_select_i,lp_MASTER,best_incumbent,node_level);
					if((*child_forbidden).current_LP<best_incumbent)
					{
						BP_Tree_pq.push(*child_forbidden);
						
					}
					// cout<<"finish branch_forbidden \n";
				}
			}			
			else if (!integer_arc)
			{
				travelcost=currentNode.Node_travelcost;
				traveltime=currentNode.Node_traveltime;
				status_node_couple=currentNode.Node_status_node_couple;


				int map_d;
				int map_o;
				int node_i;
				int node_j;

				bool _foundArc=branch_select_couple_branching(&map_d,&map_o,&node_i,&node_j);
				


				if(_foundArc)
				{
					if(((status_node_selection[map_d][map_o][node_i]) >=1) ||((status_node_selection[map_d][map_o][node_j]) >=1) )
					{	
						node_level=currentNode.level;
						column_arcs_global=currentNode.column_arcs_global_branch;
						column_index_global=currentNode.column_index_global_branch;
						column_node_global=currentNode.column_node_global_branch;
						assigned_cuts_global=currentNode.assigned_cuts_global_branch;
						unassigned_cuts_global=currentNode.unassigned_cuts_global_branch;
						row_point_indicator=currentNode.row_point_indicator_branch;
						travelcost=currentNode.Node_travelcost;
						traveltime=currentNode.Node_traveltime;
						status_u_selection=currentNode.Node_status_u_selection;
						status_node_couple=currentNode.Node_status_node_couple;
						status_node_selection=currentNode.Node_status_node_selection;
						lp_MASTER=currentNode.key_lp;

						LPnode* child_fixed=branch_fixed(Homecare_instance,map_d,map_o,node_i,node_j,lp_MASTER,node_level);
						if((*child_fixed).current_LP<best_incumbent)
						{
							BP_Tree_pq.push(*child_fixed);
						}
						
						node_level=currentNode.level;
						column_arcs_global=currentNode.column_arcs_global_branch;
						column_index_global=currentNode.column_index_global_branch;
						column_node_global=currentNode.column_node_global_branch;
						assigned_cuts_global=currentNode.assigned_cuts_global_branch;
						unassigned_cuts_global=currentNode.unassigned_cuts_global_branch;
						row_point_indicator=currentNode.row_point_indicator_branch;
						travelcost=currentNode.Node_travelcost;
						traveltime=currentNode.Node_traveltime;
						status_u_selection=currentNode.Node_status_u_selection;
						status_node_couple=currentNode.Node_status_node_couple;
						status_node_selection=currentNode.Node_status_node_selection;
						lp_MASTER=currentNode.key_lp;

						LPnode* child_release=branch_release(Homecare_instance,map_d,map_o,node_i,node_j,lp_MASTER,node_level);
						
						if((*child_release).current_LP<best_incumbent)
						{
							BP_Tree_pq.push(*child_release);
						}
					}
					
				}
			}
						
			lp_MASTER=NULL;
			if(currentNode.key_lp!=NULL)
			{
				for(int d=0;d<day;d++)
				{	
					for(int o=0;o<K;o++)
					{
						for(int i=0;i<N+K;i++)
						{
							delete [] currentNode.Node_travelcost[d][o][i];
							delete [] currentNode.Node_traveltime[d][o][i];
							delete [] currentNode.Node_status_node_couple[d][o][i];
						}
					}
				}
				for(int d=0;d<day;d++)
				{
					for(int o=0;o<K;o++)
					{
						delete [] currentNode.Node_travelcost[d][o];
						delete [] currentNode.Node_traveltime[d][o];
						delete [] currentNode.Node_status_node_couple[d][o];
						delete [] currentNode.Node_status_node_selection[d][o];
					}
				}

				for(int d=0;d<day;d++)
				{
					delete [] currentNode.Node_travelcost[d];
					delete [] currentNode.Node_traveltime[d];
					delete [] currentNode.Node_status_node_couple[d];
					delete [] currentNode.Node_status_node_selection[d];
				}
				for(int i=0;i<K;i++)
				{
					delete [] currentNode.Node_status_u_selection[i];
				}

				delete [] currentNode.Node_status_u_selection;
				delete [] currentNode.Node_travelcost;
				delete [] currentNode.Node_traveltime;
				delete [] currentNode.Node_status_node_couple;
				delete [] currentNode.Node_status_node_selection;
				
				status = CPXfreeprob (env_MASTER, &currentNode.key_lp);
				if ( status ) {
					fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
				}
			}
		}
	}

	
	cout<<"******************************"<<endl;
	cout<<"LP value in root node is\t"<<root_LP<<endl;
	cout<<"LP value in last node is\t"<<last_iter_LPvalue<<endl;
	cout<<"Find solution OPTIMAL!"<<endl;
	cout<<"Solution\t"<<best_incumbent<<endl;
	cout<<"Number of branch nodes\t"<<BP_nodes<<endl;
	cout<<"Number of total nodes\t"<<counter_all_nodes<<endl;
	optimalIndicator=1;
	if(optimalIndicator==1)
	{
		Homecare_instance->stop_time=time(NULL);
		double duration = (double) difftime(Homecare_instance->stop_time,Homecare_instance->start_time);


		ofstream info_SUMMARY("info_BP.txt", ios::app);
	
		info_SUMMARY << fixed
				<< Homecare_instance->istname << "\t"
				<< optimalIndicator << "\t"
				<< duration  << "\t"
				<< root_LP << "\t"
				<< last_iter_LPvalue <<"\t"
				<< best_incumbent <<"\t"
				<< BP_nodes <<"\t"
				<< counter_all_nodes <<"\t"
				<< endl;
		info_SUMMARY.close();
	}

	cout<<"Final tours components of cities\n";
	
	int out_flag;
	for(int d=0;d<day;d++)
	{	
		for(int o=0;o<K;o++)
		{		
			out_flag=0;
			for (int j=0;j<N+K;j++)
			{
				if(cities_visited[d][o][j]!=-1)
				{
					out_flag=1;
				}
			}
			if(out_flag==1)
			{
				cout<<"This is tour "<<"day"<<d<<"doctor"<<o<<endl;
				for(int j=0;j<N+K;j++)
				{
					cout<<cities_visited[d][o][j]<<"\t";
				}
				cout<<endl;
			}
		}
	}
	cout<<"Solution\t"<<best_incumbent<<endl;
	return 0;
}
/*****************************************************************/

/*****************************************************************/
void travel_free()
{
	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			for(int i=0;i<N+K;i++)
			{
				delete [] travelcost[d][o][i];
				delete [] traveltime[d][o][i];
			}
		}
	}

	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			delete [] travelcost[d][o];
			delete [] traveltime[d][o];
		}
	}

	for(int d=0;d<day;d++)
	{
		delete [] travelcost[d];
		delete [] traveltime[d];
	}

	delete [] travelcost;
	delete [] traveltime;
}
/*****************************************************************/

/*****************************************************************/
void master_free()
{
	/////////////////////////////////////////////////////////////

	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			for(int i=0;i<N+K;i++)
			{
				//delete [] travelcost[d][o][i];
				//delete [] traveltime[d][o][i];
				delete [] copy_travelcost[d][o][i];
				delete [] copy_traveltime[d][o][i];
			}
		}
	}

	for(int d=0;d<day;d++)
	{
		for(int o=0;o<K;o++)
		{
			delete [] copy_travelcost[d][o];
			delete [] copy_traveltime[d][o];
		
		}
	}

	for(int d=0;d<day;d++)
	{
		delete [] copy_travelcost[d];
		delete [] copy_traveltime[d];
	}

	delete [] copy_travelcost;
	delete [] copy_traveltime;

	if(env_MASTER != NULL){
		status = CPXcloseCPLEX(&env_MASTER);
	}

	for (int i=0;i<N+K;i++)
	{
		delete [] people[i]; 
	}
	delete [] people;

	for (int i=0;i<N+K;i++)
	{
	    delete [] travel[i];
	}
	delete [] travel;

	for(int d=0; d<day; d++)
	{
		for (int i=0;i<N+K;i++)
		{
			delete [] daytravel[d][i];
		}
	}
	for(int d=0; d<day; d++)
	{
		delete [] daytravel[d];
	}
	delete [] daytravel;

	for(int d=0; d<day; d++)
	{
		for (int i=0;i<N+K;i++)
		{
			delete [] tempdaytravel[d][i];
		}
	}
	for(int d=0; d<day; d++)
	{
		delete [] tempdaytravel[d];
	}
	delete [] tempdaytravel;	
	 
	for(int d=0; d<day; d++)
	{
		for (int o=0;o<K;o++)
		{
			for (int i=0;i<N+K;i++)
			{
				delete [] daydoctravel[d][o][i];
			}
		}
	}
	for(int d=0; d<day; d++)
	{
		for (int o=0;o<K;o++)
		{
			delete [] daydoctravel[d][o];
		}
	}
	for(int d=0; d<day; d++)
	{
		delete [] daydoctravel[d];
	}
	delete [] daydoctravel;

	delete [] extra_routes;

	for (int i=0;i<K;i++)
	{
		delete [] costs_sum[i];
	}
	delete [] costs_sum;
	
	
	for (int i=0;i<N+K;i++)
	{
		delete [] sharev[i];
	}
	delete [] sharev;

	for (int i=0;i<N+K;i++)
	{
		delete [] sharevi[i];
	}
	delete [] sharevi;

	for (int i=0;i<K;i++)
	{
		delete [] routes[i];
	}
	delete [] routes;

	for (int i=0;i<K;i++)
	{
		delete [] routes_time[i];
	}
	delete [] routes_time;

	delete [] sequence;
	delete [] consist_N_to_K;

	for (int d=0;d<day;d++)
	{
		delete [] tempK[d];
	}
	delete [] tempK;

	delete [] tempnumK;

	for (int d=0;d<day;d++)
	{
		delete [] tempN[d];
	}
	delete [] tempN;

	delete [] tempnumN;

	for (int i=0;i<N+K;i++)
	{
		for (int j=0;j<N+K;j++)
		{
			delete [] places[i][j];
		
		}
	}
	for (int i=0;i<N+K;i++)
	{
		delete [] places[i];
	}
	delete [] places;

}
/*****************************************************************/