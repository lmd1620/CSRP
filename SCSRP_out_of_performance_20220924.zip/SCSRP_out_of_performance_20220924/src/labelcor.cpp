﻿#include <vector>
#include <algorithm>
#include <queue>
#include <list>
#include "labelcor.h"
#include <bitset>


#define epsilon 10e-6
#define Inf_Large 10e10

inline bool isSmaller(pair_t a, pair_t b)
{
	return(a.value < b.value);
}

using namespace std;
labelcor::labelcor(int T_,int src_,int nbCities_,double** travelcost_,double** traveltime_,double* pi_,int num_rows_,int actual_num_rows_, char domLev_)
{
	T=T_;
	src=src_;
	nbCities=nbCities_;

	domLev=domLev_;
	num_rows=num_rows_;
    pi=new double[num_rows];
	for(int i=0;i<num_rows;i++)
	{
		pi[i]=pi_[i]; 
	}

	actual_num_rows=actual_num_rows_;

	travelcost=new double*[nbCities];
	traveltime=new double*[nbCities];
	for(int i=0;i<nbCities;i++)
	{
		travelcost[i]=new double[nbCities]; 
		traveltime[i]=new double[nbCities];
	}

	for(int i=0;i<nbCities;i++)
	{
		for(int j=0;j<nbCities;j++)
		{
			travelcost[i][j]=travelcost_[i][j];
			traveltime[i][j]=traveltime_[i][j];
		}
	}

	ng_setIndicator_mat=new int*[nbCities];
	for(int i=0;i<nbCities;i++)
	{
		ng_setIndicator_mat[i]=new int[nbCities];
	}

	for(int i=0;i<nbCities;i++)
	{
		for(int j=0;j<nbCities;j++)
		{
			ng_setIndicator_mat[i][j]=0;
		}
	}

	for(int i=0;i<nbCities;i++)
	{
		vector<int> index;
		ng_set.push_back(index);
	}

	for(int i=0;i<nbCities;i++)
	{
		list<node*> label_list;
		node* node_instance=NULL;
		label_list.push_back(node_instance);
		Labelist.push_back(label_list);
		unprocess_Labelist.push_back(label_list);//unprocessed list
	}


}



vector<int> labelcor::Successors(double** traveltime,int node_,int nbnodes_)
{
	vector<int> mysucc;
	if(node_ != src)
	{
		mysucc.push_back(src);
	}
	
	
	for(int v=K;v<nbnodes_;v++)
	{
		// cout<<node_<<"\t"<<v<<"\t";
		// cout<<traveltime[node_][v]<<"\t";
		// cout<<traveltime[v][node_]<<"\n";

		if(fabs(traveltime[node_][v]-0.0)>=0 && v != node_ && traveltime[node_][v]<M)
		{
			mysucc.push_back(v);
		}
	}
	// cout<<"finished succ find\n";
	
	// for(int it=0;it<mysucc.size();it++)
	// {
	// 	cout<<mysucc[it]<<"\t";
	// }
	// cout<<endl;

	return mysucc;
}



vector<vector<int>> labelcor::Find_ng_Set(int ng_size)
{
	vector<pair_t> travelTime(nbCities);

	
	for(int it=0;it<nbCities;it++)
	{
		for(int j=0;j<nbCities;j++)
		{
		
			travelTime[j].index = j;
			travelTime[j].value = traveltime[it][j];
		}

		sort(travelTime.begin(), travelTime.end() ,isSmaller);


		
		vector<int> ng_index;
		
		int m=0;
		int k=0;
		while (k<nbCities && m<ng_size)
		{
			if(travelTime[k].value >=0.0 && travelTime[k].index >=K && travelTime[k].value < M)
			{
				ng_index.push_back(travelTime[k].index);
				
				ng_setIndicator_mat[it][travelTime[k].index]=1;

				m++;
			}

			k++;
		}
		
		ng_set[it]=ng_index;
	}

	return ng_set;	

}






node* labelcor::Extend(node* lambda,int from,int arrive)
{	
	
	node* newlab=new node;
	
	newlab->resource=0.0;
	newlab->load=0.0;
	newlab->cap_load=0.0;

	//newlab->changedstate=0;
	newlab->unreachable=1;
	newlab->ng_arcselect=vector<int>(nbCities,-1);
	
	newlab->nodevisit_indicator=vector<int>(nbCities,0);
	M_RESET(newlab->ng_unreachnode);
	//newlab->bit_value=0;
	newlab->subrow_indicator=vector<int>(actual_num_rows,0);
	newlab->subrow_unsubstract=vector<int>(actual_num_rows,0);
	newlab->appro_t_a=vector<double>(L,0);
	newlab->appro_t_s=vector<double>(L,0);
	newlab->appro_t_d=vector<double>(L,0);

	newlab->resource=max(lambda->resource+traveltime[from][arrive],people[arrive][3])+people[arrive][5];

	newlab->load=lambda->load+travelcost[from][arrive];

	if(arrive==src)
	{
		newlab->cap_load=lambda->cap_load;
	}
	else
	{
		newlab->cap_load=lambda->cap_load+people[arrive][6+P+day];
	}
	
	newlab->appro_t_a=L_extend(lambda->appro_t_d,travel_points[from][arrive],traveltime[from][arrive]);
	newlab->appro_t_s=L_max(newlab->appro_t_a,people[arrive][3]);
	newlab->appro_t_d=L_extend(newlab->appro_t_s,service_points[arrive],people[arrive][5]);

	//newlab->changedstate=1;


	newlab->ng_parent=from;

	//inser the arrive into the unreachnode
	M_INSERT(newlab->ng_unreachnode, arrive);	
	//newlab->unreachable=lambda->unreachable +1;
	//newlab->bit_value|=1<<arrive;
	
	//cout<<"test of extend1 \n";

	// bool rightlabel=false;
	// bool counter=false;
	// if (from==src)
	// {
	// 	counter=1;
	// }

	// cout<<"nodevisit_indicator\n";
	// for(int k=0;k<nbCities;k++)
	// {
	// 	cout<<k<<":\t"<<lambda->nodevisit_indicator[k]<<endl;
	// }
	// cout<<"ng_arcselect\n";
	// for(int k=0;k<nbCities;k++)
	// {
	// 	cout<<k<<":\t"<<lambda->ng_arcselect[k]<<endl;
	// }
	for(int k=0;k<nbCities;k++)
	{

		// if(lambda->ng_arcselect[k]<=-1.5 || lambda->ng_arcselect[k] > nbCities)
		// {
		// 	rightlabel=true;
		// 	break;
		// }

		// if(lambda->ng_arcselect[k] == src)
		// {
		// 	counter=counter+1;
		// }
		//cout<<"before ng_arcselect and nodevisit_indicator\t"<<lambda->ng_arcselect[k]<<"\t"<<lambda->nodevisit_indicator[k]<<endl;
		newlab->nodevisit_indicator[k]=lambda->nodevisit_indicator[k];	
		
		newlab->ng_arcselect[k]=lambda->ng_arcselect[k];

		//cout<<"after ng_arcselect and nodevisit_indicator\t"<<k<<"\n";
		if(k!=arrive)
		{
			//the next node is unreachable for the previous label and the next node is in the neighbor of current node
			if(ng_setIndicator_mat[arrive][k]==1)
			{
				

				bool bit_unreached=M_BELONGS(lambda->ng_unreachnode, k);

				if(bit_unreached==true)
				{
					//inser the k into the unreachnode
					M_INSERT(newlab->ng_unreachnode, k);
					newlab->unreachable=newlab->unreachable+1;
				}			
			}
		}
		//cout<<"after one unreachable\n";
	}


	// if(rightlabel|| counter ==0)
	// {
	// 	delete newlab;
	// 	node* node_NULL=new node;
	// 	node_NULL=NULL;
	// 	cout<<"since rightlabel|| counter ==0, delete newlab"<<ednl;
	// 	return node_NULL;
	// }


	//cout<<"test of extend2 \n";
	if(arrive>=K)
	{
		for(int index_cut=0;index_cut<row_point_indicator[T][arrive-K].size();index_cut++)//new_added resource extension
		{
			// cout<<"T,arrive,c\t"<<T<<"\t"<<arrive<<"\t"<<index_cut<<"\t"<<row_point_indicator[T][arrive-K][index_cut]<<endl;

			newlab->subrow_indicator[row_point_indicator[T][arrive-K][index_cut]]=lambda->subrow_indicator[row_point_indicator[T][arrive-K][index_cut]]+1;
			newlab->subrow_unsubstract[row_point_indicator[T][arrive-K][index_cut]]=lambda->subrow_unsubstract[row_point_indicator[T][arrive-K][index_cut]]+1;
			if (newlab->subrow_indicator[row_point_indicator[T][arrive-K][index_cut]]>=2)
			{
				newlab->subrow_indicator[row_point_indicator[T][arrive-K][index_cut]]-=2;
				newlab->load=newlab->load-pi[assigned_cuts_global[T][row_point_indicator[T][arrive-K][index_cut]][3]];
			}
		}	
	}
	//cout<<"test of extend3 \n";

	if(from>=0 && from<nbCities)
	{
		newlab->ng_arcselect[arrive]=from;
	}
	else
	{
		cout<<"newlab->ng_arcselect[arrive]=from wrong;"<<"from"<<from<<"arrive"<<arrive<<endl;
		exit(-1);
	}
	
	newlab->nodevisit_indicator[arrive]=lambda->nodevisit_indicator[arrive]+1;
	if(arrive==src)
	{
		for(int index_cut=0;index_cut<actual_num_rows;index_cut++)//new_added resource extension
		{
			// cout<<"T,arrive,c\t"<<T<<"\t"<<arrive<<"\t"<<index_cut<<endl;

			newlab->subrow_indicator[index_cut]=lambda->subrow_indicator[index_cut];
			newlab->subrow_unsubstract[index_cut]=lambda->subrow_unsubstract[index_cut];
			
		}
		// if(actual_num_rows>0)
		// {
		// 	exit(-1);
		// }
		//newlab->nodevisit_indicator[arrive]=lambda->nodevisit_indicator[arrive];
		
	}
	//else
	//{
		//newlab->nodevisit_indicator[arrive]=lambda->nodevisit_indicator[arrive]+1;//now, it could indicate how many time to visit a node
	//}
	//cout<<"test of extend4 \n";

	return newlab;
}



int labelcor::USetDom_Weak(int unreachable_current,int unreachable_new)
{
	if(unreachable_current<=unreachable_new)
	{return 1;}
	else
	{return 2;}
}

int USetDom_bit(node* U_current, node* U_new)
{
	if(M_EQUAL(U_current->ng_unreachnode,U_new->ng_unreachnode))
	{
		return 1;
	}


	if(M_SUBSET(U_current->ng_unreachnode, U_new->ng_unreachnode))
	{
		return 1; //current is subset of new
	}
	else if (M_SUBSET(U_new->ng_unreachnode, U_current->ng_unreachnode))
	{
		return 2; //new is subset of current
	}
	else
	{
		return 3; //neither subset of each others
	}
/*	*/

}

/*
int USetDom_bit(long unsigned int U_current,long unsigned int U_new)
{
	
	if(M_EQUAL(U_current,U_new))
	{
		return 1;
	}


	if(M_SUBSET(U_current, U_new))
	{
		return 1; //current is subset of new
	}
	else(M_SUBSET(U_new, U_current))
	{
		return 2; //new is subset of current
	}
	else
	{
		return 3; //neither subset of each others
	}
	



}*/
/*
int labelcor::USetDom_Strong(vector<int> U_current,vector<int> U_new)
{
	
	vector<int> diff;
	int maxval=0;
	int minval=0;

	if(U_current==U_new)
	{
		return 1;
	}

	for(int i=0;i<U_current.size();i++)
	{
		
		int minus=U_current[i]-U_new[i];
		if(fabs(minus-1.0)<1e-6)
		{
			maxval=1;
			diff.push_back(minus);
		}
		else if(fabs(minus+1.0)<=1e-6)
		{
			minval=-1;
			diff.push_back(minus);
		}


		if(fabs(maxval - 1.0)<=1e-6 && fabs(minval+1.0)<=1e-6)
		{
			return 3;
		}

	}


	sort(diff.begin(),diff.end());		
	
	
	if(diff.front()>=1.0)
	{
		return 2;//new
	}
	else if(diff.back()<= -1.0)
	{
		return 1;//current
	}
	else
	{
		return 3;
	}


	
}
*/
int labelcor::USetDom(node* U_current,node* U_new,int unreachable_current,int unreachable_new,char domLev)
{

	int dominance;

	if(domLev=='s')
	{

		//dominance=USetDom_Strong(U_current,U_new);
		dominance=USetDom_bit(U_current,U_new);
	
	}

	return dominance;
}


bool labelcor::IsLabelDominated(vector<list<node*>> &ins_Labelist,node* newlabel_node,int succ,char domLev,char global)
{
	
	list<node*> temp_del;

	list<node*>::iterator it=ins_Labelist[succ].begin();

	// double subrow_reduced_cost;

	// if((*it)!=NULL && it!=ins_Labelist[succ].end())
	// {
	// 	// cout<<"ins_Labelist\t"<<(*it)->load<<endl;


	// 	subrow_reduced_cost=(*it)->load;//new_added dominance rule

	// 	// cout<<"subrow_reduced_cost\t"<<subrow_reduced_cost<<endl;


	// 	for (int i=0;i<actual_num_rows;i++)
	// 	{
	// 		if((*it)->subrow_indicator[i]>newlabel_node->subrow_indicator[i])
	// 		{
	// 			subrow_reduced_cost-=pi[assigned_cuts_global[T][i][3]];
	// 		}
	// 	}
	// 	// cout<<"subrow_reduced_cost\t"<<subrow_reduced_cost<<endl;
	// }
	
	// double subrow_reduced_cost;

	
	while((*it)!=NULL && it!=ins_Labelist[succ].end() &&((*it)->cap_load<newlabel_node->cap_load))
	{
		double subrow_reduced_cost=(*it)->load;//new_added dominance rule
		// cout<<"subrow_reduced_cost\t"<<subrow_reduced_cost<<endl;
		for (int i=0;i<actual_num_rows;i++)
		{
			if((*it)->subrow_indicator[i]>newlabel_node->subrow_indicator[i])
			{
				subrow_reduced_cost-=pi[assigned_cuts_global[T][i][3]];
			}
		}
		

		bool judge_appro_a=true;
		if((*it)!=NULL)
		{
			for(int i=0;i<L;i++)
			{
				if((*it)->appro_t_a[i]>newlabel_node->appro_t_a[i])
				{
					judge_appro_a=false;
				}
			}
		}
		
		if((subrow_reduced_cost<= newlabel_node->load)&& judge_appro_a) 
		{
			if((USetDom((*it),newlabel_node,(*it)->unreachable,newlabel_node->unreachable,domLev)==1))
			//if(USetDom_bit((*it)->bit_value,newlabel_node->bit_value)==1)
			{
				
				return true;
			}		
		}
		it++;

	}
	

	

	while(((*it)!=NULL) && (it!=ins_Labelist[succ].end())  && ((*it)->cap_load==newlabel_node->cap_load))
	{
		double	subrow_reduced_cost=(*it)->load;//new_added dominance rule
		// cout<<"subrow_reduced_cost\t"<<subrow_reduced_cost<<endl;
		for (int i=0;i<actual_num_rows;i++)
		{
			if((*it)->subrow_indicator[i]>newlabel_node->subrow_indicator[i])
			{
				subrow_reduced_cost-=pi[assigned_cuts_global[T][i][3]];
			}
		}

		bool judge_appro_a=true;
		if((*it)!=NULL)
		{
			for(int i=0;i<L;i++)
			{
				if((*it)->appro_t_a[i]>newlabel_node->appro_t_a[i])
				{
					judge_appro_a=false;
				}
			}
		}
		
		if((subrow_reduced_cost<= newlabel_node->load)&& judge_appro_a && ((*it)->appro_t_a != newlabel_node->appro_t_a)) 
		{
			if((USetDom((*it),newlabel_node,(*it)->unreachable,newlabel_node->unreachable,domLev)==1))
			//if(USetDom_bit((*it)->bit_value,newlabel_node->bit_value)==1)
			{
				
				return true;
			}		
		}
		it++;
	}
	
	while(((*it)!=NULL) && (it!=ins_Labelist[succ].end())  && ((*it)->cap_load==newlabel_node->cap_load) )
	{
		double	subrow_reduced_cost=(*it)->load;//new_added dominance rule
		// cout<<"subrow_reduced_cost\t"<<subrow_reduced_cost<<endl;
		for (int i=0;i<actual_num_rows;i++)
		{
			if((*it)->subrow_indicator[i]>newlabel_node->subrow_indicator[i])
			{
				subrow_reduced_cost-=pi[assigned_cuts_global[T][i][3]];
			}
		}
		bool judge_appro_a=true;
		if((*it)!=NULL)
		{
			for(int i=0;i<L;i++)
			{
				if((*it)->appro_t_a[i]>newlabel_node->appro_t_a[i])
				{
					judge_appro_a=false;
				}
			}
		}

		if(subrow_reduced_cost < newlabel_node->load && judge_appro_a &&((*it)->appro_t_a == newlabel_node->appro_t_a)&& USetDom((*it),newlabel_node,(*it)->unreachable,newlabel_node->unreachable,domLev)==1)
		//if(USetDom_bit((*it)->bit_value,newlabel_node->bit_value)==1)
		{
				return true;
		}
		
		it++;
	}



	while(((*it)!=NULL) && (it!=ins_Labelist[succ].end())  && ((*it)->cap_load==newlabel_node->cap_load))
	{
		double	subrow_reduced_cost=(*it)->load;//new_added dominance rule
		// cout<<"subrow_reduced_cost\t"<<subrow_reduced_cost<<endl;
		for (int i=0;i<actual_num_rows;i++)
		{
			if((*it)->subrow_indicator[i]>newlabel_node->subrow_indicator[i])
			{
				subrow_reduced_cost-=pi[assigned_cuts_global[T][i][3]];
			}
		}
		
		bool judge_appro_a=true;
		if((*it)!=NULL)
		{
			for(int i=0;i<L;i++)
			{
				if((*it)->appro_t_a[i]>newlabel_node->appro_t_a[i])
				{
					judge_appro_a=false;
				}
			}
		}

		if((subrow_reduced_cost == newlabel_node->load)  && judge_appro_a &&((*it)->appro_t_a == newlabel_node->appro_t_a)&& USetDom((*it),newlabel_node,(*it)->unreachable,newlabel_node->unreachable,domLev)==1)
		//if(USetDom_bit((*it)->bit_value,newlabel_node->bit_value)==1)
		{
				return true;
		}
		
		it++;
	}




	while(((*it)!=NULL) && (it!=ins_Labelist[succ].end())  && ((*it)->cap_load==newlabel_node->cap_load) )
	{
		
		double	subrow_reduced_cost=(*it)->load;//new_added dominance rule
		// cout<<"subrow_reduced_cost\t"<<subrow_reduced_cost<<endl;
		for (int i=0;i<actual_num_rows;i++)
		{
			if((*it)->subrow_indicator[i]>newlabel_node->subrow_indicator[i])
			{
				subrow_reduced_cost-=pi[assigned_cuts_global[T][i][3]];
			}
		}
		bool judge_appro_a=true;
		if((*it)!=NULL)
		{
			for(int i=0;i<L;i++)
			{
				if((*it)->appro_t_a[i]>newlabel_node->appro_t_a[i])
				{
					judge_appro_a=false;
				}
			}
		}

		if (subrow_reduced_cost == newlabel_node->load && judge_appro_a &&((*it)->appro_t_a == newlabel_node->appro_t_a))
		{
			if(USetDom((*it),newlabel_node,(*it)->unreachable,newlabel_node->unreachable,domLev)==1)
			//if(USetDom_bit((*it)->bit_value,newlabel_node->bit_value)==1)
			{

				return true;
			}
			else if(USetDom((*it),newlabel_node,(*it)->unreachable,newlabel_node->unreachable,domLev)==2)
			//else if(USetDom_bit((*it)->bit_value,newlabel_node->bit_value)==2)
			{


				if(ins_Labelist[succ].size()>1)
				{
					temp_del.push_back(*it);
			
					it=ins_Labelist[succ].erase(it);
				}
				else
				{	
					//if it is the last label in the node, just replace with the new one

					//delete ins_Labelist[succ].back();
					ins_Labelist[succ].back()= newlabel_node;
					it=ins_Labelist[succ].begin();
					
					return false;
				}	

			}
		}
		else
		{
			it++;
		}
		
	}


	
	if((*it)==NULL && (it==ins_Labelist[succ].begin()))
	{
		//delete ins_Labelist[succ].back();
		ins_Labelist[succ].back()= newlabel_node;
		// if(newlabel_node->ng_arcselect[0]<-0.5)
		// {
		// 	for(int j=0;j<nbCities;j++)
		// 	{
		// 		cout<<(*it)->ng_arcselect[j]<<"   ";
		// 	}
		// 	cout<<endl;
		// 	for(int j=0;j<nbCities;j++)
		// 	{
		// 		cout<<(*it)->nodevisit_indicator[j]<<"   ";
		// 	}
		// 	cout<<endl;
		// 	// exit(-1);
		// }	
		it=ins_Labelist[succ].begin();
	
	}
	else
	{
		ins_Labelist[succ].insert(it,newlabel_node);
				
	}

	
/*
	while((*it)!=NULL && it!=ins_Labelist[succ].end())
	{		
		if(((*it)->resource >= newlabel_node->resource) && ((*it)->load >= newlabel_node->load) && ((*it)->cap_load >= newlabel_node->cap_load)&& (USetDom((*it)->ng_unreachnode,newlabel_node->ng_unreachnode,(*it)->unreachable,newlabel_node->unreachable,domLev)==2))
		//if(((*it)->resource >= newlabel_node->resource) && ((*it)->load >= newlabel_node->load) && ((*it)->cap_load >= newlabel_node->cap_load)&& (USetDom_bit((*it)->bit_value,newlabel_node->bit_value)==2))
		{
			temp_del.push_back(*it);
			
			it=ins_Labelist[succ].erase(it);

		}
		else
		{
			it++;			
		}

	
	}
*/

	
	while(!temp_del.empty())
	{
		delete temp_del.back();
		temp_del.pop_back();
	}
	

	return false;
}




void labelcor::printlabels(int i)
{
	cout<<"*****************************"<<endl;

	cout<<"This is city: "<<i<<"\t"<<Labelist[i].size()<<endl;
	for(list<node*>::iterator it=Labelist[i].begin();it!=Labelist[i].end();it++)
	{
		if((*it)!=NULL)
		{
			cout<<(*it)->resource<<"\t"<<(*it)->load<<"\t"<<(*it)->cap_load<<endl;
			 
			for(int j=0;j<nbCities;j++)
			{
				cout<<(*it)->ng_arcselect[j]<<"   ";
			}
			cout<<endl;
			for(int j=0;j<nbCities;j++)
			{
				cout<<(*it)->nodevisit_indicator[j]<<"   ";
			}
			cout<<endl;
			for(int j=0;j<actual_num_rows;j++)
			{
				cout<<(*it)->subrow_indicator[j]<<"   ";
			}
			cout<<endl;
		}

	}
	cout<<"*****************************"<<endl;
	
}




void labelcor::LabelAlgorithm(double** travelcost,double** traveltime)
{
	// cout<<"LabelAlgorithm(double** travelcost,double** traveltime)"<<endl;
	ng_size=10;
//	ng_size=N;

	ng_set=Find_ng_Set(ng_size);
	/*
	for(int index=0;index<nbCities;index++)
	{
		cout<<"ng_set"<<endl;
		for(int i=0;i<ng_set[index].size();i++)
		{
			cout<<ng_set[index][i]<<" ";
		}
		cout<<endl;
		cout<<"ng_setIndicator_mat"<<endl;
		for(int i=0;i<nbCities;i++)
		{
			cout<<ng_setIndicator_mat[index][i]<<" ";
		}
		cout<<endl;
	}*/
	
	// cout<<"nbCities\t"<<nbCities<<endl;

	vector<int> E;
	E.push_back(src);
	// cout<<"src\t"<<src<<endl;

	int flag;
	int srcflag;				

	node* src_initial_label=new node;
	src_initial_label->resource=people[src][3];
	src_initial_label->load=0.0;
	src_initial_label->cap_load=0.0;

	M_INSERT(src_initial_label->ng_unreachnode, src);
	M_RESET(src_initial_label->ng_unreachnode);
	src_initial_label->ng_arcselect=vector<int>(nbCities,-1);
	src_initial_label->nodevisit_indicator=vector<int>(nbCities,0);

	src_initial_label->appro_t_a=vector<double>(L,people[src][3]);//initialization
	src_initial_label->appro_t_s=vector<double>(L,people[src][3]);
	src_initial_label->appro_t_d=vector<double>(L,people[src][3]);

	// cout<<"actual_num_rows\t"<<actual_num_rows<<endl;
	src_initial_label->subrow_indicator=vector<int>(actual_num_rows,0);
	src_initial_label->subrow_unsubstract=vector<int>(actual_num_rows,0);
	// cout<<"declare src vec"<<endl;

	//src_initial_label->bit_value=0;
	//src_initial_label->bit_value|=1<<src;
	src_initial_label->unreachable=1;// number of unreachable nodes, cannot reach itself at the begining
	//src_initial_label->changedstate=1;//the indicator of new generated label 
	//cout<<"wirte 1\n";
	//src_initial_label->ng_arcselect[src]=src;
	//cout<<"wirte 2\n";
	src_initial_label->ng_parent=src;
	src_initial_label->nodevisit_indicator[src]=0;
	//cout<<"wirte 3\n";
	//delete unprocess_Labelist[src].back();
	unprocess_Labelist[src].back()=src_initial_label;

	// cout<<"before while\n";

	
	srcflag=0;

	while(!E.empty())
	{
			

		int selectnode=E.front();
		
		// cout<<"select node\t"<<selectnode<<endl;
		list<node*> tmp_p;
		list<node*>::iterator pit=unprocess_Labelist[selectnode].begin();
		// cout<<"initial selectnode size\t"<<unprocess_Labelist[selectnode].size()<<endl;

		// for(list<node*>::iterator pit=unprocess_Labelist[selectnode].begin();pit!=unprocess_Labelist[selectnode].end();pit++)
		// {
		// 	if((*pit)!=NULL)
		// 	{
		// 		bool dominatecheck=false;
		// 		dominatecheck=IsLabelDominated(Labelist,*pit,selectnode,domLev,'g');

		// 		if(dominatecheck)
		// 		{
		// 			tmp_p.push_back(*pit);
		// 			unprocess_Labelist[selectnode].erase(pit);					
		// 		}
		// 	}

		// }

		while(((*pit)!=NULL) && pit!=unprocess_Labelist[selectnode].end())
		{
			// cout<<"********************************\n";
			// for(int j=0;j<nbCities;j++)
			// {
			// 	cout<<(*pit)->ng_arcselect[j]<<"   ";
			// }
			// cout<<endl;
			// cout<<"********************************\n";

			bool dominatecheck=false;

			// cout<<"unprocess_Labelist check start\t"<<endl;

			dominatecheck=IsLabelDominated(Labelist,*pit,selectnode,domLev,'g');
			// cout<<"===============================\n";
			// for(int j=0;j<nbCities;j++)
			// {
			// 	cout<<(*pit)->ng_arcselect[j]<<"   ";
			// }
			// cout<<endl;
			// cout<<"================================\n";
			// cout<<"IsLabelDominated finished\t"<<endl;
			
			if(dominatecheck)
			{
				// cout<<"delete start--------------------------\n";
				// for(int j=0;j<nbCities;j++)
				// {
				// 	cout<<(*pit)->ng_arcselect[j]<<"   ";
				// }
				// cout<<endl;

				// cout<<"delete end--------------------------\n";

				tmp_p.push_back(*pit);
				pit=unprocess_Labelist[selectnode].erase(pit);
				
			}
			else
			{
				++pit;
			}
		}
		
		// cout<<"tmp_p size\t"<<tmp_p.size()<<endl;

		while(!tmp_p.empty())
		{

			// cout<<"++++++++++++++++++++++++++++++++\n";
			// if((tmp_p.back())!=NULL)
			// {
			// 	for(int j=0;j<nbCities;j++)
			// 	{
			// 		cout<<(tmp_p.back())->ng_arcselect[j]<<"   ";
					
			// 	}
			// 	cout<<endl;
				
			// }
			// cout<<"++++++++++++++++++++++++++++++++\n";

			delete tmp_p.back();
			tmp_p.pop_back();

			// cout<<"tmp_p deduction size\t"<<tmp_p.size()<<endl;

		}	

		// cout<<"orignal unprocess_Labelist\t"<<selectnode<<endl;
		// for(list<node*>::iterator it=unprocess_Labelist[selectnode].begin();it!=unprocess_Labelist[selectnode].end();it++)
		// {
		// 	cout<<"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n";
		// 	if((*it)!=NULL)
		// 	{
		// 		for(int j=0;j<nbCities;j++)
		// 		{
		// 			cout<<(*it)->ng_arcselect[j]<<"   ";
					
		// 		}
		// 		cout<<endl;
		// 	}
		// 	cout<<"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n";
		// }
		// cout<<endl;

		// cout<<"orignal checknode unprocess_Labelist\t"<<selectnode<<"\tsize\t"<<unprocess_Labelist[selectnode].size()<<endl;
		// for(list<node*>::iterator it=unprocess_Labelist[selectnode].begin();it!=unprocess_Labelist[selectnode].end();it++)
		// {
		// 	if((*it)!=NULL)
		// 	{
		// 		bool rightlabel=false;
				
		// 		for(int j=0;j<nbCities;j++)
		// 		{
		// 			if((*it)->ng_arcselect[j]<-2 || (*it)->ng_arcselect[j] > nbCities)
		// 			{
		// 				rightlabel=true;
		// 			}
					
		// 		}
		// 		if(rightlabel)
		// 		{
		// 			for(int j=0;j<nbCities;j++)
		// 			{
		// 				cout<<(*it)->ng_arcselect[j]<<"   ";
						
		// 			}
		// 			cout<<endl;
		// 			exit(-5);
		// 		}
				
		// 	}
		// }

		// for(int checknode=0;checknode<nbCities;checknode++)
		// {
		// 	cout<<"orignal checknode unprocess_Labelist\t"<<checknode<<"\tsize\t"<<unprocess_Labelist[checknode].size()<<endl;
		// 	for(list<node*>::iterator it=unprocess_Labelist[checknode].begin();it!=unprocess_Labelist[checknode].end();it++)
		// 	{
		// 		if((*it)!=NULL)
		// 		{
		// 			bool rightlabel=false;
					
		// 			for(int j=0;j<nbCities;j++)
		// 			{
		// 				if((*it)->ng_arcselect[j]<-2 || (*it)->ng_arcselect[j] > nbCities)
		// 				{
		// 					rightlabel=true;
		// 				}
						
		// 			}
		// 			if(rightlabel)
		// 			{
		// 				for(int j=0;j<nbCities;j++)
		// 				{
		// 					cout<<(*it)->ng_arcselect[j]<<"   ";
							
		// 				}
		// 				cout<<endl;
		// 				exit(-5);
		// 			}
					
		// 		}
		// 	}
			
		// }
		

		// cout<<"tmp delete finished\t"<<endl;
		// cout<<"unprocess_Labelist check finished\t"<<unprocess_Labelist[selectnode].size()<<endl;
		
		if (selectnode==src)
		{
			srcflag++;
		}

		// cout<<"srcflag\t"<<srcflag<<endl;

		if(srcflag>1)
		{	
			// cout<<"enter the remove E.begion\n";
			list<node*> label_list;
			node* node_instance=NULL;
			label_list.push_back(node_instance);

			unprocess_Labelist[selectnode]=label_list;
			
			// cout<<"before remove E.begin\t"<<endl;

			if(!E.empty())
			{
				E.erase(E.begin());
				srcflag=1;
				
				
			}
			else
			{
				break;	
			}
			

		}
		else
		{
			// cout<<"before succnode\t";
			vector<int> succ;
			succ=Successors(traveltime,selectnode,nbCities);
			
			// cout<<"succnode\t";
			while(!succ.empty())
			{			
				list<node*> Fij;

				int succnode=succ.front();//search the first node of the succssor list
				// cout<<succnode<<"\t";

				for(list<node*>::iterator it=unprocess_Labelist[selectnode].begin();it!=unprocess_Labelist[selectnode].end();it++)
				{	
					if((*it)!=NULL)
					{
						// if(succnode==src && (*it)->ng_arcselect[src]==src)
						// {
						// 	continue;
						// }

						bool unreachind=false;

						unreachind = M_BELONGS((*it)->ng_unreachnode, succnode);
						
						if(succnode==src||( !unreachind && succnode!=(*it)->ng_parent) )
						{
							flag=1;
							for (int p=0;p<P;p++)
							{
								if(people[src][6+day+p]<people[succnode][6+day+p])
								{
									flag=0;
								}
							}

							
							if((succnode==src)||( ((*it)->cap_load+people[succnode][6+P+day]<=people[src][6+P+day])&& Extend_appro_t((*it),selectnode,succnode) && flag==1))
							{	
								//cout<<"\n orignal label\t"<<selectnode<<"\t"<<succnode<<endl;
								// for(int j=0;j<nbCities;j++)
								// {
								// 	cout<<(*it)->ng_arcselect[j]<<"   ";
									
								// }
								// cout<<endl;
								node* NewNodeLabel=Extend((*it),selectnode,succnode);	
								if((NewNodeLabel)!=NULL)
								{
									Fij.push_back(NewNodeLabel);

									// if(NewNodeLabel->ng_arcselect[src]<-1||NewNodeLabel->ng_arcselect[src]>=N+K)
									// {
									// 	cout<<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
									// 	cout<<"selectnode"<<selectnode<<endl;
									// 	cout<<"succnode"<<succnode<<endl;
									// 	for(int ij=0;ij<nbCities;ij++)
									// 	{
									// 		cout<<(*it)->ng_arcselect[ij]<<"   ";
									// 	}
									// 	cout<<endl;
									// 	for(int ij=0;ij<nbCities;ij++)
									// 	{
									// 		cout<<NewNodeLabel->ng_arcselect[ij]<<"   ";
									// 	}
									// 	printlabels(selectnode);
									// 	printlabels(succnode);
									// 	exit(-1);
									// }

								}

								// else
								// {
								// 	delete  NewNodeLabel;
								// }

								//cout<<"extension done\n";

								// bool includesrc=true;
			
								// for(int j=0;j<nbCities;j++)
								// {
								// 	//cout<<NewNodeLabel->ng_arcselect[j]<<"   ";
								// 	if(NewNodeLabel->ng_arcselect[j]==src)
								// 	{
								// 		includesrc=false;
								// 		break;
								// 	}
								// }
								// if(includesrc)
								// // {
								// 	cout<<"Newlabel\t"<<endl;
								// 	for(int j=0;j<nbCities;j++)
								// 	{
								// 		cout<<NewNodeLabel->ng_arcselect[j]<<"   ";
										
								// 	}
								// 	cout<<endl;
								// // 	exit(-1);
								// // }
								
								
							}						
						}
					}

				}
				
				bool changed=false;

				if(Fij.size()>0 && Fij.front()!=NULL)
				{
					list<node*> tmp;

					for(list<node*>::iterator f=Fij.begin();f!=Fij.end();f++)
					{

						bool dominatecheck=true;
					
						dominatecheck=IsLabelDominated(unprocess_Labelist,*f,succnode,domLev,'g');

						if(dominatecheck)
						{
							tmp.push_back(*f);				
						
						}
						else
						{
							changed=true;
						}
										
					}


					while(!tmp.empty())
					{
						
				
						delete tmp.back();

						tmp.pop_back();

					}

					//  cout<<"orignal label check after extension\n";
					// for(list<node*>::iterator checkit=unprocess_Labelist[selectnode].begin();checkit!=unprocess_Labelist[selectnode].end();checkit++)
					// {
					// 	// cout<<"orignal label\t"<<selectnode<<"\t"<<succnode<<endl;
					// 	for(int j=0;j<nbCities;j++)
					// 	{
					// 		cout<<(*checkit)->ng_arcselect[j]<<"   ";
							
					// 	}
					// 	cout<<endl;

					// }
				}	

				if(changed)
				{
					bool appear=false;


					appear=find(E.begin(), E.end(), succnode) != E.end();

					if(appear)
					{}
					else
					{
						E.push_back(succnode);//if the label set changed, add the succssor node into the waiting list to visit
					}
					
					
				}						
				succ.erase(succ.begin());								
			}
	
			// cout<<"selectnode after\t"<<selectnode<<"\tsize\t"<<unprocess_Labelist[selectnode].size()<<endl;
			list<node*> label_list;
			node* node_instance=NULL;
			label_list.push_back(node_instance);

			unprocess_Labelist[selectnode]=label_list;
			// cout<<"selectnode\t"<<selectnode<<"\tsize\t"<<unprocess_Labelist[selectnode].size()<<endl;
			E.erase(E.begin());

			// cout<<"E size\t"<<E.size()<<endl;
		}
		
			
	}

	// printlabels(src);
	//removebadlabels(src);
	//printlabels(src);

	



}


void labelcor::removebadlabels(int o)
{

	list<node*> temp_del;
	list<node*>::iterator it =Labelist[o].begin();
	
	cout<<Labelist[o].size()<<endl;
	for(list<node*>::iterator it=Labelist[o].begin();it!=Labelist[o].end();it++)					
	{	
		int flag1=0;
		
		if((*it)->load>=1e-5 || (*it)->resource<=0)
		{
			//cout<<(*it)->load<<"\t"<<(*it)->resource<<"\t"<<(*it)->ng_unreachnode[0]<<"\t"<<(*it)->ng_unreachnode[1]<<"\t"<<endl;
			temp_del.push_back(*it);
			it=Labelist[o].erase(it);
		}
		else
		{
			for(int index_i=0;index_i<N+K;index_i++)
			{
				if ((*it)->nodevisit_indicator[index_i]>1)
				{
					//cout<<index_i<<"\t"<<(*it)->nodevisit_indicator[index_i]<<endl;
			
					temp_del.push_back(*it);
					it=Labelist[o].erase(it);
					flag1=1;
					cout<<"stop here\n";
					exit(-1);
					break;
				}
			}
					
			if(flag1==0)
			{
				it++;
			}
		}

		

	}

	while(!temp_del.empty())
	{

		delete temp_del.back();
		temp_del.pop_back();

	}

}


vector<double> labelcor::L_extend(vector<double> appro_time1,vector<double> appro_time2,double appro_time_2)
{
	 //cout<<"begin_L_extend"<<endl;
	//cout<<"begin_l_extend"<<endl;
	vector<double> new_appro_time_L2;
	vector<double> new_appro_time_L;
	double appro_t;
	for (int i=0;i<L;i++)
	{
		for (int j=0;j<L;j++)
		{
			new_appro_time_L2.push_back(appro_time_2+appro_time1[i]+appro_time2[j]);
		}
	}

	sort(new_appro_time_L2.begin(), new_appro_time_L2.end());
	
	for (int i=0;i<L;i++)
	{
		appro_t=0;
		for (int j=0;j<L;j++)
		{
			appro_t+=new_appro_time_L2[i*L+j];
		}
		new_appro_time_L.push_back(appro_t/L);
		//cout<<"new_appro_time_L"<<"i"<<new_appro_time_L[i]<<endl;
	}
	return new_appro_time_L;
}

vector<double> labelcor::L_max(vector<double> appro_time1,double appoint_time_e)
{
	// cout<<"begin_L_max"<<endl;
	vector<double> new_appro_time;
	for(int i=0;i<L;i++)
	{
		new_appro_time.push_back(max(appro_time1[i],appoint_time_e));
	}
	return new_appro_time;
}


double labelcor:: cal_on_time_p(vector<double> appro_time,double appoint_time)
{
	// cout<<"begin_cal_on_time_p"<<endl;
	int cout_num=0;
	for (int i=0;i<L;i++)
	{
		if(appro_time[i]<=appoint_time)
		{
			cout_num++;
			//cout<<"cout_num"<<cout_num<<endl;
		}
	}
	double on_time_p=cout_num*1.0/L;
	//cout<<"on_time_p"<<on_time_p<<endl;
	return on_time_p;
}

bool labelcor::Extend_appro_t(node* lambda,int from,int arrive)
{
	if (arrive==src)
	{
		return true;
	}

	// cout<<"begin_Extend_appro_t"<<endl;
	double on_time_p;
	double on_time_p1;
	vector<double> new_appro_time_a;
	vector<double> new_appro_time_s;
	vector<double> new_appro_time_d;
	vector<double> new_appro_time;

	//new_appro_time_a=L_extend(lambda->appro_t_d,generate_points(traveltime[from][arrive]));
	new_appro_time_a=L_extend(lambda->appro_t_d,travel_points[from][arrive],traveltime[from][arrive]);
	on_time_p=cal_on_time_p(new_appro_time_a,people[arrive][4]);
	//cout<<"on_time_p"<<on_time_p<<endl;

	
	new_appro_time_s=L_max(new_appro_time_a,people[arrive][3]);
	//new_appro_time_d=L_extend(new_appro_time_s,generate_points(people[arrive][5]));
	new_appro_time_d=L_extend(new_appro_time_s,service_points[arrive],people[arrive][5]);
	new_appro_time=L_extend(new_appro_time_d,travel_points[arrive][src],traveltime[arrive][src]);
	on_time_p1=cal_on_time_p(new_appro_time,people[src][4]+regulation);
	//cout<<"on_time_p1"<<on_time_p1<<endl;
	if(on_time_p>=appro_p && on_time_p1>=appro_p)
	{
		//cout<<on_time_p<<on_time_p1<<appro_p<<endl;
		return true;
	}
	else
	{
		return false;
	}
}

