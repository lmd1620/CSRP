#ifndef VARIABLE_local_HEADER
#define VARIABLE_local_HEADER
#define DISTRIBUTION 2	// 1: uniform, 2: two-point, 3: triangle

#include <cplex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <iomanip>
#include <time.h>
#include <cstdlib> 
#include <vector>
#include<list>
#include <queue>
#include <cstdio>

using namespace std;
#define PI                      3.141592654
#define EARTH_RADIUS            6378.137       
#define M 10e10     


extern int day;
extern int K; //doctors
extern int N; //patients
extern int Q;
extern int P;
extern double regulation;
extern double** people;
extern double** travel;
extern double*** daytravel;
extern double*** tempdaytravel;
extern double**** daydoctravel;
extern double* extra_routes;
extern double** costs_sum;
extern double** sharev;
extern double** sharevi;
extern int** routes;
extern double** routes_time;
extern int* sequence;
extern int** tempK;
extern int** tempN; //new_added  available patients for each day
extern double*** places;
extern int* consist_N_to_K;

extern int R;//routes number
extern double   **Routes;
// extern vector<vector<int>> ROUTES;
// extern vector<double> ROUTES_COST;
// extern vector<vector<int>> ROUTES_SEQ;
extern int    constraints[4];
extern int*    tempnumK;//new_added available patients number
extern int*    tempnumN;
extern double penalty_cost[4];
extern double sum_costs;
extern double travel_cost;
extern double costs[3];                    
extern int    route_index_1;
extern double addcost;                   
extern int out_index;
extern time_t tBegin,timeEnd,currTime;
extern clock_t time_finish,time_start;
extern double TIME_LIMIT;
extern bool STOP_TIME_LIMIT;
extern double current_time;
extern int BP_nodes;

extern int L;//discrete points
extern double appro_p;//probability 
extern double appro_v;//variation, [(1-v)*initialtime,(1+v)*initialtime]
extern vector<vector<vector<double>>> travel_points;
extern vector<vector<double>> service_points;


extern vector<vector<double>> m_time_lb;
extern vector<vector<double>> m_time_ub;
extern vector<double> m_service_lb;
extern vector<double> m_service_ub;
extern vector<vector<double>>  m_time_std;
extern vector<double> m_service_std;
extern vector<vector<vector<double>>> m_saa_time;
extern vector<vector<double>> m_saa_service;
extern int m_saa_number;
extern double eps;



extern vector<vector<vector<int>>> assigned_cuts_global;//new_added 
extern vector<vector<vector<int>>> unassigned_cuts_global;//new_added 
extern vector<vector<vector<int>>> row_point_indicator;//new_added  for each day each point, the collection of cuts contain the point

extern vector<vector<vector<vector<int>>>> basic_columns;

typedef class data
{
public:

	char *istname;
    int option;
    char *distname;

    // clock_t start_time;
    // clock_t stop_time;
    time_t  start_time;
    time_t stop_time;
    // tBegin,timeEnd,currTime;

} data;


#endif