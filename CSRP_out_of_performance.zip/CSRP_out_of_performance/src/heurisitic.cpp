#include "heurisitic.h"


void initialization(int d)
{
	tempnumK[d]=0;//new_added 
	tempnumN[d]=0;

	for(int i=0;i<N+K;i++)
	{
		for(int j=0;j<N+K;j++)
		{
			daytravel[d][i][j]=travel[i][j];
			tempdaytravel[d][i][j]=travel[i][j];
		}
	}

	int temp=0;

	for (int i=0; i< K; i++)
	{
		if (people[i][6+d]!=0)
		{
			tempK[d][temp++] = i;//new_added 
		}
		else
		{
			for(int j=0;j<N+K;j++)
			{
				if (i!=j)
				{
				    daytravel[d][i][j]=M;
				    daytravel[d][j][i]=M;
				    tempdaytravel[d][i][j]=M;
				    tempdaytravel[d][j][i]=M;
				}
			}
		}
	}
	tempnumK[d]=temp;
	temp=0;
	for (int i=K; i<N+K; i++)
	{
		if (people[i][6+d]!=0)
		{
			tempN[d][temp] = i;
			sequence[temp++] = i;
		}
		else
		{
			for(int j=0;j<N+K;j++)
			{
				if (i!=j)
				{
				    daytravel[d][i][j]=M;
				    daytravel[d][j][i]=M;
				    tempdaytravel[d][i][j]=M;
				    tempdaytravel[d][j][i]=M;
				}
			}
		}
	}
	tempnumN[d]=temp;

	// sharev returns to zero
	for (int i=0; i!=N+K; i++)
	{
		sharev[i][0] = 0.0;
		sharev[i][1] = 0.0;
		sharev[i][2] = 0.0;

		sharevi[i][0] = 0.0;
		sharevi[i][1] = 0.0;
		sharevi[i][2] = 0.0;
	}

	// routes initialization
	for (int k=0; k!=K; k++)
	{
		for (int i=2; i!=N+4; i++)
		{
			routes[k][i] = k;
		}
		routes[k][0] = 0;
		routes[k][1] = 0;
	}

}




//calculate totalcost
void totalCosts()
{
	int nrk;
	int p1,p2;
	double s;
	for (int k=0;k!=K;k++)
	{
		for (int i=0; i<6; i++)
		{
			costs_sum[k][i]=0;
		}
	}

	for (int k=0; k!=K; k++)
	{
		nrk = routes[k][1];
		if (nrk > 0)
		{
			double capacity=0;
			int start= routes[k][2];
			for (int l=2; l!=nrk+2; l++)
			{
				p1 = routes[k][l];
				p2 = routes[k][l+1];
				costs_sum[start][1] += travel_cost* travel[p1][p2];
				capacity+=people[p2][6+day+P];
                
                for (int loc=6+day;loc<6+day+P;loc++)
				{
					if (people[p2][loc]>people[start][loc])
					{
						costs_sum[start][2] +=penalty_cost[2];
						//costs_sum[start][2] +=penalty_cost[2]*people[p2][5];
					}
				}
				if (sharev[p2][2] > people[p2][4])
                    costs_sum[start][3] += penalty_cost[0];
					//costs_sum[start][3] += penalty_cost[0] * (sharev[p2][2] -people[p2][4]);
			}
			costs_sum[start][1] += travel_cost * travel[p2][start];
            s = sharev[p2][2] + people[p2][5] + travel[p2][start];
			if(capacity>people[start][6+day+P])
			{
				costs_sum[start][5] +=10000000;
			}
            if (s > people[start][4]+regulation)
                //costs_sum[start][4] += penalty_cost[1] * (s - people[start][4]-regulation);
				costs_sum[start][4] += penalty_cost[1];
		}
	}
	for (int k=0;k<K;k++)
	{
		for (int i=0; i<6; i++)
			costs_sum[k][0] += costs_sum[k][i];
	}
	for (int k=0; k<K; k++)
	{
		sum_costs+=costs_sum[k][0];
	}
		
}


void routesTime()
{
	int nri,p0;
	double os;
	for (int k=0; k!=K; k++)
	{
		nri = routes[k][1];
		if (nri>0)
		{
			int start=routes[k][2];
			routes_time[k][2] = people[start][3];
			for (int i=3; i!=nri+3; i++)
			{
				p0 = routes[k][i];
				os = sharev[p0][2];
				routes_time[k][i] = os;
			}
			os = os + people[p0][5] + travel[p0][start];
			routes_time[k][nri+3] = os;
			for (int i=nri+4; i!=N+4; i++)
				routes_time[k][i] = 0;
		}
	}
}

void addCostOne(int pp)
{
	int p0, p1, p2;
	int cnr, cnrl;
	double os, ns, t;
    double *nstarts;
	nstarts=new double[N+2+2];
    cnr = routes[route_index_1][1]+2;
	int sn,f;
	double addcosti,benchcost, penaltyC,total_capacity;
	addcost=0;
	
	for (int loc=6+day;loc<6+day+P;loc++)
	{
		if (people[pp][loc]>people[route_index_1][loc])
		{
			//addcost+=penalty_cost[2]*people[pp][5];
			addcost+=penalty_cost[2];
		}
	}
	total_capacity=0;
	for(int j=3;j<cnr+1;j++)
	{
		if(routes[route_index_1][j]>routes[route_index_1][2])
		{
			total_capacity+=people[routes[route_index_1][j]][6+P+day];
		}
	}
	total_capacity+=people[pp][6+P+day];
	for (int j=2; j!=cnr+1; j++)
	{
		sn = 0;
		f = 0;
		
		if(total_capacity>people[routes[route_index_1][2]][6+P+day])
		{
			addcosti = addcost+penalty_cost[3];
		}
		else
		{
			addcosti = addcost;
		}
		p1 = routes[route_index_1][j];
		p2 = routes[route_index_1][j+1];
		addcosti += travel_cost*(travel[p1][pp]+travel[pp][p2]-travel[p1][p2]);
		
        ns = routes_time[route_index_1][j]+people[p1][5]+travel[p1][pp];
        if (ns < people[pp][3])
			ns = people[pp][3];
		else if (ns > people[pp][4])
            addcosti += penalty_cost[0];
			//addcosti += penalty_cost[0]*(ns-people[pp][4]);
		nstarts[j] = ns;

	
		ns = ns+people[pp][5]+travel[pp][p2];
		os = routes_time[route_index_1][j+1];
        if (ns <= os)
			ns = os;
		else
		{
            t = people[p2][4];
			if (p2<K)
				t+=regulation;
			if (t < ns)
			{
				if (j < cnr)
					penaltyC = penalty_cost[0];
				else
					penaltyC = penalty_cost[2];
				if (t < os)
					addcosti += penaltyC;
					//addcosti += penaltyC*(ns-os);
				else
					addcosti += penaltyC;
					//addcosti += penaltyC*(ns-t);
			}
		}
		nstarts[j+1] = ns;
		
		benchcost = costs[0];
		if (addcosti > benchcost)
			f = 1;
		if (f == 0)
		{
			cnrl = cnr+1;
			for (int l=j+1; l!=cnr+1; l++)
			{
				p1 = routes[route_index_1][l];
				p2 = routes[route_index_1][l+1];
				ns = ns+people[p1][5]+travel[p1][p2];
				os = routes_time[route_index_1][l+1];
				if (ns <= os)
				{
					ns = os;
					cnrl = l+1;
					break;
				}
				else
				{
					t = people[p2][4];
					if (p2<K)
				        t+=regulation;
					if (t < ns)
					{
						if (l < cnr)
							penaltyC = penalty_cost[1];
						else
							penaltyC = penalty_cost[2];
						if (t < os)
							addcosti += penaltyC;
							//addcosti += penaltyC*(ns-os);

						else
							addcosti += penaltyC;
							//addcosti += penaltyC*(ns-t);
						if (addcosti > benchcost)
						{
							f = 1;
							break;
						}
					}
				}
				nstarts[l+1] = ns;
			}
		}

		if (f == 0)
		{
			for (int i=K; i!=K+N; i++)
			{

				sharevi[i][0] = sharev[i][0];
				sharevi[i][1] = sharev[i][1];
				sharevi[i][2] = sharev[i][2];

			}
			sharevi[pp][0] = route_index_1;
			sharevi[pp][1] = j+1;
			sharevi[pp][2] = nstarts[j];

			
			for (int l=j+1; l!=cnrl; l++)
			{
				p0 = routes[route_index_1][l];
				sharevi[p0][2] = nstarts[l];
			}
			if (f == 0)
			{
				costRenew(pp,addcosti);
			}
		}
	}
	delete [] nstarts;
}

void costRenew(int pp,double addcosti)
{
	if (addcosti < costs[0])
	{
		for (int i=0; i!=N+K; i++)
		{
			places[pp][i][0] = sharevi[i][0];
			places[pp][i][1] = sharevi[i][1];
			places[pp][i][2] = sharevi[i][2];
		}
	}
	costs[0] = addcosti;
}

void insertion(int pp)
{
	int ri,rp,nri,p0;
	ri = int(sharev[pp][0]);
	rp = int(sharev[pp][1]);
	nri = routes[ri][1];
	for (int i=nri+4; i!=rp; i--)
	{
		p0 = routes[ri][i-1];
		routes[ri][i] = p0;
		sharev[p0][1] += 1;
	}
	routes[ri][rp] = pp;
	routes[ri][1] += 1; 

	consist_N_to_K[pp]=ri;
}